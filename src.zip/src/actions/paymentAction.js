import axios from 'axios';
import {GET_PAYMENT_TEXT,SHOW_PAYMENT_ONLINE_MODAL,SHOW_PAYMENT_UPON_DELIVERY_MODAL,RESET_TRAVEL_COMPLETELY,RESET_PAYMENT_COMPLETELY,GET_CITIES} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getPaymentTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_PAYMENT_TEXT, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION
  export const getCities = () => {
  return (dispatch) => {
    client.post(`getzones?zone_country_id=108`).then((response) => {
  console.log("response",response)
      const res = response.data.data;
      dispatch({type: GET_CITIES, payload: res})
    }).catch((error) => {
        console.log("error",error)
      dispatch({type: GET_CITIES, payload: []})
    })
  }
  };
  //START SHOW/HIDE MODAL
  export const showPaymentOnlineModal = value => {
    return {type: SHOW_PAYMENT_ONLINE_MODAL, payload: value};
  };
  //END SHOW/HIDE MODAL

  //START SHOW/HIDE MODAL
  export const showPaymentUponDeliveryModal = value => {
    return {type: SHOW_PAYMENT_UPON_DELIVERY_MODAL, payload: value};
  };
  //END SHOW/HIDE MODAL


  export const resetTraveloCompletely = () =>
  {
    return dispatch =>
    {
      dispatch({type:RESET_TRAVEL_COMPLETELY});
    }
  
  }
  export const goFromPaymentUponDeliveryInformation= ( city,address,details,user_id,order_id,type,company_name,company_name_ar) => {
console.log("order_id",order_id)
console.log("type",type)
console.log("address",address)
console.log("details",details)
console.log("city",city)
    return (dispatch) => {
      if (city == ''||address==''||details=='') {
        // dispatch({
        //   type: SERVANT_INSURANCE_MESSAGE,
        //   payload: {
        //     isError: true,
        //     isSuccess: false,
        //     msg:message
        //   }
        // });
     
  
      }  
      
          else{
 
    
          client.post(`addaddress`,{
            city:city,
            address:address,
            details:details,
            order_id:order_id,
            type:type
          }).then(function(response) {
            console.log("response",response)
      
            // dispatch({
            //   type: SERVANT_INSURANCE_MESSAGE,
            //   payload: {
            //     isError: false,
            //     isSuccess: true,
            //     msg: "success"
            //   }
            // });
       Actions.DoneScreen({user_id:user_id,order_id:order_id,company_name:company_name,company_name_ar:company_name_ar});
       dispatch({type: SHOW_PAYMENT_UPON_DELIVERY_MODAL, payload: false});

       setTimeout(() => dispatch({type: RESET_PAYMENT_COMPLETELY}), 1000);


          }).catch(function(error) {
            console.log("error11111111",error)
            const res = JSON.parse(error.request._response);
            console.log("res",res)
            dispatch({
              type: SERVANT_INSURANCE_MESSAGE,
              payload: {
                isError: true,
                isSuccess: false,
                msg: res.message
              }
            });

  
          });
        }
      }
    
  };


