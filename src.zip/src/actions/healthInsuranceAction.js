
import axios from 'axios';
import {GET_HEALTH_INSURANCE_TEXTS,RESET_HEALTH_INSURANCE_MESSAGE,HEALTH_INSURANCE_MESSAGE,RESET_HEALTH_COMPLETELY} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";
import {scanned_id_image} from "../App";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getHealthInsuranceTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_HEALTH_INSURANCE_TEXTS, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION

  //START SHOW/HIDE MODAL
export const resetHealthInsuranceMessage = value => {
    return {type:RESET_HEALTH_INSURANCE_MESSAGE};
  };

  
  //END SHOW/HIDE MODAL



  export const goFromHealthInsurance = ( full_name,id_number,age,Do_you_have_any_diseases,user_id,message,id_image) => {
    console.log("Do_you_have_any_diseases",Do_you_have_any_diseases)
    return (dispatch) => {
      if (full_name == ''||id_number==''|| age==''||Do_you_have_any_diseases==''||id_image==null) {
        dispatch({
          type: HEALTH_INSURANCE_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg:message
          }
        });
     
  
      }  
      
          else{
         const data={ 
  
           full_name:full_name,
           id_number:id_number,
           age:age,
           Do_you_have_any_diseases:Do_you_have_any_diseases,
           user_id:user_id
    }
    let type=null
    if(Do_you_have_any_diseases=='0'){
      type=2
    }
    else if(Do_you_have_any_diseases=='1'){
      type=1
    }
          client.post(`addhealthorder`,{
            'name':full_name,
            'age':age,
            'user_id':user_id,
            'national_number':id_number,
            'disease':Do_you_have_any_diseases
          }).then(function(response) {
            var order_id=response.data.order_id
            console.log("responsesss",response)
            let apiUrl = 'https://bolisati1.qiotic.info/app/healthimage';

  
  
            var formData = new FormData();
        
             formData.append("identity", {
               name: 'uiyutesttest5:30.jpg',
               type: 'jpg',
               uri:
             id_image.replace("file://", "")
             });
           
          
             let options = {
               method: 'POST',
               body: formData,
               headers: {
                 Accept: 'application/x-www-from-urlencoded',
                 'Content-Type': 'multipart/form-data',
               },
             };
             console.log("formData",formData)
             fetch(apiUrl, options).then(res=>{
                       console.log('response test',res)
             })
            client.post(`healthquestion`,{
    type:type
            }).then(function(response) {
              console.log("response",response)
           Actions.healthinsurancequestion({questions:response.data.data,order_id:order_id,user_id:user_id})
              // dispatch({
              //   type: HEALTH_INSURANCE_MESSAGE,
              //   payload: {
              //     isError: false,
              //     isSuccess: true,
              //     msg: response.data.message
              //   }
              // });
   /////
  
            }).catch(function(error) {
              console.log("error11111111",error)
              const res = JSON.parse(error.request._response);
              console.log("res",res)
              dispatch({
                type: HEALTH_INSURANCE_MESSAGE,
                payload: {
                  isError: true,
                  isSuccess: false,
                  msg: res.data.message
                }
              });
          
    
            });
            // dispatch({
            //   type: HEALTH_INSURANCE_MESSAGE,
            //   payload: {
            //     isError: false,
            //     isSuccess: true,
            //     msg: response.data.message
            //   }
            // });
 /////

          }).catch(function(error) {
            console.log("error11111111",error)
            const res = JSON.parse(error.request._response);
            console.log("res",res)
            dispatch({
              type: HEALTH_INSURANCE_MESSAGE,
              payload: {
                isError: true,
                isSuccess: false,
                msg: res.message
              }
            });
        
  
          });
        }
      }
    
  };
  //END Go  ACTION

  export const goFromHealthInsuranceQuestion = (questions,order_id,user_id) => {
        return (dispatch) => {
   
              client.post(`addlifequestions`,{
                'questions':questions,
                'order_id':order_id
              }).then(function(response) {
                console.log("response",response)
  Actions.DoneScreen2({user_id:user_id,order_id:order_id})
  setTimeout(() => dispatch({type: RESET_HEALTH_COMPLETELY}), 1000);
  scanned_id_image.full_name=""
  scanned_id_image.id_number=""
  scanned_id_image.skip_id_img=""
  scanned_id_image.date_of_birth=""
  scanned_id_image.scanned=false

                dispatch({
                  type: HEALTH_INSURANCE_MESSAGE,
                  payload: {
                    isError: false,
                    isSuccess: true,
                    msg: "success"
                  }
                });
    
              }).catch(function(error) {
                console.log("error11111111",error)
                const res = JSON.parse(error.request._response);
                console.log("res",res)
                dispatch({
                  type: HEALTH_INSURANCE_MESSAGE,
                  payload: {
                    isError: true,
                    isSuccess: false,
                    msg: res.message
                  }
                });
            
      
              });
            }
          
        
      };