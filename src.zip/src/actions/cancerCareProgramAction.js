import axios from 'axios';
import {GET_CANCER_CARE_PROGRAM_TEXTS,RESET_CANCER_CARE_PROGRAM_MESSAGE,CANCER_CARE_PROGRAM_MESSAGE,RESET_CANCER_CARE_COMPLETELY} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";
import {scanned_id_image} from "../App";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getCancerCareProgramTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_CANCER_CARE_PROGRAM_TEXTS, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION

  //START SHOW/HIDE MODAL
export const resetCancerCareProgramMessage = value => {
    return {type:RESET_CANCER_CARE_PROGRAM_MESSAGE};
  };

  
  //END SHOW/HIDE MODAL



  export const goFromCancerCareProgram = (full_name, id_number,coverage,passport_number,nationality,are_you_jordanian,user_id,message,id_image,passport_image) => {

    return (dispatch) => {
      if (full_name == '' ||coverage=='') {
        dispatch({
          type: CANCER_CARE_PROGRAM_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg: message
          }
        });
     
  
      } 
      // else if(are_you_jordanian==1){
      //   if (id_number == '' ||id_image==null) {
      //     dispatch({
      //       type: CANCER_CARE_PROGRAM_MESSAGE,
      //       payload: {
      //         isError: true,
      //         isSuccess: false,
      //         msg: message
      //       }
      //     });
       
    
      //   } 
      // } 
      // else if(are_you_jordanian==0){
      //   if (passport_number == ''||nationality=='' ||passport_image==null) {
      //     dispatch({
      //       type: CANCER_CARE_PROGRAM_MESSAGE,
      //       payload: {
      //         isError: true,
      //         isSuccess: false,
      //         msg: message
      //       }
      //     });
       
    
      //   } 
      // }
       
      
          else{
         const data={ 
             full_name: full_name,
          id_number: id_number,
          coverage:coverage,
          user_id:user_id,
          passport_number:passport_number,
          are_you_jordanian:are_you_jordanian,
          nationality:nationality
    }
    let apiUrl = 'http://bolisati1.qiotic.info/app/cancerimage';

  
  
      var formData = new FormData();
  if(are_you_jordanian==0){
       formData.append("passportimage", {
         name: 'uiyutesttest5:30.jpg',
         type: 'jpg',
         uri:
         passport_image.replace("file://", "")
       });
      }
      else if(are_you_jordanian==1){
       formData.append("identity", {
        name: 'uiyutesttest5:30.jpg',
        type: 'jpg',
        uri:
        id_image.replace("file://", "")
      });
      }
       let options = {
         method: 'POST',
         body: formData,
         headers: {
           Accept: 'application/x-www-from-urlencoded',
           'Content-Type': 'multipart/form-data',
         },
       };
       console.log("formData",formData)
       fetch(apiUrl, options).then(res=>{
                 console.log('response test',res)
       })
    console.log("data",data)
          client.post(`addcancerorder`,{
            name:full_name,
            national_id:id_number,
            coverage:coverage,
            user_id:user_id,
            are_you_jordanian:are_you_jordanian,
            passport_number:passport_number

          }).then(function(response) {
            console.log("response",response)
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
            // dispatch({
            //   type: CANCER_CARE_PROGRAM_MESSAGE,
            //   payload: {
            //     isError: false,
            //     isSuccess: true,
            //     msg: "success"
            //   }
            // });
            // Actions.insurancecompanies({
            // insuranceCompanies:response.data.data,
            // cancerCarProgramInformation:data,
            // user_id:user_id            
            // });
            Actions.DoneScreen2({user_id:user_id,order_id:response.data.order_id})
            setTimeout(() => dispatch({type: RESET_CANCER_CARE_COMPLETELY}), 1000);
            scanned_id_image.full_name=""
            scanned_id_image.id_number=""
            scanned_id_image.skip_id_img=""
            scanned_id_image.scanned=false

          }).catch(function(error) {
            console.log("error11111111",error)
            const res = JSON.parse(error.request._response);
            dispatch({
              type: CANCER_CARE_PROGRAM_MESSAGE,
              payload: {
                isError: true,
                isSuccess: false,
                msg: res.message
              }
            });
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
  
          });
        }
      }
    
  };
  //END Go  ACTION

