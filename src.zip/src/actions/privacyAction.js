import axios from 'axios';
import {
    GET_PRIVACY,
    GET_USER_AGREEMENT
 } from './types';
import client from '../constants';
import {AsyncStorage} from 'react-native';

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START FETCHING privacy
export const getPrivacy = (lang) => {
  console.log("lang in action",lang)

  console.log("language_id",lang)
  return (dispatch) => {
    // dispatch({type: HOME_LOADING, payload: true})
    client.post(`getallpages`,{
        'language_id':lang,
        'page_id':5
    }).then((response) => {
  console.log("response",response)
      const res = response.data.pages_data;
      dispatch({type: GET_PRIVACY, payload: res})
    //   dispatch({type: HOME_LOADING, payload: false})

    }).catch((error) => {
        console.log("error")
      dispatch({type: GET_PRIVACY, payload: []})
    //   dispatch({type: HOME_LOADING, payload: false})

    })
  }
};
//END FETCHING privacy

export const getUserAgreement = (lang) => {
    console.log("lang in action",lang)
  
    console.log("language_id",lang)
    return (dispatch) => {
    //   dispatch({type: HOME_LOADING, payload: true})
    client.post(`getallpages`,{
        'language_id':lang,
        'page_id':6
    }).then((response) => {
  console.log("response",response)
        const res = response.data.pages_data;
        dispatch({type: GET_USER_AGREEMENT, payload: res})
        // dispatch({type: HOME_LOADING, payload: false})
  
      }).catch((error) => {
          console.log("error")
        dispatch({type: GET_USER_AGREEMENT, payload: []})
        // dispatch({type: HOME_LOADING, payload: false})
  
      })
    }
  };

