import {SHOW_INSURANCE_COMPANY_MODAL,GET_ADDONS,GET_TERMS,GET_COMPANIES_TEXT,LIFE_INSURANCE_MESSAGE,SHOW_PDF_MODAL,SHOW_INSURANCE_COMPANY_MODAL_CAR} from './types';
import client from '../constants';
import { Actions } from 'react-native-router-flux';

  //START SHOW/HIDE MODAL
  export const showInsuranceCompanyModal = value => {
    return {type: SHOW_INSURANCE_COMPANY_MODAL, payload: value};
  };

  export const showInsuranceCompanyModal2 = value => {
    return {type: SHOW_INSURANCE_COMPANY_MODAL_CAR, payload: value};
  };
  //END SHOW/HIDE MODAL

    //START SHOW/HIDE MODAL
    export const showPdfModal = value => {
      return {type: SHOW_PDF_MODAL, payload: value};
    };
    //END SHOW/HIDE MODAL

//START FETCHING ADDONS
export const getAddons = (manufacturers_id,category_id) => {
  console.log("category_id",category_id)
  console.log("manufacturers_id",manufacturers_id)

return (dispatch) => {
  client.post(`companyaddons`,{
    'manufacturers_id':manufacturers_id,
    'categories_id':category_id
  }).then((response) => {
console.log("response addon ",response)
    const res = response.data.data;
    dispatch({type: GET_ADDONS, payload: res})

  }).catch((error) => {
      console.log("error")
    dispatch({type: GET_ADDONS, payload: []})

  })
}
};
//END FETCHING ADDONS

//START FETCHING TERMS
export const getTerms = (manufacturers_id) => {
  return (dispatch) => {
    client.post(`companyinformation?manufacturers_id=${manufacturers_id}`).then((response) => {
  console.log("response of terms",response)
      const res = response.data.data;
      dispatch({type: GET_TERMS, payload: res})
  
    }).catch((error) => {
        console.log("error")
      dispatch({type: GET_TERMS, payload: []})
  
    })
  }
  };
  //END FETCHING TERMS


export const getInsuranceCompaniesText = ({prop, value}) => {
  console.log("value",value)
  return dispatch => {
    dispatch({type: GET_COMPANIES_TEXT, payload: {prop, value}});
  }
};

export const lifeInsuranceOrder=(insuranceCompaanyId,lifeInsuranceInformation,user_id)=>{

  console.log("lifeInsuranceInformation",lifeInsuranceInformation)
  console.log("company_id",insuranceCompaanyId)
  console.log("user_id",user_id)
  return (dispatch) => {
    client.post(`addlifeorder`,{
      'national_id' :lifeInsuranceInformation.id_number,
      'name' :lifeInsuranceInformation.full_name,
      'age' :lifeInsuranceInformation.age,
      'company_id' :insuranceCompaanyId,
      'user_id':user_id,
      'value_of_insurance':lifeInsuranceInformation.value_of_insurance,
      'beneficiaries':lifeInsuranceInformation.beneficiaries
    }).then(function(response) {
      console.log("responseeee",response)
      // alert(response.data.message)
      Actions.DoneScreen({user_id:user_id})

      dispatch({
        type: LIFE_INSURANCE_MESSAGE,
        payload: {
          isError: false,
          isSuccess: true,
          msg: "success"
        }
      });
 
    })
  }
}
export const travelInsuranceOrder=(insuranceCompaanyId,travelInformation,user_id)=>{
  console.log("lifeInsuranceInformation",travelInformation)
  return (dispatch) => {
    client.post(`addtravelorder`,{
      'passport_number' :travelInformation.passport_number,
      'name' :travelInformation.full_name,
      'travel_date' :travelInformation.travel_date,
      'travel_from' :travelInformation.from,
      'travel_to' :travelInformation.to,
      'days_to_stay':travelInformation.days_to_stay,
      'company_id' :insuranceCompaanyId,
      'user_id':user_id
    }).then(function(response) {
      console.log("responseeee",response)
      // alert(response.data.message)
      Actions.DoneScreen({user_id:user_id})


      dispatch({
        type: LIFE_INSURANCE_MESSAGE,
        payload: {
          isError: false,
          isSuccess: true,
          msg: "success"
        }
      });
 
    })
  }
}

export const cancerCareProgramOrder=(insuranceCompaanyId,cancerCarProgramInformation,user_id)=>{
  console.log("cancerCarProgramInformation",cancerCarProgramInformation)
  return (dispatch) => {
    client.post(`addcancerorder`,{
      'name' :cancerCarProgramInformation.full_name,
      'national_id' :cancerCarProgramInformation.id_number,
      'company_id' :insuranceCompaanyId,
      'user_id':user_id
    }).then(function(response) {
      console.log("responseeee",response)
      // alert(response.data.message)
      Actions.DoneScreen({user_id:user_id})


      dispatch({
        type: LIFE_INSURANCE_MESSAGE,
        payload: {
          isError: false,
          isSuccess: true,
          msg: "success"
        }
      });
 
    })
  }
}

export const shippingInsuranceOrder=(insuranceCompaanyId,shippingInformation,user_id)=>{
  console.log("shippingInformation",shippingInformation)
  return (dispatch) => {
    client.post(`addcargoorder`,{
      'name' :shippingInformation.full_name,
      'what_your_shipping' :shippingInformation.what_your_shipping,
      'shipped_date' :shippingInformation.shipped_date,
      'shipped_from' :shippingInformation.shipped_from,
      'shipped_to' :shippingInformation.shipped_to,
      'carrier_name' :shippingInformation.carrier_name,
      'company_id' :insuranceCompaanyId,
      'user_id':user_id
    }).then(function(response) {
      console.log("responseeee",response)
      // alert(response.data.message)
      Actions.DoneScreen({user_id:user_id})


      dispatch({
        type: LIFE_INSURANCE_MESSAGE,
        payload: {
          isError: false,
          isSuccess: true,
          msg: "success"
        }
      });
 
    })
  }
}