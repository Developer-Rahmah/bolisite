import axios from 'axios';
import {
    GET_CATEGORIES,
    HOME_LOADING,
    GET_SHOW_ICON_TEXT,
    GET_CUSTOMER_INFO
 } from './types';
import client from '../constants';
import {AsyncStorage} from 'react-native';

//  const base_URL = 'https://bolisati.qiotic.info/app';
export const getCustomerInfo = (user_id) => {

  return (dispatch) => {
    client.post(`customerinfo?id=${user_id}`).then((response) => {
  console.log("response of customer info",response)
      const res = response.data.data;
      dispatch({type: GET_CUSTOMER_INFO, payload: res})

    })
    .catch((error) => {
        console.log("error")
      dispatch({type: GET_CUSTOMER_INFO, payload: []})

    })
  }
};
//START FETCHING CATEGORIES
export const getCategories = (lang) => {
  // var language_id=0
  // if (lang=='ar'){
  //    language_id=4
  // }
  // else if (lang=='en'){
  //   language_id=1

  // }
  return (dispatch) => {
    dispatch({type: HOME_LOADING, payload: true})
    client.post(`allcategories?language_id=${lang}`).then((response) => {
  console.log("response",response)
      const res = response.data.data;
      dispatch({type: GET_CATEGORIES, payload: res})
      dispatch({type: HOME_LOADING, payload: false})

    }).catch((error) => {
        console.log("error")
      dispatch({type: GET_CATEGORIES, payload: []})
      dispatch({type: HOME_LOADING, payload: false})

    })
  }
};
//END FETCHING CATEGORIES


  export const getShowIconText = (show) => {
    return (dispatch) => {
      // AsyncStorage.setItem("show", show);

      
      // AsyncStorage.getItem("show").then((value) => {
      //   console.log("valueee",value)
      //      });
      dispatch({type: GET_SHOW_ICON_TEXT, payload: show})

        // dispatch({type: GET_LANGUAGE_TEXT, payload: language})
    
    
    
    
    }
    };