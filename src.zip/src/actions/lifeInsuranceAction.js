
import axios from 'axios';
import {GET_LIFE_INSURANCE_TEXTS,RESET_LIFE_INSURANCE_MESSAGE,LIFE_INSURANCE_MESSAGE,MOTHER_SHOW_MODAL,FATHER_SHOW_MODAL,DAUGHTERS_SHOW_MODAL,SISTER_SHOW_MODAL,BROTHER_SHOW_MODAL,WIFE_SHOW_MODAL,HUSBAND_SHOW_MODAL,RESET_LIFE_COMPLETELY} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";
import {scanned_id_image} from "../App";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getLifeInsuranceTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_LIFE_INSURANCE_TEXTS, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION

  //START SHOW/HIDE MODAL
export const resetLifeInsuranceMessage = value => {
    return {type:RESET_LIFE_INSURANCE_MESSAGE};
  };

  
  //END SHOW/HIDE MODAL

   //START SHOW/HIDE MODAL
   export const showMotherModal = value => {
    return dispatch => {
      dispatch({type: MOTHER_SHOW_MODAL, payload: value});
      // dispatch({type: RESET_LIFE_INSURANCE_MESSAGE});
    };
  };
  //END SHOW/HIDE MODAL
     //START SHOW/HIDE MODAL
     export const showFatherModal = value => {
      return dispatch => {
        dispatch({type: FATHER_SHOW_MODAL, payload: value});
        // dispatch({type: RESET_LIFE_INSURANCE_MESSAGE});
      };
    };
    //END SHOW/HIDE MODAL
       //START SHOW/HIDE MODAL
       export const showBrotherModal = value => {
        return dispatch => {
          dispatch({type: BROTHER_SHOW_MODAL, payload: value});
          // dispatch({type: RESET_LIFE_INSURANCE_MESSAGE});
        };
      };
      //END SHOW/HIDE MODAL
            //START SHOW/HIDE MODAL
            export const showHusbandModal = value => {
              return dispatch => {
                dispatch({type: HUSBAND_SHOW_MODAL, payload: value});
                // dispatch({type: RESET_LIFE_INSURANCE_MESSAGE});
              };
            };
            //END SHOW/HIDE MODAL
                 //START SHOW/HIDE MODAL
                 export const showWifeModal = value => {
                  return dispatch => {
                    dispatch({type: WIFE_SHOW_MODAL, payload: value});
                    // dispatch({type: RESET_LIFE_INSURANCE_MESSAGE});
                  };
                };
                //END SHOW/HIDE MODAL
             //START SHOW/HIDE MODAL
             export const showSisterModal = value => {
              return dispatch => {
                dispatch({type: SISTER_SHOW_MODAL, payload: value});
                // dispatch({type: RESET_LIFE_INSURANCE_MESSAGE});
              };
            };
            //END SHOW/HIDE MODAL
                      //START SHOW/HIDE MODAL
                      export const showDaughtersModal = value => {
                        return dispatch => {
                          dispatch({type: DAUGHTERS_SHOW_MODAL, payload: value});
                          // dispatch({type: RESET_LIFE_INSURANCE_MESSAGE});
                        };
                      };
                      //END SHOW/HIDE MODAL

  export const goFromLifeInsurance = (full_name, id_number, age,value_of_insurance,arr,user_id,message,message2,id_image,total) => {
    console.log("full_name",full_name)
    console.log("id_number",id_number)
    console.log("age",age)
    console.log("value_of_insurance",value_of_insurance)
    console.log("id_image",id_image)
console.log("total",total)
    return (dispatch) => {
      if (full_name == '' || id_number == '' || age == ''||value_of_insurance==''||id_image==null) {
        dispatch({
          type: LIFE_INSURANCE_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg: message
          }
        });
     
  
      }  
       else if (total!=100) {
        dispatch({
          type: LIFE_INSURANCE_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg: message2
          }
        });
     
  
      }  
      
          else{
         const data={ 
           full_name: full_name,
          id_number: id_number,
          age:age,
          value_of_insurance:value_of_insurance,
          beneficiaries:arr
    }
    let apiUrl = 'https://bolisati1.qiotic.info/app/lifeimage';

  
  
      var formData = new FormData();
  
       formData.append("identity", {
         name: 'uiyutesttest5:30.jpg',
         type: 'jpg',
         uri:
         id_image.replace("file://", "")
       });
     
    
       let options = {
         method: 'POST',
         body: formData,
         headers: {
           Accept: 'application/x-www-from-urlencoded',
           'Content-Type': 'multipart/form-data',
         },
       };
       console.log("formData",formData)
       fetch(apiUrl, options).then(res=>{
                 console.log('response test',res)
       })
          client.post(`lifeinsurance`).then(function(response) {
            console.log("response",response)
            const res=response
        
            client.post(`lifequestion`).then(function(response) {
                        console.log("response",response)
                     Actions.lifeinsurancequestion({
            insuranceCompanies:res.data.data,
            lifeInsuranceInformation:data,
            user_id:user_id,
            questions:response.data.data,
            id_image:id_image
            })
          
                        // dispatch({
                        //   type: LIFE_INSURANCE_MESSAGE,
                        //   payload: {
                        //     isError: false,
                        //     isSuccess: true,
                        //     msg: response.data.message
                        //   }
                        // });
             /////
            
                      }).catch(function(error) {
                        console.log("error11111111",error)
                        const res = JSON.parse(error.request._response);
                        console.log("res",res)
                        dispatch({
                          type: LIFE_INSURANCE_MESSAGE,
                          payload: {
                            isError: true,
                            isSuccess: false,
                            msg: res.message
                          }
                        });
                    
              
                      });
          

          })
         .catch(function(error) {
            console.log("error11111111",error)
            const res = JSON.parse(error.request._response);
            console.log("res",res)
            dispatch({
              type: LIFE_INSURANCE_MESSAGE,
              payload: {
                isError: true,
                isSuccess: false,
                msg: res.message
              }
            });
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
  
          });
        }
      }
    
  };
  //END Go  ACTION

  export const goFromLifeInsuranceQuestion=(lifeInsuranceInformation,user_id,questions,id_image)=>{
    console.log("id_image",id_image)
  //   let apiUrl = 'https://bolisati1.qiotic.info/app/addlifeorder';

  // var formData = new FormData();
  //  // formData.append('rightImage', {
  //  //   right_uri,
  //  //   name: `rightImage.${fileType2}`,
  //  //   type: `image/${fileType2}`,
  //  // });
  //  // formData2.append('leftImage', {
  //  //   left_uri,
  //  //   name: `leftImage.${fileType}`,
  //  //   type: `image/${fileType}`,
  //  // });
  //  // this.setState({formData : formData2})
  //  // formData.append('frontImage', {
  //  //   front_uri,
  //  //   name: `frontImage.${fileType3}`,
  //  //   type: `image/${fileType3}`,
  //  // });
  //  // formData.append('backImage', {
  //  //   back_uri,
  //  //   name: `backImage.${fileType4}`,
  //  //   type: `image/${fileType4}`,
  //  // });

  //      formData.append('national_id', lifeInsuranceInformation.id_number)
  //      formData.append('name', lifeInsuranceInformation.full_name)
  //      formData.append('age', lifeInsuranceInformation.age)
  //      formData.append('user_id', user_id)
  //      formData.append('value_of_insurance',lifeInsuranceInformation.value_of_insurance)
  //      formData.append('beneficiaries', lifeInsuranceInformation.beneficiaries)
  //      formData.append('questions', questions)
 


  //  formData.append("identity", {
  //    name: 'uiyutesttest5:30.jpg',
  //    type: 'jpg',
  //    uri:
  //      id_image.replace("file://", "")
  //  });
   
  //  let options = {
  //    method: 'POST',
  //    body: formData,
  //    headers: {
  //      Accept: 'application/x-www-from-urlencoded',
  //      'Content-Type': 'multipart/form-data',
  //    },
  //  };
  //  console.log("formData",formData)
  //  fetch(apiUrl, options).then(res=>{
  //            console.log('response test',res)
  //  })

    return (dispatch) => {
      client.post(`addlifeorder`,{
        'national_id' :lifeInsuranceInformation.id_number,
        'name' :lifeInsuranceInformation.full_name,
        'age' :lifeInsuranceInformation.age,
        'user_id':user_id,
        'value_of_insurance':lifeInsuranceInformation.value_of_insurance,
        'beneficiaries':lifeInsuranceInformation.beneficiaries,
        'questions':questions
      }).then(function(response) {
        console.log("responseeee",response)
        // alert(response.data.message)
        Actions.DoneScreen2({user_id:user_id,order_id:response.data.order_id})
        setTimeout(() => dispatch({type: RESET_LIFE_COMPLETELY}), 1000);
        scanned_id_image.full_name=""
        scanned_id_image.id_number=""
        scanned_id_image.skip_id_img=""
        scanned_id_image.date_of_birth=""
        scanned_id_image.scanned=false

        dispatch({
          type: LIFE_INSURANCE_MESSAGE,
          payload: {
            isError: false,
            isSuccess: true,
            msg: "success"
          }
        });
   
      })
    }
  }