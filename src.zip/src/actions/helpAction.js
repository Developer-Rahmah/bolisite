import {GET_HELP_TEXT, START_LOADING, RESET_HELP_MESSAGE, HELP_MESSAGE, RESET_PAGE_COMPLETELY,GET_INFO} from './types';
import client from '../constants';

import axios from 'axios';
import {Actions} from 'react-native-router-flux';
const validate_email = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

//START GETTING INPUTS TEXT ACTION
export const getHelpText = ({prop, value}) => {
  var obj = {
    type: GET_HELP_TEXT,
    payload: {
      prop,
      value
    }
  };
  return obj;
};
//END GETTING INPUTS TEXT ACTION
  //START SHOW/HIDE MODAL
  //START SHOW/HIDE MODAL
  export const resetHelpMessage = value => {
    return {type:RESET_HELP_MESSAGE};
  };
//START CONTACT US PROCESS
export const submitMessage = ( email,subject, msg,user_id,message,message2) => {


  return (dispatch) => {
    if (email == '' || subject == '' || msg == '') {
      dispatch({
        type: HELP_MESSAGE,
        payload: {
          isError: true,
          isSuccess: false,
          msg: message
        }
      });
    } else if (validate_email.test(email) === false) {
      dispatch({
        type: HELP_MESSAGE,
        payload: {
          isError: true,
          isSuccess: false,
          msg: message2
        }
      });
    } 
    else {
      dispatch({
        type: START_LOADING,
        payload: {
          loading: true
        }
      });
      client.post(`help`, {
        "email": email,
        "message": msg,
        user_id:user_id
      }).then(function(response) {
        console.log("response",response)
        const message = response.data.message;
        dispatch({
          type: START_LOADING,
          payload: {
            loading: false
          }
        });
        // dispatch({
        //   type: HELP_MESSAGE,
        //   payload: {
        //     isError: false,
        //     isSuccess: true,
        //     msg: response.data.message
        //   }
        // });
        setTimeout(() => dispatch({type: RESET_PAGE_COMPLETELY}), 1000);

      }).catch(function(error) {
        console.log('error', error.request._response);
        const res = JSON.parse(error.request._response);
        dispatch({
          type: START_LOADING,
          payload: {
            loading: false
          }
        });
        dispatch({
          type: HELP_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg: res.message
          }
        });
        setTimeout(() => dispatch({type: RESET_HELP_MESSAGE}), 1000);
      });

    }
  }
};
//END CONTACT US PROCESS
export const getInfo = () => {
  return (dispatch) => {
    client.post(`appcontact`).then((response) => {
  console.log("response",response)
      const res = response.data.data[0];
      dispatch({type: GET_INFO, payload: res})

    }).catch((error) => {
        console.log("error",error)
      dispatch({type: GET_INFO, payload: []})

    })
  }
};
//END FETCHING CATEGORIES
