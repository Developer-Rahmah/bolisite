import { StyleSheet } from 'react-native';
module.exports  = StyleSheet.create({
profileNameText:{
    color:'#003580',fontSize:20,fontFamily:'TajawalBold0'
},
homeCardItem:{
    backgroundColor:'transparent',marginTop:15
},
otherCardItemStyle:{
    backgroundColor:'transparent',marginTop:10
},
otherTextsStyle:{
    color:'#003580',fontSize:18,fontFamily:'TajawalBold0'
},
profileImageStyle:{
    width: 64.5, height: 64.5, borderRadius: 64.5/2
},
listStyle:{
    marginLeft:100
}
  })