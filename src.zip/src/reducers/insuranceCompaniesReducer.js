import {SHOW_INSURANCE_COMPANY_MODAL,GET_ADDONS,GET_TERMS,SHOW_PDF_MODAL,SHOW_INSURANCE_COMPANY_MODAL_CAR} from '../actions/types';
  
  const INITIAL_STATE = {
      show_insurance_modal:false,
      addons:[],
      terms:[],
      show_pdf_modal:false,
      show_insurance_modal2:false,
     }
  
  export default(state = INITIAL_STATE, action) => {
    switch (action.type) {
        case SHOW_INSURANCE_COMPANY_MODAL:
        return {...state, show_insurance_modal: action.payload};

        case SHOW_INSURANCE_COMPANY_MODAL_CAR:
        return {...state, show_insurance_modal2: action.payload};
        case SHOW_PDF_MODAL:
        return {...state, show_pdf_modal: action.payload};

        case GET_ADDONS:
        return {...state,addons: action.payload
        }

        case GET_TERMS:
        return {...state,terms: action.payload
        }
  
      default:
        return state;
  
    }
  }
  