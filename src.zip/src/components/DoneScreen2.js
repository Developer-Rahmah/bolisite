import React,{Component} from 'react';
import  {ImageBackground,Dimensions,Text,StyleSheet,TouchableOpacity,View,Modal,TouchableWithoutFeedback,Image,Keyboard,StatusBar} from 'react-native';
import {Body,CardItem,Item,Button,Input,Content,List,
  ListItem,Icon,Toast,Drawer} from 'native-base';
import {Spinner} from "./common/Spinner";
import DropdownAlert from 'react-native-dropdownalert';
import PhoneInput from 'react-native-phone-input';
import * as authAction from '../actions/authAction';
import { connect } from 'react-redux';
import {Actions} from "react-native-router-flux";
import {strings} from '../../Locales/i18n';
import {signInButton,signInText} from '../assests/styles/firstPageStyles';
import Header from './headerWithoutArrow';
import SideBar from "./sideBar";
import {uploadButton,licenseImage,continueText,uploadLicenseText,skipButton,skipText,continueButton} from '../assests/styles/drivingLicenseStyles';

import {blueBackgroundColor,buttonStyle,buttonText,cardItemWithMargin,inputStyle,transparentBackground,transparentBorder,phoneInputStyle,centerStyle,touchableOpacityText} from '../theme';
const dimensions=Dimensions.get('window');
import {Updates} from 'expo';
class DoneScreen extends Component{
  closeDrawer = () => {
    this.drawer._root.close();

  };

// a=()=>{
//   console.log("ddddddddddddddddd")
//   Updates.reloadFromCache();

// }
  openDrawer = () => {
    
    this.drawer._root.open();
    setTimeout(() => Keyboard.dismiss());
  };

    render(){
      const {lang}=this.props
      console.log("this.props in Done Screen 2",this.props)
return(
  
  // <View
  //  style={{width:dimensions.width,height:dimensions.height,backgroundColor:"#fafafa"}}
  // >
  <ImageBackground
  source={require("../assests/images/splash–1.png")}
  style={{width: dimensions.width, height: "100%"}}
>
          <Drawer
            type="overlay"
            side="right"
            ref={ref => {
              this.drawer = ref;
            }}
            content={
              <SideBar
                navigator={this._navigator}
                closeDrawer={this.closeDrawer}
              />
            }
            onClose={this.closeDrawer}
            onOpen={this.openDrawer}
            tapToClose={true}
            openDrawerOffset={0.2}
            panCloseMask={0.2}
            closedDrawerOffset={-3}
            styles={drawerStyles}
          >

           <Header
                       openDrawer={this.openDrawer}
                       closeDrawer={this.closeDrawer}
           /> 
 
            <StatusBar backgroundColor="#1e2131" barStyle="light-content" />
  <CardItem style={{marginTop:100,backgroundColor:"transparent"}}>
  <Body style={centerStyle}>
<Image source={require('../assests/images/Artboard–1.png')}
style={{width:100,height:100,paddinTop:100}}
/>

</Body>
</CardItem>
<CardItem style={transparentBackground}>
  <Body style={centerStyle}>
    <Text style={{fontFamily:'TajawalBold0',lineHeight:25}}>{strings('Done_screen.add_order_message',lang)}</Text>
    </Body>
</CardItem>
{lang=='en'?
<CardItem style={transparentBackground}>
  <Body style={centerStyle}>
    <Text style={{fontFamily:'TajawalMedium0',lineHeight:25}}>Your order# {this.props.order_id} has been submitted successfully</Text>
    <Text style={{fontFamily:'TajawalMedium0',lineHeight:25}}> We will contact you within the next 24 hours</Text>

  </Body>
</CardItem>
:
<CardItem style={transparentBackground}>
  <Body style={centerStyle}>
    <Text style={{fontFamily:'TajawalMedium0',lineHeight:25}}>تم إرسال طلبك رقم {this.props.order_id} بنجاح</Text>
    <Text style={{fontFamily:'TajawalMedium0',lineHeight:25}}> سوف نتصل بك خلال ال 24 ساعة القادمة</Text>


  </Body>
</CardItem>
}
          
{/* <CardItem>
  <Body style={centerStyle}>
  <Button style={signInButton}block onPress={() => Actions.home()}>
            <Text style={signInText} >Back To Home</Text>
          </Button>
</Body>
</CardItem> */}
             <CardItem style={[transparentBackground,{marginTop:30}]}>
                 <Button style={continueButton} onPress={() => Actions.home()}>
              
                   <Text style={[continueText,{lineHeight:25}]}>{strings('header.home',lang)}</Text>
               
                   </Button>
                 <Button style={skipButton}onPress={() =>Actions.orderspage({user_id:this.props.user_id})}>
                   <Text style={{color:"#003580",fontSize:16,fontFamily:'TajawalBold0',textAlign:'center',marginTop:7,lineHeight:25}}>{strings('header.orders',lang)}</Text>
                 </Button>
               </CardItem>
</Drawer>
</ImageBackground>


)
    }
}
const styles = StyleSheet.create({
    ImageBackgroundStyle: {
        width:dimensions.width,
        height:dimensions.height
    }
  });

  const drawerStyles = {
    drawer: {shadowOpacity: 0, elevation: 0},
    main: {shadowOpacity: 0, elevation: 0}
  };
// START MAP STATE TO PROPS
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;
    return { lang};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,authAction)(DoneScreen);