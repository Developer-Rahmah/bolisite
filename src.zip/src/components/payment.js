import React, { Component } from 'react';
import {ImageBackground,Dimensions,Modal,Platform,Keyboard,StatusBar,ScrollView} from 'react-native';
import {CardItem,Body,Button,Text,Right,Left, Icon,View,Item, Content,Input,CheckBox,Label,ListItem,Picker,Drawer,Textarea} from 'native-base';
import {transparentBackground,sevicesCardItemStyle,servicesText,buttonText,transparentBorder,inputStyle,labelStyle,pickerStyle2} from '../theme';
import { connect } from 'react-redux';
import * as paymentAction from '../actions/paymentAction';
const dimensions=Dimensions.get('window');
import {strings} from '../../Locales/i18n';
import Header from './header';
import SideBar from "./sideBar";
import { Actions } from 'react-native-router-flux';
class Payment extends Component{
  state = {
    form_submitted: false,
    type:''

  };
  componentWillMount() {
    this.props.getCities();

    if(this.props.insurance_type=="Travel Insurance"&&this.props.lang=='ar'){
      this.setState({type:"تأمين السفر"})
    }else if(this.props.insurance_type=="Travel Insurance"&&this.props.lang=='en'){

      this.setState({type:this.props.insurance_type})

    }
    else if (this.props.insurance_type=="Car Insurance"&&this.props.lang=='ar'){
      this.setState({type:"تأمين السيارات"})

    }
    else if(this.props.insurance_type=="Car Insurance"&&this.props.lang=='en'){

      this.setState({type:this.props.insurance_type})

    }
  }
  closeDrawer = () => {
    this.drawer._root.close();

  };

  

  openDrawer = () => {
    
    this.drawer._root.open();
    setTimeout(() => Keyboard.dismiss());
  };
    changePaymentOnline=(payment_online)=>{
      console.log("here")
        const {show_payment_online_modal,show_payment_upon_delivery_modal,payment_upon_delivery}=this.props
        this.props.getPaymentTexts({
                  prop: "payment_online",
                  value: !payment_online
                })
                this.props.getPaymentTexts({
                  prop: "payment_upon_delivery",
                  value: false
                })
                if(!payment_online)
                this.props.showPaymentOnlineModal(!show_payment_online_modal)
             
    }
    changePaymentUponDelivery=(payment_upon_delivery)=>{
        const {show_payment_upon_delivery_modal,payment_online}=this.props
        this.props.getPaymentTexts({
                  prop: "payment_upon_delivery",
                  value: !payment_upon_delivery
                })
                this.props.getPaymentTexts({
                  prop: "payment_online",
                  value: false
                })
       
                if(!payment_upon_delivery)
                this.props.showPaymentUponDeliveryModal(!show_payment_upon_delivery_modal)
             
    }
    payOnline=()=>{
      const {show_payment_online_modal}=this.props;
      console.log("kjfhjkh")
      this.setState({form_submitted:true})
      this.props.showPaymentOnlineModal(!show_payment_online_modal)
      Actions.DoneScreen({user_id:this.props.user_id})
      this.props.resetTraveloCompletely()
    }
    payDelivery=()=>{

      const {show_payment_upon_delivery_modal,city,address,details}=this.props;
      console.log("kjfhjkh",city)

  
      this.setState({form_submitted:true})
      // this.props.showPaymentUponDeliveryModal(!show_payment_upon_delivery_modal)
      var type2=null
      if(this.state.type=="تأمين السيارات"){
        type2=1
      }
      else if(this.state.type=="تأمين السفر"){
        type2=2
      }
      this.props.goFromPaymentUponDeliveryInformation(city,address,details,this.props.user_id,this.props.order_id,type2,this.props.company_name,this.props.company_name_ar)
      // Actions.DoneScreen({user_id:this.props.user_id})
      this.props.resetTraveloCompletely()
    }
  render(){
      console.log("this.props in payment",this.props)
  const{payment_online,payment_upon_delivery,show_payment_online_modal,show_payment_upon_delivery_modal,data,months,payment_info_name,payment_info_credit_Card,payment_info_cvv,payment_info_ExMonth,payment_info_ExYear,lang,city,address,details,cities}=this.props;
  const {form_submitted}=this.state
    return(

      <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
          <Drawer
            type="overlay"
            side="right"
            ref={ref => {
              this.drawer = ref;
            }}
            content={
              <SideBar
                navigator={this._navigator}
                closeDrawer={this.closeDrawer}
              />
            }
            onClose={this.closeDrawer}
            onOpen={this.openDrawer}
            tapToClose={true}
            openDrawerOffset={0.2}
            panCloseMask={0.2}
            closedDrawerOffset={-3}
            styles={drawerStyles}
          >

           <Header
                       openDrawer={this.openDrawer}
                       closeDrawer={this.closeDrawer}
           /> 
 
            <StatusBar backgroundColor="#1e2131" barStyle="light-content" />
        <Content>
        <CardItem style={[sevicesCardItemStyle, {width: dimensions.width}]}>
        {lang=='ar'?
          <Right>
            <Text style={servicesText}>{strings('payment.payment',lang)}</Text>
          </Right>
          :
          <Left>
            <Text style={servicesText}>{strings('payment.payment',lang)}</Text>

          </Left>
        }
        </CardItem>
        {/* <CardItem style={transparentBackground}>
          <Item style={transparentBorder}> 
            <Input
              color="#fff"
              onChangeText={value =>this.props.getUserText({prop:'password',value})}
              value ={this.props.full_name}
              placeholder ={strings('payment.name_of_insured',lang)}
              style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=="ar"?"right":"left"}]}
            />
              </Item>
            </CardItem> */}

             <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                 <View style={{flexDirection:'column',width:'100%'}}>
                 <Label style={[labelStyle,{textAlign:lang=='ar'?"right":"left",color:"#171717"}]}>{strings('payment.name_of_insured',lang)}</Label>
                   <Input
                    disabled={true}
                     color="#fff"
                     value ={this.props.full_name}
                    //  placeholder ={strings('carInformation.id_number',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left",borderBottomColor:form_submitted && this.props.full_name == ""? "red": "#171717",borderBottomWidth:form_submitted && this.props.full_name == "" ? 1 : 0}]}
                    //  onChangeText={value =>this.props.getCarInformationTexts({prop:"full_name",value})}
                   />
                   </View>
                 </Item>
               </CardItem>
       
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                 <View style={{flexDirection:'column',width:'100%'}}>
                 <Label style={[labelStyle,{textAlign:lang=='ar'?"right":"left",color:"#171717"}]}>{strings('payment.insurance_type',lang)}</Label>
                   <Input
                    disabled={true}
                     color="#fff"
                     value ={this.state.type}
                    //  placeholder ={strings('carInformation.id_number',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                    //  onChangeText={value =>this.props.getCarInformationTexts({prop:"full_name",value})}
                   />
                   </View>
                 </Item>
               </CardItem>
            {/* <CardItem style={transparentBackground}>
          <Item style={transparentBorder}> 
            <Input
              color="#fff"
              onChangeText={value =>this.props.getUserText({prop:'password',value})}
              value =""
              placeholder ={strings('payment.insurance_company',lang)}
              style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=="ar"?"right":"left"}]}
            />
              </Item>
            </CardItem> */}
        {this.props.addons.length>0&&this.props.addons!=null?
        <View>
            <View style={{marginRight:lang=='ar'?30:null,marginLeft:lang=='en'?30:null,marginTop:20}}>
              <Text style={{fontSize:16,textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBlack0'}}>{strings('payment.Additional_Services',lang)}</Text>     
            </View>
            {this.props.addons.map((addon, index) => {
                            


                      return (
       <View style={{marginRight:30,marginTop:15,marginLeft:lang=='en'?30:null}} key={addon.id}>
          <Text style={{fontSize:14,textAlign:lang=='ar'?"right":"left",color:"gray",fontFamily:'TajawalBold0'}}> {addon.addon_name}</Text>     
          </View> 
                      )
            })}
            {/* <View style={{marginRight:30,marginTop:15}}>
              <Text style={{fontSize:14,textAlign:lang=='ar'?"right":"left",color:"gray",fontFamily:'TajawalBold0'}}> لوريم ايبسوم دولار سيت أميت </Text>     
            </View> */}
            </View>
            :null}
             {Platform.OS=="ios"||(Platform.OS=="android"&&lang=='en')?

            <CardItem style={[transparentBackground,{marginTop:40,direction:lang=='ar'?"rtl":"ltr"}]} bordered>
              <Left>
                 <Text style={{fontSize:16,textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBlack0'}}>{strings('payment.total',lang)}</Text>
              </Left>
              <Right>
                 <Text style={{fontSize:16,textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBlack0'}}>{this.props.total} JOD</Text>
              </Right>
            </CardItem>
            :
            <CardItem style={[transparentBackground,{marginTop:40,flexDirection:"row-reverse"}]} bordered>
            <Right>
               <Text style={{fontSize:16,textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBlack0'}}>{strings('payment.total',lang)}</Text>
            </Right>
            <Left>
               <Text style={{fontSize:16,textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBlack0'}}>{this.props.total} JOD</Text>
            </Left>
          </CardItem>
          }
                       {Platform.OS=="ios"||(Platform.OS=="android"&&lang=='en')?

            <CardItem style={[transparentBackground,{direction:lang=='ar'?"rtl":"ltr"}]}>
                 <Item style={transparentBorder}> 
                 <View style={{flexDirection: 'row',justifyContent: 'space-between',width:'100%',alignItems:'center'}}>
                 <View style={{flexDirection: 'row',width:'50%'}}>
                 <CheckBox
                        style={{marginRight:15,borderRadius:30,justifyContent:'center',alignItems:'center',paddingRight:4}}
                        checked={payment_online}
                        color="#003580"
                        onPress={() =>this.changePaymentOnline(payment_online)
                      
                    }
                      /> 
                      <Text style={{fontFamily:"TajawalMedium0",fontSize:12,marginTop:5}}>{strings('payment.Online_payment',lang)}</Text>
                 </View>
                 <View style={{flexDirection: 'row',width:'50%'}}>
                 <CheckBox
                        style={{marginRight:15,borderRadius:30,justifyContent:'center',alignItems:'center',paddingRight:4}}
                        checked={payment_upon_delivery}
                        color="#003580"
                        onPress={() =>this.changePaymentUponDelivery(payment_upon_delivery)
                
                          }
                      /> 
                       <Text style={{fontFamily:"TajawalMedium0",fontSize:12,marginTop:5}}>{strings('payment.Payment_upon_delivery',lang)}</Text>
          
                 </View>
                 </View>
         
                 </Item>
               </CardItem>
           :
           <CardItem style={[transparentBackground,{flexDirection:"row-reverse"}]}>
           <Item style={transparentBorder}> 
           <View style={{flexDirection: 'row',justifyContent: 'space-between',width:'100%',alignItems:'center'}}>
           <View style={{flexDirection: 'row',width:'50%',marginLeft:50}}>
           <Text style={{fontFamily:"TajawalMedium0",fontSize:12,marginTop:5}}>{strings('payment.Payment_upon_delivery',lang)}</Text>

           <CheckBox
                  style={{marginRight:15,borderRadius:30,justifyContent:'center',alignItems:'center',paddingRight:4}}
                  checked={payment_upon_delivery}
                  color="#003580"
                  onPress={() =>this.changePaymentUponDelivery(payment_upon_delivery)
          
                    }
                /> 
    
           </View>
           <View style={{flexDirection: 'row',width:'50%'}}>
           <Text style={{fontFamily:"TajawalMedium0",fontSize:12,marginTop:5}}>{strings('payment.Online_payment',lang)}</Text>

           <CheckBox
                  style={{marginRight:15,borderRadius:30,justifyContent:'center',alignItems:'center',paddingRight:4}}
                  checked={payment_online}
                  color="#003580"
                  onPress={() =>this.changePaymentOnline(payment_online)
                
              }
                /> 
           </View>
       
           </View>
   
           </Item>
         </CardItem>
                        }
    
            <Modal
            visible={show_payment_online_modal}
            animationType={"slide"}
            onRequestClose={() =>
              this.props.showPaymentOnlineModal(!show_payment_online_modal)
            }
            supportedOrientations={[
              "portrait",
              "portrait-upside-down",
              "landscape",
              "landscape-left",
              "landscape-right"
            ]}
            transparent
          >
         <ScrollView
            ref={ref => {
              this._scrollView = ref;
            }}>
              <View style={{backgroundColor:'rgba(0,0,0,0.50)',position:'relative',flex:1,justifyContent:'center',marginTop:30}}>
                <View style={{  borderWidth:1,borderRadius:5,borderColor:'#e3e3e3',padding:0,backgroundColor:'#fff',marginLeft:15,marginRight:15}}>
                <CardItem>
                <Left>
                <Icon style={{color:'#003580',fontSize:25}} name="md-close"   onPress={() =>this.props.showPaymentOnlineModal(!show_payment_online_modal)} />
            </Left>
                </CardItem>
                    {/* <CardItem>
                  <Label style={{
                    fontFamily:"TajawalRegular0",textAlign: lang == "ar" ? "right" : "left",
                      color:
                        form_submitted && payment_info_credit_Card == ""
                          ? "red"
                          : "#171717"
                    }}> {strings('payment.Card_Number',lang)}</Label>
                  </CardItem> */}
                               <CardItem style={transparentBackground}>
                <Item style={transparentBorder}>
                  <View style={{flexDirection: "column", width: "100%"}}>
                    <Label
                      style={[
                        labelStyle,
                        {
                          textAlign: lang == "ar" ? "right" : "left",
                          color:
                          form_submitted && payment_info_credit_Card == ""
                            ? "red"
                            : "#171717"                        }
                      ]}
                    >
                     {strings('payment.Card_Number',lang)}
                    </Label>
      
                  </View>
                </Item>
              </CardItem>
                  <CardItem>
                  <Item regular>
                  <Input
                  style={{fontFamily:'TajawalRegular0',textAlign: lang == "ar" ? "right" : "left",
                }}
                    maxLength={16}
                    autoCorrect={false}
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_credit_Card",
                        value
                      })
                    }
                    value={payment_info_credit_Card}
                    placeholder="1234   5678   3456   2456"
                    placeholderTextColor="gray"
                  />
                </Item>
                  </CardItem>
                  {/* <CardItem>
                  <Label style={{fontFamily:"TajawalRegular0",textAlign: lang == "ar" ? "right" : "left",
                      color:
                        form_submitted && payment_info_name == ""
                          ? "red"
                          : "#171717"
                    }}> {strings('payment.CARDHOLDER_NAME',lang)}</Label>
         
                  </CardItem> */}
                                  <CardItem style={transparentBackground}>
                <Item style={transparentBorder}>
                  <View style={{flexDirection: "column", width: "100%"}}>
                    <Label
                      style={[
                        labelStyle,{textAlign: lang == "ar" ? "right" : "left",color:form_submitted && payment_info_name == ""? "red": "#171717"                        }
                      ]}
                    >
                     {strings('payment.CARDHOLDER_NAME',lang)}
                    </Label>
      
                  </View>
                </Item>
              </CardItem>
                  <CardItem>
            <Item regular>
              <Input
              style={{fontFamily:'TajawalRegular0',textAlign: lang == "ar" ? "right" : "left"}}
                autoCorrect={false}
                onChangeText={value =>
                  this.props.getPaymentTexts({
                    prop: "payment_info_name",
                    value
                  })
                }
                value={payment_info_name}
                placeholder="e.g John Doe"
                placeholderTextColor="gray"
              />
            </Item>
                  </CardItem>
                  {/* <CardItem style={{direction:lang=='ar'?"rtl":"ltr"}}>
                  <Label style={{
                 fontFamily:"TajawalRegular0",
                      color:
                        form_submitted && payment_info_ExMonth== "" &&payment_info_ExYear==""
                          ? "red"
                          : "#171717"
                    }}>{strings('payment.EXPIRE_DATE',lang)}</Label>
                  </CardItem> */}
                                        <CardItem style={transparentBackground}>
                <Item style={transparentBorder}>
                  <View style={{flexDirection: "column", width: "100%"}}>
                    <Label
                      style={[
                        labelStyle,{textAlign: lang == "ar" ? "right" : "left",color:form_submitted &&payment_info_ExMonth== "" &&payment_info_ExYear==""? "red": "#171717"                        }
                      ]}
                    >
                     {strings('payment.EXPIRE_DATE',lang)}
                    </Label>
      
                  </View>
                </Item>
              </CardItem>
                  <CardItem>
                  <Item style={transparentBorder}>
                  {lang=='ar'?
                  <Right>

                  <Picker
                    mode="dropdown"
              
                    iosHeader={strings('payment.Expiry_Month',lang)}
                    placeholder={strings('payment.Expiry_Month',lang)}
                    iosIcon={<Icon name="ios-arrow-down" />}
                    style={{fontFamily:'TajawalRegular0',direction:lang=='ar'?'rtl':'ltr',width:170,height:45}}
                    selectedValue={payment_info_ExMonth}
                    placeholderTextColor={
                      form_submitted && payment_info_ExMonth == ""
                        ? "red"
                        : "gray"
                    }
                    onValueChange={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_ExMonth",
                        value
                      })
                    }
                  >
                    {months.map((item, index) => {
                      return (
                        <Picker.Item
                          key={item.id}
                          style={{fontFamily:'TajawalRegular0',}}
                          label={item.month}
                          value={item.value}
                        />
                      );
                    })}
                  </Picker>
                  </Right>
                  :
                  <Left>

<Picker
                    mode="dropdown"
              
                    iosHeader={strings('payment.Expiry_Month',lang)}
                    placeholder={strings('payment.Expiry_Month',lang)}
                    iosIcon={<Icon name="ios-arrow-down" />}
                    style={{fontFamily:'TajawalRegular0',direction:lang=='ar'?'rtl':'ltr',width:180,height:45}}
                    selectedValue={payment_info_ExMonth}
                    placeholderTextColor={
                      form_submitted && payment_info_ExMonth == ""
                        ? "red"
                        : "gray"
                    }
                    onValueChange={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_ExMonth",
                        value
                      })
                    }
                  >
                    {months.map((item, index) => {
                      return (
                        <Picker.Item
                          key={item.id}
                          style={{fontFamily:'TajawalRegular0',}}
                          label={item.month}
                          value={item.value}
                        />
                      );
                    })}
                  </Picker>
                  </Left>
                  }
            </Item>
                  </CardItem>
                  <CardItem>
            <Item regular>
            <Input
                  style={{fontFamily:'TajawalRegular0',textAlign: lang == "ar" ? "right" : "left"}}
                    maxLength={4}
                    autoCorrect={false}
                    placeholder={strings('payment.Expiry_Year',lang)}
                    placeholderTextColor={
                      form_submitted && payment_info_ExYear == ""
                        ? "red"
                        : "gray"
                    }
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_ExYear",
                        value
                      })
                    }
                    value={payment_info_ExYear}
                  />
            </Item>
                  </CardItem>

        
            {/* <CardItem style={{direction:lang=='ar'?"rtl":"ltr"}}>
              <Label style={{fontFamily:"TajawalRegular0",
                      color:
                        form_submitted && payment_info_cvv == ""
                          ? "red"
                          : "#171717"
                    }}> CVV</Label>
            </CardItem> */}
                                          <CardItem style={transparentBackground}>
                <Item style={transparentBorder}>
                  <View style={{flexDirection: "column", width: "100%"}}>
                    <Label
                      style={[
                        labelStyle,{textAlign: lang == "ar" ? "right" : "left",color:form_submitted &&payment_info_cvv==""? "red": "#171717"                        }
                      ]}
                    >
                    CVV
                    </Label>
      
                  </View>
                </Item>
              </CardItem>
             <CardItem>
                 <Item regular>
                 <Input
                 style={{fontFamily:'TajawalRegular0',textAlign: lang == "ar" ? "right" : "left"}}
                    maxLength={3}
                    placeholder="e.g 123"
                    placeholderTextColor={
                      form_submitted && payment_info_cvv == ""
                        ? "red"
                        : "gray"
                    }
                    autoCorrect={false}
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_cvv",
                        value
                      })
                    }
                    value={payment_info_cvv}
                  />
                 </Item>
             </CardItem>
             <CardItem>
               {lang=='en'?
                    <Left>
                    <CheckBox
                        style={{marginRight:15,borderRadius:50,justifyContent:'center',alignItems:'center',paddingRight:4}}
                        checked={false}
                        color="#003580"
                    
                      />
                    <Text style={{fontFamily:"TajawalRegular0"}}>{strings('payment.SAVEـCARD',lang)}</Text>
                    </Left>
                    :
                    <Left style={{marginLeft:180}}>
                    <Text style={{fontFamily:"TajawalRegular0"}}>{strings('payment.SAVEـCARD',lang)}</Text>
                    <CheckBox
                        style={{marginRight:15,borderRadius:50,justifyContent:'center',alignItems:'center',paddingRight:4}}
                        checked={false}
                        color="#003580"
                    
                      />
                    </Left>
               }
                  </CardItem>

              
                        <ListItem style={{borderBottomWidth: 0}}>
                    <Body>
                    <Button style={{backgroundColor:"#003580"}}block onPress={this.payOnline}>
                      <Text style={buttonText}>{strings('payment.Pay_now',lang)}</Text>
                    </Button>
                    </Body>
                  </ListItem>
                </View>
              </View>
              </ScrollView>
          </Modal>
          {/* ***************** */}
          <Modal
            visible={show_payment_upon_delivery_modal}
            animationType={"slide"}
            onRequestClose={() =>
              this.props.showPaymentUponDeliveryModal(!show_payment_upon_delivery_modal)
            }
            supportedOrientations={[
              "portrait",
              "portrait-upside-down",
              "landscape",
              "landscape-left",
              "landscape-right"
            ]}
            transparent
          >
             {/* <TouchableWithoutFeedback
              onPress={() => this.props.showPaymentUponDeliveryModal(!show_payment_upon_delivery_modal)}
            > */}
            {/* <ScrollView
            ref={ref => {
              this._scrollView = ref;
            }}
          > */}
           <ScrollView
            ref={ref => {
              this._scrollView = ref;
            }}
            height="100%"
          > 
              <View style={{backgroundColor:'rgba(0,0,0,0.50)',position:'relative',flex:1,justifyContent:'center',marginTop:Platform.OS=="ios"?60:30}}>
                <View style={{  borderWidth:1,borderRadius:5,borderColor:'#e3e3e3',padding:0,backgroundColor:'#fff',marginLeft:15,marginRight:15}}>
                <CardItem>
                <Left>
                <Icon style={{color:'#003580',fontSize:25}} name="md-close"  onPress={() => this.props.showPaymentUponDeliveryModal(!show_payment_upon_delivery_modal)} />
            </Left>
                </CardItem>
                {/* <CardItem>
                  <Label style={{fontFamily:"TajawalRegular0",textAlign:lang=="ar"?"right":"left"}}>{strings('payment.city',lang)}</Label>
                  </CardItem> */}
                                            <CardItem style={transparentBackground}>
                <Item style={transparentBorder}>
                  <View style={{flexDirection: "column", width: "100%"}}>
                    <Label
                      style={[
                        labelStyle,{textAlign: lang == "ar" ? "right" : "left",color:"#171717"                        }
                      ]}
                    >
                    {strings('payment.city',lang)}
                    </Label>
      
                  </View>
                </Item>
              </CardItem>
                  <CardItem>
                  <Item regular>
                  {/* <Input
                  style={{fontFamily:'TajawalRegular0',textAlign:lang=="ar"?"right":"left",borderBottomColor:form_submitted && city == ""? "red": "#171717",borderBottomWidth:form_submitted && city == "" ? 1 : 0}}
                    maxLength={16}
                    autoCorrect={false}
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "city",
                        value
                      })
                    }
                    value={city}
                    placeholderTextColor="gray"
                  /> */}
                  <Picker
                        mode="dropdown"
                        iosHeader={strings('payment.city',lang)}
                        // placeholder={strings('carInformation.car_type',lang)}
                        iosIcon={<Icon name="arrow-down" />}
                        placeholderStyle={{color: "#9B9B9B"}}
                        style={
                          {
                            borderRadius:5,marginBottom:5,backgroundColor:"#fff",height:45,width:"65%",

                            direction: lang == "ar" ? "rtl" : "ltr",
                            borderBottomColor:
                              form_submitted && city == ""
                                ? "red"
                                : "#171717",
                            borderBottomWidth:
                              form_submitted && city == "" ? 1 : 0
                          }
                        }
                        selectedValue={city}
                        onValueChange={value =>
                          this.props.getPaymentTexts({
                            prop: "city",
                            value
                          })
                        }
                      >
                        {cities.map((item, index) => {
                          return (
                            <Picker.Item
                              key={item.zone_id}
                              label={item.zone_name}
                              value={item.zone_name}
                            />
                          );
                        })}
                      </Picker>
                </Item>
                  </CardItem>
                    {/* <CardItem>
                  <Label style={{fontFamily:"TajawalRegular0",textAlign:lang=="ar"?"right":"left"}}>{strings('payment.address',lang)}</Label>
                  </CardItem> */}
                                                  <CardItem style={transparentBackground}>
                <Item style={transparentBorder}>
                  <View style={{flexDirection: "column", width: "100%"}}>
                    <Label
                      style={[
                        labelStyle,{textAlign: lang == "ar" ? "right" : "left",color:"#171717"                        }
                      ]}
                    >
                    {strings('payment.address',lang)} 
                    </Label>
      
                  </View>
                </Item>
              </CardItem>
                  <CardItem>
                  <Item regular>
                  <Input
                  style={{fontFamily:'TajawalRegular0',textAlign:lang=="ar"?"right":"left",borderBottomColor:form_submitted && address == ""? "red": "#171717",borderBottomWidth:form_submitted && address == "" ? 1 : 0}}
                    maxLength={16}
                    autoCorrect={false}
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "address",
                        value
                      })
                    }
                    value={address}
                    // placeholder="Address"
                    placeholderTextColor="gray"
                  />
                </Item>
                  </CardItem>
                  {/* <CardItem>
                  <Label style={{fontFamily:"TajawalRegular0",textAlign:lang=="ar"?"right":"left"}}>{strings('payment.details',lang)}</Label>
                  </CardItem> */}
                                                    <CardItem style={transparentBackground}>
                <Item style={transparentBorder}>
                  <View style={{flexDirection: "column", width: "100%"}}>
                    <Label
                      style={[
                        labelStyle,{textAlign: lang == "ar" ? "right" : "left",color:"#171717"                        }
                      ]}
                    >
                    {strings('payment.details',lang)}                    </Label>
      
                  </View>
                </Item>
              </CardItem>
                  <CardItem>
                  <Item regular>

                  <Textarea  style={{height: 100, width:'100%',fontSize:18,fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left",borderBottomColor:form_submitted && details == ""? "red": "#171717",borderBottomWidth:form_submitted && details == "" ? 1 : 0}}
                       value={details}
                       onChangeText={(value) => this.props.getPaymentTexts({prop:'details',value})}
                        autoCorrect={false}
                      />
                      </Item>
                  </CardItem>
                  <ListItem style={{borderBottomWidth: 0}}>
                    <Body>
                    <Button style={{backgroundColor:"#003580"}}block onPress={this.payDelivery}>
                      <Text style={buttonText}>{strings('payment.send',lang)}</Text>
                    </Button>
                    </Body>
                  </ListItem>
                </View>
              </View>
              {/* </TouchableWithoutFeedback> */}
              {/* </ScrollView> */}
              </ScrollView>
          </Modal>
        </Content>
        </Drawer>
      </ImageBackground>
        )
    }
}
const drawerStyles = {
  drawer: {shadowOpacity: 0, elevation: 0},
  main: {shadowOpacity: 0, elevation: 0}
};
// START MAP STATE TO PROPS
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;
    const { payment_online,payment_upon_delivery,show_payment_online_modal,show_payment_upon_delivery_modal,months,payment_info_name,payment_info_credit_Card,payment_info_cvv,payment_info_ExMonth,payment_info_ExYear,address,city,details,cities} = state.paymentReducer;
    return {  payment_online,payment_upon_delivery,show_payment_online_modal,show_payment_upon_delivery_modal,months,payment_info_name,payment_info_credit_Card,payment_info_cvv,payment_info_ExMonth,payment_info_ExYear,lang,address,city,details,cities};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,paymentAction)(Payment);