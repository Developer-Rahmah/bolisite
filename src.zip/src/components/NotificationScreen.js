import React, { Component } from 'react';
import {ImageBackground,Dimensions,Platform,View,Keyboard,StatusBar,Modal,TouchableOpacity} from 'react-native';
import {CardItem,Body,Text,Right,Left,Card, Content,Drawer, Button,Icon,Label,CheckBox,Item,Picker,ListItem,Radio} from 'native-base';
import * as notificationsPageAction from '../actions/notificationAction'
import { connect } from 'react-redux';
import {VerticalWrapper} from "./common/VerticalWrapper";
import {Spinner} from "./common/Spinner";
import Header from './header';
import SideBar from "./sideBar";
import {centerStyle,buttonStyle,transparentBackground,labelStyle,transparentBorder,pickerStyle2,buttonText} from '../theme';
import {strings} from '../../Locales/i18n';

const dimensions=Dimensions.get('window');
class NotificationScreen extends Component{
  constructor(props) {
    super(props);
    this.state = {
      orderId: null,
      form_submitted: false,
      isReasonChecked: false,
      

      reason:''


    };
  }
  componentWillMount() {
    this.props.getReasons();

const {user_id,lang}=this.props
var language_id=null
if(lang=='ar')
{
  language_id=4
}
else{
  language_id=1
}
    this.props.getNotifications(user_id,language_id);

    
  }
  closeDrawer = () => {
    this.drawer._root.close();

  };

  

  openDrawer = () => {
    
    this.drawer._root.open();
    setTimeout(() => Keyboard.dismiss());
  };
  count = (value) => {
  
    console.log("value",value)
    value.isChecked = !value.isChecked;
    this.setState({isReasonChecked: value.isChecked});
    

  };
  goToAnotherPage=(reason)=>{
    var language_id
    if(this.props.lang=='ar')
    {
      language_id=4
    }
    else{
      language_id=1
    }
console.log("reason",reason)
console.log("orderId",this.state.orderId)
this.props.sendReason(this.state.orderId,reason,this.props.user_id,language_id)
  }

  showModal = (id) => {
 const {show_order_modal}=this.props;
    this.setState({orderId: id});
   
    // this.props.getTerms(id);
    this.props.showCancelOrderModal(!show_order_modal);

  };
    render(){
      const {notifications,notifications_loading,lang,show_order_modal,reasons}=this.props
      const {reason}=this.state;
      console.log("notifications",notifications)
      const {form_submitted}=this.state
console.log("reasons",reasons)

        return(

            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>

<Drawer
            type="overlay"
            side="right"
            ref={ref => {
              this.drawer = ref;
            }}
            content={
              <SideBar
                navigator={this._navigator}
                closeDrawer={this.closeDrawer}
              />
            }
            onClose={this.closeDrawer}
            onOpen={this.openDrawer}
            tapToClose={true}
            openDrawerOffset={0.2}
            panCloseMask={0.2}
            closedDrawerOffset={-3}
            styles={drawerStyles}
          >

           <Header
                       openDrawer={this.openDrawer}
                       closeDrawer={this.closeDrawer}
           /> 
 
            <StatusBar backgroundColor="#1e2131" barStyle="light-content" />
<Content>
{!notifications_loading?
              (Object.keys(notifications).length > 0)?
              <Card style={{  paddingLeft: 10,paddingRight: 10,marginBottom:0,elevation:0,shadowOpacity: 0,borderBottomWidth:0,  backgroundColor: "transparent",borderColor:"transparent"
            }}>
                {notifications.map((order, index) => {
                  return (
                    order.length>0?

                    //  order.length>0?

                      <Card style={{ flex: 1,
                          marginBottom: 20,
                          borderColor:"transparent",
                          backgroundColor:"#003580",
                          borderRadius:10,
                          borderWidth:0,
                          shadowOpacity:0,
                          elevation:0,
                        padding:Platform.OS === 'android'?2:0,
                      shadowRadius:5}}
                      >
                      {(Object.keys(order).length > 0)?
                      order.map((order1, index) => {
                        console.log("order1",order1)
                          return(
                            <Card style={{ flex: 1,
                                marginBottom: 20,
                                backgroundColor:"#003580",
                                borderColor:"transparent",
                                borderRadius:10,
                                borderWidth:1,
                                shadowOpacity:0,
                                elevation:0,
                              padding:Platform.OS === 'android'?2:0,
                            shadowRadius:5}}
                            >
                        <CardItem style={{direction:lang=='ar'?'rtl':'ltr'}}>
                            <Left>
                                <Text style={{fontFamily:'TajawalBold0',lineHeight:25}}>{strings("order_page.insurance_type", lang)}</Text>
                            </Left>
                              <Right>
                            <Text style={{fontFamily:'TajawalMedium0'}}>
                              {order1.Insurance_Type}
                            </Text>
                            </Right>
                        </CardItem>
                        <CardItem style={{direction:lang=='ar'?'rtl':'ltr'}}>
                            <Left >
                                <Text style={{fontFamily:'TajawalBold0',lineHeight:25}}>{strings("order_page.order_id", lang)}</Text>
                            </Left>
                              <Right>
                            <Text style={{fontFamily:'TajawalMedium0'}}>
                              {order1.id}
                            </Text>
                            </Right>
                        </CardItem>
                        <CardItem style={{direction:lang=='ar'?'rtl':'ltr'}}>
                            <Left>
                                <Text style={{fontFamily:'TajawalBold0',lineHeight:25}}>{strings("order_page.created_at", lang)}</Text>
                            </Left>
                              <Right>
                            <Text style={{fontFamily:'TajawalMedium0'}}>
                              {order1.created_at}
                            </Text>
                            </Right>
                        </CardItem>
                        <CardItem style={{direction:lang=='ar'?'rtl':'ltr'}}>
                            <Left>
                                <Text style={{fontFamily:'TajawalBold0',lineHeight:25}}>{strings("order_page.status", lang)}</Text>
                            </Left>
                              <Right>
                            <Text style={{fontFamily:'TajawalMedium0'}}>
                              {order1.orders_status_name}
                            </Text>
                            </Right>
                        </CardItem>
                        {(!order1.orders_status_name=="Cancel"||!order1.orders_status_name=="Cancel Request")||order1.orders_status_name=="Pending"?
                        <CardItem>
                          <Body style={[centerStyle,{marginLeft:lang=='en'?85:100}]}>
                            <Button style={buttonStyle} onPress={() =>this.showModal(order1.id)} >
                              <Text style={{fontFamily:'TajawalMedium0',lineHeight:25}}>{strings("Done_screen.cancel_request", lang)}</Text>
                            </Button>
                          </Body>
                        </CardItem>
:null}
</Card>

                          )

                      })
                      :null}
                      </Card>
                           :null
// :null
                  );
             
                })}

              </Card>
              :
              <Card style={{  backgroundColor:'transparent',borderColor:'transparent',shadowOpacity:0,elevation:0}}>
              <VerticalWrapper style={{marginTop:230}}>
                {/* <Image source={require('../../assests/images/no-results-found.png')} style={{width:120,height:120}} /> */}
                <Text style={{  marginTop:10,marginBottom:10,color:"#003580",fontFamily:'TajawalBold0'}}>there's no orders yet...</Text>
              </VerticalWrapper>
            </Card>
              
     :
     <CardItem style={{backgroundColor:'tranparent'}} >
     <Body>
       <View style={{  alignItems:'center',alignSelf:'center',justifyContent:'center',marginTop:250}}>
         <Spinner Size="large" color="#003580" />
       </View>
     </Body>
    </CardItem>
     }
      
              
               
      <Modal
                visible={show_order_modal}
                animationType={"slide"}
                onRequestClose={() => this.props.showCancelOrderModal(!show_order_modal)}
                supportedOrientations={[
                  "portrait",
                  "portrait-upside-down",
                  "landscape",
                  "landscape-left",
                  "landscape-right"
                ]}
                transparent
              >
               <View
                style={{
                  backgroundColor: "rgba(0,0,0,0.50)",
                  position: "relative",
                  flex: 1,
                  justifyContent: "center"
                }}
              >
                <View
                  style={{
                    borderWidth: 1,
                    borderRadius: 5,
                    borderColor: "#e3e3e3",
                    padding: 0,
                    backgroundColor: "#fff",
                    marginLeft: 15,
                    marginRight: 15
                  }}
                >
                
                    <View style={{marginLeft: 10}}>
                      <Icon
                        style={{
                          color: "#003580",
                          fontSize: 25,
                          alignSelf: "flex-start"
                        }}
                        onPress={() => this.props.showCancelOrderModal(!show_order_modal)}
                        name="md-close"
                      />
                    </View>
                    {/* <View style={{marginRight:lang=='ar'?20:null,marginLeft:lang=='en'?20:null,marginTop:20}}>
          
          <Label style={{textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBold0'}}>djhkfdkfkdsjkdsjkj</Label>
      </View> */}
      {/* <CardItem style={transparentBackground}>
                <Item style={transparentBorder}>
                  <View style={{flexDirection: "column"}}>
                    <Label
                      style={[
                        labelStyle,
                        {
                          textAlign: lang == "ar" ? "right" : "left",
                          color: "#171717"
                        }
                      ]}
                    >
                      {strings("insurancecompanies.choose_reason", lang)}
                    </Label>
                    </View>
                </Item>
              </CardItem> */}
              <ListItem
                    style={{
                      marginTop: 10,
                      alignSelf: lang == "en" ? "flex-start" : "flex-end",
                      borderBottomWidth: 0
                    }}
                  >
                    <Text
                      style={{
                        color: "#171717",
                        fontSize: 21,
                        fontFamily: "TajawalRegular0",
                        lineHeight:25
                      }}
                    >
                      {strings("insurancecompanies.choose_reason", lang)}
                    </Text>
                  </ListItem>
                  <ListItem>
                <Body style={centerStyle}>
                
                          <Picker
                        mode="dropdown"
                        iosHeader={strings("insurancecompanies.choose_reason", lang)}
                        // placeholder={strings('carInformation.car_type',lang)}
                        iosIcon={<Icon name="arrow-down" />}
                        placeholderStyle={{color: "#9B9B9B"}}
                      placeholder={strings("insurancecompanies.choose_reason", lang)}
                        style={{
                          borderRadius:5,marginBottom:5,backgroundColor:"#fff",height:40,borderColor:'gray',borderWidth:0.1,marginRight:lang=='ar'?100:null,

                            direction: lang == "ar" ? "rtl" : "ltr",
                            borderBottomColor:
                              form_submitted && this.state.reason == ""
                                ? "red"
                                : "#171717",
                            borderBottomWidth:
                              form_submitted && this.state.reason == "" ? 1 : 0
                          }
                        }
                        selectedValue={this.state.reason}
                        onValueChange={value =>
                          this.setState({reason:value})
                        }
                      >
                      {lang=='ar'?
reasons.length>0?
                        reasons.map((test, index) => {
                          return (
                          
                            <Picker.Item
                              key={test.id}
                              label={test.reason_ar}
                              value={test.id}
                            />
                          );
                        })
                        :null
                        :
                        reasons.length>0?
                        reasons.map((test, index) => {
                          return (
                          
                            <Picker.Item
                              key={test.id}
                              label={test.reason_en}
                              value={test.id}

                            />
                          );
                        })
                        :null
                        }
                      </Picker>
                      </Body>
                      </ListItem>  
                                          <CardItem>
                      {/* <ListItem style={{borderBottomWidth: 0}}> */}
                    <Body>
                      <Button
                        onPress={() =>
                          this.goToAnotherPage(
                           reason
                          )
                        }
                        style={{backgroundColor: "#003580"}}
                        block
                      >
                        <Text style={buttonText}>
                        {strings('drivinglicense.continue',lang)}
                        </Text>
                      </Button>
                    </Body>
                  {/* </ListItem> */}
                  </CardItem>
      
                  </View>
                  {/* </Content>    */}
                </View>
              </Modal>
              
               
      
            </Content>
</Drawer>
            </ImageBackground>

            

        )
    }
}
const drawerStyles = {
  drawer: {shadowOpacity: 0, elevation: 0},
  main: {shadowOpacity: 0, elevation: 0}
};
// export default LifeInsurance;
const mapStateToProps = state => {
    const { lang } = state.sideBarReducer;
    const { notifications,notifications_loading,show_order_modal,reasons} = state.notificationReducer;
    return {lang,notifications,notifications_loading,show_order_modal,reasons};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,
    notificationsPageAction,
   )
    (NotificationScreen);