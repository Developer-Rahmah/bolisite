
import React, { Component } from 'react';
import {ImageBackground,Dimensions,ScrollView,View,Image,Keyboard,StatusBar,TouchableWithoutFeedback,Platform} from 'react-native';
import {CardItem,Body,Button,Text, Icon,Right,Left,Card,Label,Drawer,CheckBox} from 'native-base';
import {transparentBackground,centerStyle,buttonStyle,buttonText,labelStyle} from '../theme';
import * as lifeInsuranceAction from '../actions/lifeInsuranceAction';
import Header from './header';
import SideBar from "./sideBar";
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';
import DropdownAlert from 'react-native-dropdownalert';


const dimensions=Dimensions.get('window');
class LifeInsuranceQuestion extends Component{
  constructor(props){
    super(props);
    this.state ={
      form_submitted: false,

      isYesChecked:false,isNoChecked:false
  }
  }
countYes=(value)=>{
value.No=false
    value.Yes=!value.Yes
    this.setState({isYesChecked: value.Yes});

  }
  countNo=(value)=>{
    console.log("value",value)
 value.Yes=false
    value.No=!value.No
    this.setState({isNoChecked: value.No});
    

  }
    goFromLifeInsuranceQuestion=()=>{
      console.log("kifedsf",this.props.lifeInsuranceInformation)
      
      var arr=[]
      this.setState({form_submitted:true})
      const {questions,lang}=this.props;
      for(var i=0;i<questions.length;i++)
      {
        if(questions[i].Yes==false&&questions[i].No==false){
          // this.dropdown.alertWithType('error',strings('message.error',lang), strings('message.fill_message',lang));
arr.push(questions[i])
        }
      
      }
      if(arr.length<=0){
      this.props.goFromLifeInsuranceQuestion(this.props.lifeInsuranceInformation,this.props.user_id,questions)

      }
      else{
    this.dropdown.alertWithType('error',strings('message.error',lang), strings('message.fill_message',lang));

      }
      
          // Actions.insurancecompanies({
          //   insuranceCompanies:this.props.insuranceCompanies,
          //   lifeInsuranceInformation:this.props.lifeInsuranceInformation,
          //   user_id:this.props.user_id

          //   });
      
   
        }
        closeDrawer = () => {
            this.drawer._root.close();
        
          };
        
          
        
          openDrawer = () => {
            
            this.drawer._root.open();
            setTimeout(() => Keyboard.dismiss());
          };
    render(){
      console.log("this.props in life questions",this.props)
      const {lang,questions}=this.props
console.log("questions",questions)
console.log("this.state.form submitted",this.state.form_submitted)
        return(

            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
          <Drawer
            type="overlay"
            side="right"
            ref={ref => {
              this.drawer = ref;
            }}
            content={
              <SideBar
                navigator={this._navigator}
                closeDrawer={this.closeDrawer}
              />
            }
            onClose={this.closeDrawer}
            onOpen={this.openDrawer}
            tapToClose={true}
            openDrawerOffset={0.2}
            panCloseMask={0.2}
            closedDrawerOffset={-3}
            styles={drawerStyles}
          >

           <Header
                       openDrawer={this.openDrawer}
                       closeDrawer={this.closeDrawer}
           /> 
 
            <StatusBar backgroundColor="#1e2131" barStyle="light-content" />
         
                      <ScrollView ref={(ref)=> {this._scrollView = ref}}>

       
                      {questions.map((item, index) => {
                                  item.Yes=Boolean(item.Yes)
                                  item.No=Boolean(item.No)


                      return (
              //  lang=='ar'?
              <View style={{backgroundColor:'transparent',borderColor:'transparent'}}>

                     <View style={{marginRight:lang=='ar'?20:null,marginLeft:lang=='en'?20:null,marginTop:20}} key={item.id}>
          
                          <Label style={{textAlign:lang=='ar'?"right":"left",color:this.state.form_submitted==true&&item.Yes==false&&item.No==false?"red":"#171717",fontFamily:'TajawalBold0',lineHeight:25}}>{item.questions}</Label>
                      </View>
                      {Platform.OS=="ios"||(Platform.OS=="android"&&lang=='en')?

                      <TouchableWithoutFeedback onPress={() =>this.countYes(item)}>


               <CardItem style={[transparentBackground,{direction:lang=='ar'?"rtl":"ltr"}]}  >
             
          {/* <Right style={{justifyContent:'flex-end'}}> */}
          <View style={{flexDirection: 'row',justifyContent: 'space-between',alignItems:'center'}}>
                 <CheckBox
              
              style={{marginRight:15,borderRadius:50,justifyContent:'center',alignItems:'center',paddingRight:4,marginBottom :15}}
              checked={item.Yes}
              color="#003580"
              onPress={() =>this.countYes(item)
            
              }
            />
   <Label style={[labelStyle,{textAlign:lang=='ar'?"right":"left",color:"#171717",marginBottom:10}]}>{strings('health_insurance.yes',lang)}</Label>


                 </View>
               </CardItem>
               </TouchableWithoutFeedback>
               :
               <TouchableWithoutFeedback onPress={() =>this.countYes(item)}>


               <CardItem style={[transparentBackground,{flexDirection:"row-reverse"}]}  >
             
          {/* <Right style={{justifyContent:'flex-end'}}> */}
          <View style={{flexDirection: 'row',justifyContent: 'space-between',alignItems:'center'}}>
          <Label style={[labelStyle,{textAlign:lang=='ar'?"right":"left",color:"#171717",marginBottom:15}]}>{strings('health_insurance.yes',lang)}</Label>

                 <CheckBox
              
              style={{marginRight:15,borderRadius:50,justifyContent:'center',alignItems:'center',paddingRight:4,marginBottom :15}}
              checked={item.Yes}
              color="#003580"
              onPress={() =>this.countYes(item)
            
              }
            />


                 </View>
               </CardItem>
               </TouchableWithoutFeedback>
  }
                        {Platform.OS=="ios"||(Platform.OS=="android"&&lang=='en')?

               <TouchableWithoutFeedback onPress={() =>this.countNo(item)}>

               <CardItem style={[transparentBackground,{direction:lang=='ar'?"rtl":"ltr",marginTop:-25}]} bordered >
             
             {/* <Right style={{justifyContent:'flex-end'}}> */}
             <View style={{flexDirection: 'row',justifyContent: 'space-between',alignItems:'center'}}>
          
                      <CheckBox
                 
                 style={{marginRight:15,borderRadius:50,justifyContent:'center',alignItems:'center',paddingRight:4,marginBottom :15}}
                 checked={item.No}
                 color="#003580"
                 onPress={() =>this.countNo(item)
               
                 }
               />
      <Label style={[labelStyle,{textAlign:lang=='ar'?"right":"left",color: "#171717",marginBottom:10}]}>{strings('health_insurance.no',lang)}</Label> 
    
   
                    </View>
                   
             {/* </Right> */}
                  </CardItem>
     
                  </TouchableWithoutFeedback>
                  :
                  <TouchableWithoutFeedback onPress={() =>this.countNo(item)}>

                  <CardItem style={[transparentBackground,{flexDirection:"row-reverse",marginTop:-25}]} bordered >
                
                {/* <Right style={{justifyContent:'flex-end'}}> */}
                <View style={{flexDirection: 'row',justifyContent: 'space-between',alignItems:'center'}}>
                <Label style={[labelStyle,{textAlign:lang=='ar'?"right":"left",color: "#171717",marginBottom:12}]}>{strings('health_insurance.no',lang)}</Label> 

             
                         <CheckBox
                    
                    style={{marginRight:15,borderRadius:50,justifyContent:'center',alignItems:'center',paddingRight:4,marginBottom :15}}
                    checked={item.No}
                    color="#003580"
                    onPress={() =>this.countNo(item)
                  
                    }
                  />
       
      
                       </View>
                      
                {/* </Right> */}
                     </CardItem>
        
                     </TouchableWithoutFeedback>
                }
    
                  
                 
  </View>

                      );
                })}
          
    
               <CardItem style={transparentBackground}>
               
                <Body style={centerStyle}>
               
                  <Button style={buttonStyle}  block onPress={this.goFromLifeInsuranceQuestion}>
                  {lang=='ar'?
                    <Icon name='md-arrow-back' style={{color:'#fff'}}/>
                    :null}
                    <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
                    {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                  </Button>
                </Body>
            </CardItem>

            </ScrollView>
            <DropdownAlert replaceEnabled={true}  titleStyle={{textAlign:lang=='ar'? 'right':'left',fontFamily:'TajawalBold0',color:"#fff"}} messageStyle={{textAlign:lang=='ar'?'right':'left',fontFamily:'TajawalBold0',color:"#fff"}}imageStyle={{direction:'rtl'}} ref={(ref) => this.dropdown = ref}  />    

        </Drawer>
            </ImageBackground>

            

        )
    }
}
const drawerStyles = {
    drawer: {shadowOpacity: 0, elevation: 0},
    main: {shadowOpacity: 0, elevation: 0}
  };
// export default LifeInsurance;
const mapStateToProps = state => {
    const { lang } = state.sideBarReducer;

    return {lang};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,lifeInsuranceAction)
    (LifeInsuranceQuestion);