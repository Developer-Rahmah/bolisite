import React, {Component} from "react";
import {
  ImageBackground,
  Dimensions,
  Text,
  View,
  Image,
  TouchableWithoutFeedback,
  Modal,
  Keyboard,
  StatusBar,
  TouchableOpacity,Platform
} from "react-native";
import {
  CardItem,
  Body,
  Right,
  Left,
  ListItem,
  CheckBox,
  Button,
  Content,
  Icon,
  Drawer,Card
} from "native-base";

import {connect} from "react-redux";
import {strings} from "../../Locales/i18n";
import {Constants} from "expo";
import {VerticalWrapper} from "./common/VerticalWrapper";
var typeInsurancee=""
const dimensions = Dimensions.get("window");
const IMAGE_BASE_URL = "https://bolisati1.qiotic.info/";

import * as insuranceCompaniesAction from "../actions/insuranceCompaniesAction";

import {
  centerStyle,
  servicesText,
  sevicesCardItemStyle,
  transparentBackground,
  buttonStyle,
  buttonText
} from "../theme";
import {Actions} from "react-native-router-flux";
import Header from "./header";
import SideBar from "./sideBar";
import PDFReader from "rn-pdf-reader-js";

class InsuranceCompanies extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isAddonChecked: false,
      insuranceCompanyId: null,
      totalAll: 0
    };
  }
 
  countPrice = value => {
    value.isChecked = !value.isChecked;
    this.setState({isAddonChecked: value.isChecked});
  };
  goToAnotherPage = (addons, insuranceCompaanyId, total) => {
    var companyAddons = [];
    for (var i = 0; i < addons.length; i++) {
      if (addons[i].isChecked) {
        companyAddons.push(addons[i]);
      }
    }
    const {
      show_insurance_modal2,
      carInformation,
      user_id,
      lifeInsuranceInformation,
      cancerCarProgramInformation,
      shippingInformation
    } = this.props;

    console.log("carInformation", carInformation);

    this.props.showInsuranceCompanyModal2(!show_insurance_modal2);
    console.log("this.props.insurance_type",this.props.insurance_type)
    

      Actions.damagestep({
        carInformation: carInformation,
        addons: companyAddons,
        insuranceCompaanyId: insuranceCompaanyId,
        total: total,
        user_id: user_id,
        full_name:this.props.full_name
      });
 
  
 
  };
  showPdfModal = id => {
    this.props.getTerms(id);
    this.props.showPdfModal(!show_pdf_modal);
  };
  showModal = (id, company) => {
    console.log("company", company);
    const {addons, show_insurance_modal2, category_id,carInformation} = this.props;
    this.setState({insuranceCompanyId: id});
    // this.setState({totalAll:company.insurance_price})
    if (company.total) {
      this.setState({totalAll: parseFloat(company.total)});
    }
    this.props.getAddons(id, category_id);
    this.props.getTerms(id);
    this.props.showInsuranceCompanyModal2(!show_insurance_modal2);
    console.log("addons", addons);
  };
  closeDrawer = () => {
    this.drawer._root.close();
  };

  openDrawer = () => {
    this.drawer._root.open();
    setTimeout(() => Keyboard.dismiss());
  };
  render() {
    console.log("this.props in insurance", this.props);
    console.log("Actions.prev s in insurance ", Actions.prevScene);
   
    const {
      show_insurance_modal2,
      insuranceCompanies,
      terms,
      addons,
      carInformation,
      lang,
      show_pdf_modal
    } = this.props;
    console.log("this.state.totalAll", this.state.totalAll);
    console.log("terms", terms);
    var total = this.state.totalAll;
    for (var i = 0; i < addons.length; i++) {
      if (addons[i].isChecked) {
        total = total + (addons[i].price);
      }
    }

    return (
      <ImageBackground
        source={require("../assests/images/splash–1.png")}
        style={{width: dimensions.width, height: "100%"}}
      >
        <Drawer
          type="overlay"
          side="right"
          ref={ref => {
            this.drawer = ref;
          }}
          content={
            <SideBar
              navigator={this._navigator}
              closeDrawer={this.closeDrawer}
            />
          }
          onClose={this.closeDrawer}
          onOpen={this.openDrawer}
          tapToClose={true}
          openDrawerOffset={0.2}
          panCloseMask={0.2}
          closedDrawerOffset={-3}
          styles={drawerStyles}
        >
          <Header openDrawer={this.openDrawer} closeDrawer={this.closeDrawer} />

          <StatusBar backgroundColor="#1e2131" barStyle="light-content" />
          {/* <TouchableWithoutFeedback onPress={() => this.props.showInsuranceCompanyModal(!show_insurance_modal)}>    */}
          <Content style={{backgroundColor: "transparent"}}>
            <CardItem
              style={{
                width: dimensions.width,
                backgroundColor: "#fff",
                height: 66
              }}
            >
              {lang == "ar" ? (
                <View style={{marginLeft:180}}>
                  <Text style={servicesText}>
                    {strings("insurancecompanies.insurance_companies", lang)}
                  </Text>
                </View>
              ) : (
                <Left>
                  <Text style={servicesText}>
                    {strings("insurancecompanies.insurance_companies", lang)}
                  </Text>
                </Left>
              )}
            </CardItem>
{Platform.OS=="ios"?
            insuranceCompanies.length>0
              ? insuranceCompanies.map((company, index) => {
                  return (
                    <TouchableWithoutFeedback
                      onPress={() =>
                        this.showModal(company.manufacturers_id, company)
                      }
                   
                      key={company.manufacturers_id}
                    >
                      {lang == "ar" ? (
                        <CardItem
                          style={{
                            backgroundColor: "#fff",height: 129,marginTop: 15,width: dimensions.width,direction: "rtl"}}
                        >
                          <Right>
                            <Body>
                              <Image
                                source={{uri: `${IMAGE_BASE_URL}${company.manufacturers_image}`}}
                                style={{width: 100, height: 100}}
                              />
                            </Body>
                          </Right>
                  
                          <Left>
                            <Body>
                              {lang=="en"?
                              <Text style={{fontFamily: "TajawalBold0",lineHeight:25}}>
                                {company.manufacturers_name}
                              </Text>
                              :
                              <Text style={{fontFamily: "TajawalBold0",lineHeight:25}}>
                              {company.manufacturers_name_ar}
                            </Text>
                          }
                              {company.total ? (
                                <Text
                                  style={{
                                    fontFamily: "TajawalBold0",
                                    marginTop: 10
                                  }}
                                >
                                  {company.total} JOD
                                </Text>
                              ) : null}
                            </Body>
                          </Left>
                        </CardItem>
                      ) : (
                        <CardItem
                          style={{
                            backgroundColor: "#fff",
                            height: 129,
                            marginTop: 15,
                            width: dimensions.width,
                            direction: "ltr"
                          }}
                        >
                          <Left>
                            <Body>
                              <Image
                                source={{
                                  uri: `${IMAGE_BASE_URL}${
                                    company.manufacturers_image
                                  }`
                                }}
                                style={{width: 100, height: 100}}
                              />
                            </Body>
                          </Left>
                          {/* <Body style={{justifyContent:"center",alignItems:"center"}}>
                           <Text style={{marginLeft:20}}>
                             {company.manufacturers_name}
                           </Text>
                         </Body> */}

                          <Right>
                            <Body style={{marginTop: 50}}>
                            {lang=="en"?
                              <Text style={{fontFamily: "TajawalBold0"}}>
                                {company.manufacturers_name}
                              </Text>
                              :
                              <Text style={{fontFamily: "TajawalBold0"}}>
                              {company.manufacturers_name_ar}
                            </Text>
                        }
                              {company.total ? (
                                <Text style={{fontFamily: "TajawalBold0"}}>
                                  {company.total} JOD
                                </Text>
                              ) : null}
                            </Body>
                          </Right>
                        </CardItem>
                      )}
                    </TouchableWithoutFeedback>
                  );
                })
              : 
              <Card style={{  backgroundColor:'transparent',borderColor:'transparent',shadowOpacity:0,elevation:0}}>
              <VerticalWrapper style={{marginTop:230}}>
                {/* <Image source={require('../../assests/images/no-results-found.png')} style={{width:120,height:120}} /> */}
                <Text style={{  marginTop:10,marginBottom:10,color:"#003580",fontFamily:'TajawalBold0',fontSize:16}}>there's no insurance companies...</Text>
              </VerticalWrapper>
            </Card>
            :
            insuranceCompanies.length>0
              ? insuranceCompanies.map((company, index) => {
                  return (
                    <TouchableWithoutFeedback
                      onPress={() =>
                        this.showModal(company.manufacturers_id, company)
                      }
                   
                      key={company.manufacturers_id}
                    >
                      {lang == "ar" ? (
                        <CardItem
                          style={{
                            backgroundColor: "#fff",height: 129,marginTop: 15,width: dimensions.width,flexDirection:"row-reverse"}}
                        >
                          <Right>
                            <Body>
                              <Image
                                source={{uri: `${IMAGE_BASE_URL}${company.manufacturers_image}`}}
                                style={{width: 100, height: 100}}
                              />
                            </Body>
                          </Right>
                  
                          <Left>
                            <Body>
                              {lang=="en"?
                              <Text style={{fontFamily: "TajawalBold0",lineHeight:25}}>
                                {company.manufacturers_name}
                              </Text>
                              :
                              <Text style={{fontFamily: "TajawalBold0",lineHeight:25}}>
                              {company.manufacturers_name_ar}
                            </Text>
                          }
                              {company.total ? (
                                <Text
                                  style={{
                                    fontFamily: "TajawalBold0",
                                    marginTop: 10
                                  }}
                                >
                                  {company.total} JOD
                                </Text>
                              ) : null}
                            </Body>
                          </Left>
                        </CardItem>
                      ) : (
                        <CardItem
                          style={{
                            backgroundColor: "#fff",
                            height: 129,
                            marginTop: 15,
                            width: dimensions.width,
                            direction: "ltr"
                          }}
                        >
                          <Left>
                            <Body>
                              <Image
                                source={{
                                  uri: `${IMAGE_BASE_URL}${
                                    company.manufacturers_image
                                  }`
                                }}
                                style={{width: 100, height: 100}}
                              />
                            </Body>
                          </Left>
                          {/* <Body style={{justifyContent:"center",alignItems:"center"}}>
                           <Text style={{marginLeft:20}}>
                             {company.manufacturers_name}
                           </Text>
                         </Body> */}

                          <Right>
                            <Body style={{marginTop: 50}}>
                            {lang=="en"?
                              <Text style={{fontFamily: "TajawalBold0"}}>
                                {company.manufacturers_name}
                              </Text>
                              :
                              <Text style={{fontFamily: "TajawalBold0"}}>
                              {company.manufacturers_name_ar}
                            </Text>
                        }
                              {company.total ? (
                                <Text style={{fontFamily: "TajawalBold0"}}>
                                  {company.total} JOD
                                </Text>
                              ) : null}
                            </Body>
                          </Right>
                        </CardItem>
                      )}
                    </TouchableWithoutFeedback>
                  );
                })
              : 
              <Card style={{  backgroundColor:'transparent',borderColor:'transparent',shadowOpacity:0,elevation:0}}>
              <VerticalWrapper style={{marginTop:230}}>
                {/* <Image source={require('../../assests/images/no-results-found.png')} style={{width:120,height:120}} /> */}
                <Text style={{  marginTop:10,marginBottom:10,color:"#003580",fontFamily:'TajawalBold0',fontSize:16}}>there's no insurance companies...</Text>
              </VerticalWrapper>
            </Card>
              }
            <Modal
              visible={show_insurance_modal2}
              animationType={"slide"}
              onRequestClose={() =>
                this.props.showInsuranceCompanyModal2(!show_insurance_modal2)
              }
              supportedOrientations={[
                "portrait",
                "portrait-upside-down",
                "landscape",
                "landscape-left",
                "landscape-right"
              ]}
              transparent
            >
              {/* <TouchableWithoutFeedback
             onPress={() => this.props.showInsuranceCompanyModal(!show_insurance_modal)}
           > */}
              <View
                style={{
                  backgroundColor: "rgba(0,0,0,0.50)",
                  position: "relative",
                  flex: 1,
                  justifyContent: "center"
                }}
              >
                <View
                  style={{
                    borderWidth: 1,
                    borderRadius: 5,
                    borderColor: "#e3e3e3",
                    padding: 0,
                    backgroundColor: "#fff",
                    marginLeft: 15,
                    marginRight: 15
                  }}
                >
                  <CardItem>
                    <Left>
                      <Icon
                        style={{color: "#003580", fontSize: 25}}
                        name="md-close"
                        onPress={() =>
                          this.props.showInsuranceCompanyModal2(
                            !show_insurance_modal2
                          )
                        }
                      />
                    </Left>
                  </CardItem>
                  <ListItem
                    style={{
                      marginTop: 10,
                      alignSelf: lang == "en" ? "flex-start" : "flex-end",
                      borderBottomWidth: 0
                    }}
                  >
                    <Text
                      style={{
                        color: "#171717",
                        fontSize: 21,
                        fontFamily: "TajawalRegular0",
                        lineHeight:25
                      }}
                    >
                      {strings("insurancecompanies.Terms_and_Conditions", lang)}
                    </Text>
                  </ListItem>

                  {terms.length > 0 ? (
                    <ListItem
                      style={{
                        marginTop: 10,
                        borderBottomWidth: 0,
                        alignSelf: lang == "en" ? "flex-start" : "flex-end",

                      }}
                    >
                      <TouchableOpacity
                        onPress={() => this.props.showPdfModal(!show_pdf_modal)}
                      >
                        <Text
                          style={{fontFamily: "TajawalBold0", lineHeight: 20}}
                        >
                          {strings("insurancecompanies.terms_text", lang)}
                        </Text>
                      </TouchableOpacity>
                    </ListItem>
                  ) : // <CardItem style={transparentBackground}>
                  // <View style={{marginLeft:50}}>
                  // <Text style={{textAlign:lang=='ar'?"right":"left",fontSize:12,fontFamily:'TajawalRegular0'}}>{terms[0].terms}</Text>
                  // </View>
                  // <Button onPress={() =>this.props.showPdfModal(!show_pdf_modal)}><Text>here</Text></Button>

                  // </CardItem>

                  null}
  {addons.length > 0?
                  <ListItem
                    style={{
                      marginTop: 10,
                      borderBottomWidth: 0,
                      alignSelf: lang == "en" ? "flex-start" : "flex-end",
                    }}
                  >
                    <Text
                      style={{
                        color: "#171717",
                        fontSize: 21,
                        fontFamily: "TajawalRegular0",
                        lineHeight:20
                      }}
                    >
                      {strings("insurancecompanies.addons", lang)}
                    </Text>
                  </ListItem>
:null}
  {Platform.OS=="ios"||(Platform.OS=="android"&&lang=='en')?

                  addons.length > 0
                    ? addons.map((addon, index) => {
                        addon.isChecked = Boolean(addon.isChecked);
                        console.log("addon.isChecked", addon.isChecked);
                        return (
                          
                          <CardItem
                            style={{
                              borderBottomWidth: 0,
                              direction: lang == "ar" ? "rtl" : "ltr"
                            }}
                            key={index}
                          >
                   
                            <CheckBox
                              style={{
                                marginRight: 15,
                                borderRadius: 50,
                                justifyContent: "center",
                                alignItems: "center",
                                paddingRight: 4
                              }}
                              checked={addon.isChecked}
                              color="#003580"
                              onPress={() => this.countPrice(addon)}
                            />

                  {lang=="en"?
                            <Text style={{fontFamily: "TajawalRegular0"}}>
                              {addon.addon_name} {addon.price}
                            </Text>
                      :
                      <Text style={{fontFamily: "TajawalRegular0"}}>
                      {addon.addon_name_ar} {addon.price}
                    </Text>
                            }
                          </CardItem>
                        );
                      })
                    : null
                    :
                    addons.length > 0
                    ? addons.map((addon, index) => {
                        addon.isChecked = Boolean(addon.isChecked);
                        console.log("addon.isChecked", addon.isChecked);
                        return (
                          
                          <CardItem
                            style={{
                              borderBottomWidth: 0,
                              // direction: lang == "ar" ? "rtl" : "ltr"
                              flexDirection:"row-reverse"
                            }}
                            key={index}
                          >
                   
                            <CheckBox
                              style={{
                                // marginRight: 5,
                                borderRadius: 50,
                                justifyContent: "center",
                                alignItems: "center",
                                paddingRight: 4
                              }}
                              checked={addon.isChecked}
                              color="#003580"
                              onPress={() => this.countPrice(addon)}
                            />

                  {lang=="en"?
                            <Text style={{fontFamily: "TajawalRegular0",marginRight:20}}>
                              {addon.addon_name} {addon.price}
                            </Text>
                      :
                      <Text style={{fontFamily: "TajawalRegular0",marginRight:20}}>
                      {addon.addon_name_ar} {addon.price}
                    </Text>
                            }
                          </CardItem>
                        );
                      })
                    : null}

  
                  {/* <CardItem>
           <Right>
                   <Text>{total} JOD</Text>
               </Right>
               <Body>

               </Body>
               <Left>
                   <Text>المجموع</Text>

               </Left>

           </CardItem> */}
           {total != 0&&Platform.OS=="ios"||(Platform.OS=="android"&&lang=="en") ? (
                    <CardItem
                      style={[
                        transparentBackground,
                        {marginTop: 40, direction: lang == "ar" ? "rtl" : "ltr"}
                      ]}
                      bordered
                    >
                      <Left>
                        <Text
                          style={{
                            fontFamily: "TajawalRegular0",
                            fontSize: 16,
                            textAlign: "right",
                            color: "#171717"
                          }}
                        >
                          {strings("insurancecompanies.total", lang)}
                        </Text>
                      </Left>
                      <Right>
                        <Text
                          style={{
                            fontFamily: "TajawalRegular0",
                            fontSize: 16,
                            textAlign: "right",
                            color: "#171717"
                          }}
                        >
                          {total} JOD
                        </Text>
                      </Right>
                    </CardItem>
                  ) : null}
                         {total != 0&&Platform.OS=="android"&&lang=="ar" ? (
                    <CardItem
                      style={[
                        transparentBackground,
                        {marginTop: 40, flexDirection:"row-reverse"}
                      ]}
                      bordered
                    >
                      <Right>
                        <Text
                          style={{
                            fontFamily: "TajawalRegular0",
                            fontSize: 16,
                            textAlign: "right",
                            color: "#171717"
                          }}
                        >
                          {strings("insurancecompanies.total", lang)}
                        </Text>
                      </Right>
                      <Left>
                        <Text
                          style={{
                            fontFamily: "TajawalRegular0",
                            fontSize: 16,
                            textAlign: "right",
                            color: "#171717"
                          }}
                        >
                          {total} JOD
                        </Text>
                      </Left>
                    </CardItem>
                  ) : null}
                  <ListItem style={{borderBottomWidth: 0}}>
                    <Body>
                      <Button
                        onPress={() =>
                          this.goToAnotherPage(
                            addons,
                            this.state.insuranceCompanyId,
                            total
                          )
                        }
                        style={{backgroundColor: "#003580"}}
                        block
                      >
                        <Text style={buttonText}>
                          {strings("insurancecompanies.agree_the_termas", lang)}
                        </Text>
                      </Button>
                    </Body>
                  </ListItem>
                </View>
              </View>
              {/* </TouchableWithoutFeedback> */}
              <Modal
                visible={show_pdf_modal}
                animationType={"slide"}
                onRequestClose={() => this.props.showPdfModal(!show_pdf_modal)}
                supportedOrientations={[
                  "portrait",
                  "portrait-upside-down",
                  "landscape",
                  "landscape-left",
                  "landscape-right"
                ]}
                transparent
              >
                <View
                  style={{
                    backgroundColor: "#fff",
                    width: dimensions.width,
                    height: "100%"
                  }}
                >
                  {/* <Content> */}
                  <View
                    style={{
                      marginTop: 22,
                      flex: 1,
                      padding: 10,
                      backgroundColor: "transparent",
                      justifyContent: "space-between",
                      flexDirection: "column"
                    }}
                  >
                    <View style={{marginLeft: 10}}>
                      <Icon
                        style={{
                          color: "#003580",
                          fontSize: 25,
                          alignSelf: "flex-start"
                        }}
                        onPress={() => this.props.showPdfModal(!show_pdf_modal)}
                        name="md-close"
                      />
                    </View>
                    {terms.length > 0 ? (
                      <View
                        style={{
                          flex: 1,
                          paddingTop: Constants.statusBarHeight,
                          backgroundColor: "#fff"
                        }}
                      >
                        <PDFReader source={{uri: terms[0].car_terms}} />
                      </View>
                    ) : null}
                  </View>
                  {/* </Content>    */}
                </View>
              </Modal>
            </Modal>
          </Content>
        </Drawer>
      </ImageBackground>
    );
  }
}
const drawerStyles = {
  drawer: {shadowOpacity: 0, elevation: 0},
  main: {shadowOpacity: 0, elevation: 0}
};
// START MAP STATE TO PROPS
const mapStateToProps = state => {
  const {lang} = state.sideBarReducer;
  const {
    show_insurance_modal2,
    addons,
    terms,
    show_pdf_modal
  } = state.insuranceCompaniesReducer;
  return {show_insurance_modal2, addons, terms, lang, show_pdf_modal};
};
// END MAP STATE TO PROPS

export default connect(mapStateToProps, insuranceCompaniesAction)(
  InsuranceCompanies
);
