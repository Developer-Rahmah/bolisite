import React, { Component } from 'react';
import {ImageBackground,Dimensions,Image,Keyboard,StatusBar,ImageEditor,ImageStore,ActivityIndicator,TouchableOpacity,Alert,Platform} from 'react-native';
import {CardItem,Body,Button,Text, Icon, Content,View,Drawer} from 'native-base';
import {uploadButton,continueText,uploadLicenseText,skipButton,skipText,continueButton} from '../assests/styles/drivingLicenseStyles';
import {transparentBackground,centerStyle} from '../theme';
import {Actions} from "react-native-router-flux";
import {ImagePicker, Camera, Permissions, ImageManipulator, Audio} from "expo";
import axios from 'axios';
import Header2 from './headerWithoutArrow';

// import {RNCamera} from 'react-native-camera';
import * as drivingLicenseAction from '../actions/drivingLicenseAction';
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';
import Header from './header';
import SideBar from "./sideBar";
const dimensions=Dimensions.get('window');
import {scanned_passport_image} from "../App";

class Uploadpassport extends Component{
  constructor(props){
    super(props);
    this.state ={
      showCameraView:false ,
      type: Camera.Constants.Type.back,
           image: null,
           cameraPermission: null,
           cameraRollPermission: null,
           fadeAnim: 0,
     doneimg: require("../assests/images/empty.png"),
     loading: false,
     flip: false,
     text1:"",
     text2:"",
     text3:"",
     counter:1
   
    }
  }
  async componentWillMount() {
    
    this.setState({ loading: false });
    const { status } = await Permissions.askAsync(Permissions.CAMERA);
    this.setState({ hasCameraPermission: status === 'granted' });
}


  async componentDidMount() {
    const cameraPermission = await Permissions.getAsync(Permissions.CAMERA)
    const cameraRollPermission = await Permissions.getAsync(Permissions.CAMERA_ROLL);

    this.setState({
        cameraPermission: cameraPermission.status,
        cameraRollPermission: cameraRollPermission.status,
    })
    setInterval(() => {
      this.setState({fadeAnim:this.state.fadeAnim==1?0:1})
    }, 1000); 
    this.soundObject = new Audio.Sound();
    this.soundObject.loadAsync(require("../assests/sounds/ding.mp3"));
}
goToAnotherPage=()=>{
console.log("this.propsjjj",this.props)

    const {user_id,servantInformation,travelInformation}=this.props;
// if(servantInformation){
//     Actions.servantinsuranceinformation({
//       user_id:user_id
//     })
//   }
  if (travelInformation){
    Actions.travelinsurance({user_id:this.props.user_id,insuranceCompaanyId:this.props.insuranceCompaanyId,travelInformation:this.props.travelInformation,total:this.props.total,addons:this.props.addons})
  }
  else{
       Actions.servantinsuranceinformation({
      user_id:user_id
    }) 
  }
  }
closeDrawer = () => {
  this.drawer._root.close();

};



openDrawer = () => {
  
  this.drawer._root.open();
  setTimeout(() => Keyboard.dismiss());
};
soundObject = null;
  start() {
    this.setState({showCameraView: true});
    this.capture = true;
    setInterval(() => {
      if (this.capture) {
        this.takePicture();
      }
    }, 300);
  }
  license = {
    regtype: {
      x: 0,
      y: 0,
      val: "",
      no: "",
      symbol: ""
    },
    name: {
      x: 0,
      y: 0,
      val: ""
    },
    id: {
      x: 0,
      y: 0,
      val: ""
    }
    // nameE: {
    //   x: 0,
    //   y: 0,
    //   val: ""
    // }

  };

  reset() {
    this.license = {
      regtype: {
        x: 0,
        y: 0,
        val: "",
        no: "",
        symbol: ""
      },
      name: {
        x: 0,
        y: 0,
        val: ""
      },
      id: {
        x: 0,
        y: 0,
        val: ""
      }
      // },
      // nameE: {
      //   x: 0,
      //   y: 0,
      //   val: ""
      // }
    };

  }
  lines = [];
  face = 1;
  uploadPost(imagedata,d) {
    let data1 = {
      requests: []
    };
    data1.requests.push({
      image: {
        content: imagedata
      },
      features: []
    });
    data1.requests[0].features.push({
      type: "DOCUMENT_TEXT_DETECTION"
    });

    var headers = {
      "Content-Type": "application/json"
    };
    data1.requests[0].image.content = imagedata;
    console.log("data1",data1)
    var cur = this;
    fetch(
      "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyBoXrBh8kQ0quHCNhAjs2T3h5RvUJK1Ajo",
      {
        method: "post",
        headers: headers,
        body: JSON.stringify(data1)
      }
    )
      .then(response => {
        response.json().then(
          async jsn => {
            console.log("jsn",jsn)
            //alert(JSON.stringify(jsn));
            if(this.state.counter>6){
              Alert.alert("","خطأ")
            this.setState({showCameraView:false})
              }
            if (
              (cur.face == 1 &&
                (JSON.stringify(jsn).indexOf("المملكة") == -1 ||
                JSON.stringify(jsn).indexOf("سفر") == -1)) 
              // (cur.face == 2 &&
              //   (JSON.stringify(jsn).indexOf("المحرك") == -1 ||
              //     JSON.stringify(jsn).indexOf("الترخيص") == -1))
            ) {
              this.setState({counter:this.state.counter+1})

              setTimeout(() => {
                cur.capture = true;
              }, 1000);
            } else {
              //alert("1");
              cur.setState({loading: true});
              var text = [];

              for (
                var x = 1;
                x < jsn.responses[0].textAnnotations.length;
                x++
              ) {
                console.log("jsn.responses[0].textAnnotations[x]",jsn.responses[0].textAnnotations[x])

                var description =
                  jsn.responses[0].textAnnotations[x].description;
                  console.log("description",description)
                var xval = Number.parseInt(
                  jsn.responses[0].textAnnotations[x].boundingPoly.vertices[0].x
                );
                console.log("xval",xval)

                var yval = Number.parseInt(
                  jsn.responses[0].textAnnotations[x].boundingPoly.vertices[0].y
                );
                console.log("yval",yval)

                cur.lines.push(
                  description + "-" + xval.toString() + "-" + yval.toString()
                );
                //console.log(description + "-" + xval.toString()+"-"+yval.toString())
                if (description == "Name"||description=="الإسم"||description=="/") {
                  cur.license.name.x = xval;
                  cur.license.name.y = yval;
                } else if (description == "JOR") {
                  cur.license.id.x = xval;
                  cur.license.id.y = yval;
                } 
                // else if (description == "Name") {
                //   cur.license.nameE.x = xval;
                //   cur.license.nameE.y = yval;
                // } 
     
              // }
              // for (
              //   var x = 1;
              //   x < jsn.responses[0].textAnnotations.length;
              //   x++
              // ) {
              //   console.log("jsn.responses[0].textAnnotations[x]",jsn.responses[0].textAnnotations[x])
              //   var description =
              //     jsn.responses[0].textAnnotations[x].description;
              //     console.log("descriptopn2",description)
              //   var xval = Number.parseInt(
              //     jsn.responses[0].textAnnotations[x].boundingPoly.vertices[0].x
              //   );
              //   console.log("xval12",xval)
              //   var yval = Number.parseInt(
              //     jsn.responses[0].textAnnotations[x].boundingPoly.vertices[0].y
              //   );
              //   console.log("yval2",yval)
                if (
                  description.indexOf("المركبة") == -1 &&
                  description.indexOf("اسم") == -1 &&
                  description.indexOf("المالك") == -1 &&
                  description != "فئة" &&
                  description != "العنوان" &&
                  description.indexOf("نوع") == -1 &&
                  description.indexOf("اللون") == -1 &&
                  description.indexOf("رخصة") == -1 &&
                  description.indexOf("غاية") == -1 &&
                  description != "سنة" &&
                  description != "الصنع" &&
                  description != "الفرعي" &&
                  description != "الترخيص" &&
                  description != "مركز" &&
                  description != "الشاصي" &&
                  description != "المحرك" &&
                  description.indexOf("ستعمال") == -1 &&
                  description.indexOf("رقم") == -1 &&
                  description != "التسجيل" &&
                  description != "التسجيل" &&
                  description != "خصوصي" &&
                  description.indexOf("غاىة") == -1 &&
                  description.indexOf(":") == -1 &&
                  description.indexOf("الوقود") == -1 &&
                  description.indexOf("صفة") == -1 &&
                  description.indexOf("+") == -1
                ) {
                  if (cur.face == 1) {
                    cur.license = cur.assignval(
                      cur.license,
                      description,
                      xval,
                      yval
                    );
                    console.log("licsnnndhskhdk",cur.license)
                  } 
                }
              }

              if (
                cur.face == 1 &&
                (cur.license.name.val == "" ||
                  // cur.license.nameE.val == "" ||
                  cur.license.id.val == "" )
              ) {
                console.log("here")
                cur.reset();
                setTimeout(() => {
                  cur.setState({loading: false});
                  cur.lines = [];
                  cur.capture = true;
                }, 1000);
              }
              //  else if (cur.face == 2 && cur.license1.fueltype.val == "") {
              //   setTimeout(() => {
              //     cur.setState({loading: false});
              //     //cur.lines=[];
              //     cur.capture = true;
              //   }, 1000);
              // }
               else {
                if (cur.face == 1) {
                  console.log("here2")
                  // setTimeout(() => {
                  //   cur.setState({
                  //     loading: false,
                  //     doneimg: require("../assests/images/checkmark1.png"),
                  //     text1: "تم قراءة الوجه الأمامى",
                  //     // flip: true
                  //   });

                    try {
                      cur.soundObject.playAsync();
                    } catch (error) {console.log("error",error)}
                    // setTimeout(() => {
                    //   cur.setState({
                    //     doneimg: require("../assests/images/rotate1.png"),
                    //     text3: "من فضلك اقلب الرخصة"
                    //   });
                    //   setTimeout(() => {
                    //     cur.setState({
                    //       doneimg: require("../assests/images/empty.png"),
                    //       text3: ""
                    //     });
                    //   }, 4000);
                    // }, 3000);
                    //Alert.alert("","الرجاء قلب الرخصة")
                    // console.log(cur.license);
                    // cur.face = 2;
                    // cur.capture = true;
                    //cur.lines.push("--");
                  // }, 300);
                  scanned_passport_image.full_name = cur.license.name.val.replace('Name ','');
                  scanned_passport_image.passport_number = cur.license.id.val.replace('JOR ','');
                  scanned_passport_image.skip_passport_img=d;

                   cur.setState({showCameraView: false});
                   scanned_passport_image.scanned = true;
                   console.log("scanned_passport_image",scanned_passport_image)

              //      if(this.props.canerCareText){

              //       Actions.cancercareprogram({user_id:this.props.user_id})

              // }
              // else if(this.props.healthInsuranceText){
              //   Actions.healthinsurance({user_id:this.props.user_id})
              // }
              // else {
              //   Actions.lifeinsurance({user_id:this.props.user_id})}
              //   } 
              if (this.props.travelInformation){
                Actions.travelinsurance({user_id:this.props.user_id,insuranceCompaanyId:this.props.insuranceCompaanyId,travelInformation:this.props.travelInformation,total:this.props.total,addons:this.props.addons})
              }
              else{
                   Actions.servantinsuranceinformation({
                  user_id:this.props.user_id
                }) 
              }
             } else {
                  console.log("here3")
                  cur.setState({loading: false, flip: false});
                  cur.face = 1;
                  //this.capture=true;

                  // cur.license.expiary.val = cur.license.expiary.val.replace(
                  //   /[٠١٢٣٤٥٦٧٨٩]/g,
                  //   function(d) {
                  //     return d.charCodeAt(0) - 1632;
                  //   }
                  // );
                  /*cur.license.expiary.val=cur.license.expiary.val.replace('١','1');
                      cur.license.expiary.val=cur.license.expiary.val.replace('٢','2');
                      cur.license.expiary.val=cur.license.expiary.val.replace('٣','3');
                      cur.license.expiary.val=cur.license.expiary.val.replace('٤','4');
                      cur.license.expiary.val=cur.license.expiary.val.replace('٥','5');
                      cur.license.expiary.val=cur.license.expiary.val.replace('٦','6');
                      cur.license.expiary.val=cur.license.expiary.val.replace('٧','7');
                      cur.license.expiary.val=cur.license.expiary.val.replace('٨','8');
                      cur.license.expiary.val=cur.license.expiary.val.replace('٩','9');*/

                  /*var datearray=cur.license.expiary.val.split('/');
                      for(var z=0;z<datearray.length;z++)
                      {
                        datearray[z]=datearray[z].replace(/[^0-9]/g, '');
                      }
                      cur.license.expiary.val=datearray.join('/');*/
                  // scanned_driving_license.full_name = cur.license.name.val;
                  // scanned_driving_license.car_type = cur.license.type.val;
                  // scanned_driving_license.car_model = cur.license.model.val;
                  // scanned_driving_license.fuel_type = cur.license1.fueltype.val;
                  // scanned_driving_license.manufacturing_year =
                  //   cur.license.year.val;
                  // scanned_driving_license.end_date = cur.license.expiary.val;
                  // scanned_driving_license.driving_license_img=d;
                  // var l = cur.license.regtype.no.split("-");

                  // scanned_driving_license.license_no =
                  //   l.length > 1 ? l[1] : l[0];
                  // scanned_driving_license.symbol = l[0];
                  // scanned_driving_license.scanned = true;
                  scanned_passport_image.full_name = cur.license.name.val;
                  scanned_passport_image.id_number = cur.license.id.val;
                  scanned_passport_image.skip_id_img=d;
                   cur.setState({showCameraView: false});
                  
              
                  // console.log(cur.license1);
                  //alert(JSON.stringify(cur.license));
                  //alert(JSON.stringify(scanned_driving_license));
                }
              }
            }
          },
          err => {
            alert(JSON.stringify(err));
          }
        );
      })
      .catch(err => {console.log("err",err)});
  }
  assignval(license, data, x, y) {
    console.log("data",data)
    console.log("license",license)
    console.log("x",x)
    console.log("y",y)
console.log("(Math.abs(y - license.name.y)",(Math.abs(y - license.name.y)))
    if (Math.abs(y - license.name.y) <= 15) {

      license.name.val = license.name.val+" "+data;
      console.log("license.name.val",license.name.val)
    } else if (Math.abs(y - license.regtype.y) <= 15) {
      license.regtype.no = license.regtype.no + " " + data;
    } else if (Math.abs(y - license.id.y) <= 15) {
      license.id.val = license.id.val + " " + data;
    }
    // } else if (Math.abs(y - license.nameE.y) <= 15 ) {
    //   license.nameE.val = license.nameE.val + " " + data;
    // }
    return license;
  }
 
  capture = true;
  async takePicture() {

    if (this.camera && this.capture) {
      this.capture = false;

      const options = {quality: 1, base64: true};
      var cur = this;
      this.camera.takePictureAsync(options).then(async data => {
        var d = await ImageManipulator.manipulateAsync(
          data.uri,
          [{resize: {width: 1200}}],
          {base64: true}
        );
        console.log("ddddddd",d)
        //cur.uploadPost(d.base64);
        //});
        console.log(d.height.toString() + "-" + d.width.toString());
        var yoffset = d.height / 2 - d.width * 0.95 * 2 / 6;
        var snappheight = d.width * 0.95 * 2 / 3;
        console.log(yoffset.toString() + "-" + snappheight.toString());
        const cropData = {
          offset: {x: d.width * 0.05, y: yoffset},
          size: {width: d.width * 0.95, height: snappheight}
        };
        var cur = this;
        // alert(data.width.toString() + "-" +data.height.toString()+"-"+data.pictureOrientation.toString())
        ImageEditor.cropImage(
          d.uri,
          cropData,
          uri => {
            ImageStore.getBase64ForTag(
              uri,
              base64data => {
                cur.uploadPost(base64data,d.uri);
              },
              err => {
                //alert(JSON.stringify(err))
              }
            );
          },
          err => {
            //alert(JSON.stringify(err))
          }
        );
      });
    }
  }

  // takePicture =  async function(a) {
  //   // debugger
  //   if (this.camera) {
  //     const options = { quality: 0.5, base64: true };
  //     const data23 =  await this.camera.takePictureAsync(options);
  //     const base64Str = 'data:image/jpg;base64,'+data23.base64;
  //      var data = new FormData();  
  //     data.append('apikey', '103f8deacb88957')
  //     data.append('base64Image', base64Str)
  //     data.append('language','ara')
  //     data.append('isOverlayRequired',true)
    
  //   const headers = { 
  //     'isOverlayRequired':true,
  //     'language':'ara',
  //     'apikey': '103f8deacb88957',
  //     'Accept': 'application/json',
  //     'Content-Type': 'multipart/form-data;',
  //    }
  //   const config = { 
  //     method: 'POST', 
  //     headers,
  //     body: data
  //    };
  //   const URL = 'https://api.ocr.space/parse/image';
  //   // debugger
  //   fetch(URL, config ).then(res=>{
  //     // debugger
  //     console.log('asda',res)
  //   })
    
  //   this.setState({showCameraView:false })
    
  //  // this.props.getImageInfo(data.uri)
  //   }
  // };
    render(){
      let { image } = this.state;

      const {lang}=this.props;
  console.log("this.prop in upload passport",this.props)
        return(
            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:dimensions.height}}>
          <Drawer
            type="overlay"
            side="right"
            ref={ref => {
              this.drawer = ref;
            }}
            content={
              <SideBar
                navigator={this._navigator}
                closeDrawer={this.closeDrawer}
              />
            }
            onClose={this.closeDrawer}
            onOpen={this.openDrawer}
            tapToClose={true}
            openDrawerOffset={0.2}
            panCloseMask={0.2}
            closedDrawerOffset={-3}
            styles={drawerStyles}
          >
          {!this.state.showCameraView?
            <Header openDrawer={this.openDrawer} closeDrawer={this.closeDrawer} />
  :
            <Header2 openDrawer={this.openDrawer} closeDrawer={this.closeDrawer} />
      }
 
            <StatusBar backgroundColor="#1e2131" barStyle="light-content" />
            <Content style={transparentBackground}>
            {/* {this.state.showCameraView?
            <View style={{flex: 1,flexDirection: 'column',backgroundColor: 'black',width:dimensions.width,height:dimensions.height/1.2}}>

      </View>
      :null} */}
        {this.state.showCameraView ? (
              <View
                style={{
                  flex: 1,
                  flexDirection: "column",
                  backgroundColor: "black",
                  width: dimensions.width,
                  height: dimensions.height / 1.2
                }}
              >
                <Camera
                  ref={ref => {
                    this.camera = ref;
                  }}
                  style={{
                    flex: 1,
                    flexDirection: "column",
                    justifyContent: "flex-start",
                    alignItems: "center"
                  }}
                  type={Camera.Constants.Type.back}
                  flashMode={Camera.Constants.FlashMode.off}
                  permissionDialogTitle={"Permission to use camera"}
                  permissionDialogMessage={
                    "We need your permission to use your camera phone"
                  }
                >
                 {Platform.OS=="android"?
                  <View
                    style={{
                      backgroundColor: "rgba(1,1,1,0.6)",
                      flex: 1,
                      width: "100%",
                      marginLeft: 5
                    }}
                  >
                                       <TouchableOpacity onPress={()=>this.setState({showCameraView:false})} style={{marginLeft:10,backgroundColor: "rgba(1,1,1,0.6)",width:dimensions.width}}>
        <Text style={{fontFamily: "TajawalBold0",color:"#fff"}}>Cancel</Text>
      </TouchableOpacity> 
  </View>
  :
  <View
  style={{
    backgroundColor: "rgba(1,1,1,0.6)",
    flex: 1,
    width: "100%",
    marginLeft: 0
  }}
>
                     <TouchableOpacity onPress={()=>this.setState({showCameraView:false})} style={{marginLeft:5,marginTop:5,width:dimensions.width}}>
<Text style={{fontFamily: "TajawalBold0",color:"#fff"}}>Cancel</Text>
</TouchableOpacity> 
</View>
                  }
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "center",
                      alignItems: "center",
                      padding: 0,
                      margin: 0,
                      width: "100%",
                      height: Dimensions.get("window").width * 0.95 * 2 / 3
                    }}
                  >
                    <View
                      style={{
                        backgroundColor: "rgba(1,1,1,0.6)",
                        height: Dimensions.get("window").width * 0.95 * 2 / 3,
                        width: "2.5%",
                        margin: 0
                      }}
                    />
                    <View
                      style={{
                        backgroundColor: "transparent",
                        justifyContent: "center",
                        alignItems: "center",
                        borderColor: "#fcfcfc",
                        borderWidth: 1,
                        borderRadius: 2,
                        margin: 0,
                        width: "95%",
                        height: Dimensions.get("window").width * 0.95 * 2 / 3,
                        minWidth: 200,
                        minHeight: 100
                      }}
                    >
                      {this.state.loading ? (
                        <ActivityIndicator size="large" color="#fcfcfc" />
                      ) : null}
                      <Image
                        source={this.state.doneimg}
                        style={{width: 128, height: 128}}
                      />
                      <Text
                        style={{
                          opacity: this.state.flip ? 1 : this.state.fadeAnim,
                          fontSize: 16,
                          color: "#e7f6f8",
                          fontFamily: "TajawalBold0"
                        }}
                      >
                        {this.state.text3}
                      </Text>
                    </View>
                    <View
                      style={{
                        backgroundColor: "rgba(1,1,1,0.6)",
                        height: Dimensions.get("window").width * 0.95 * 2 / 3,
                        width: "2.5%",
                        justifyContent: "center",
                        alignItems: "center",
                        margin: 0
                      }}
                    />
                  </View>
                  <View
                    style={{
                      backgroundColor: "rgba(1,1,1,0.6)",
                      flex: 1,
                      width: "100%",
                      margin: 0,
                      paddingTop: 20,
                      justifyContent: "flex-start",
                      alignItems: "center"
                    }}
                  >
                    <Text
                      style={{
                        opacity: this.state.flip ? 1 : this.state.fadeAnim,
                        fontSize: 16,
                        color: "#e7f6f8",
                        fontFamily: "TajawalBold0"
                      }}
                    >
                      {this.state.text1}
                    </Text>
                    <Text
                      style={{
                        opacity: this.state.fadeAnim,
                        fontSize: 16,
                        color: "#e7f6f8",
                        fontFamily: "TajawalBold0",
                        opacity: this.state.fadeAnim
                      }}
                    >
                      {this.state.text2}
                    </Text>
                  </View>

                  <View
                    style={{
                      justifyContent: "center",
                      alignItems: "center",
                      width: "100%"
                    }}
                  />
                </Camera>

              </View>
            ) : null}
               <CardItem style={[transparentBackground,{marginTop:40}]}>
               <View style={{ width: '100%', height: 110, justifyContent: 'center', alignItems: 'center', borderRadius: 0,  borderWidth: 0, backgroundColor: 'transform' }}>
               <Image style={{
                resizeMode: 'contain',
                height:172.8,width:278.3
                // justifyContent: 'cener',
            }} source={require('../../assets/Passport.png')} />
            <View style={{ justifyContent: 'center', alignItems: 'center', }}>
    {image &&
        <Image source={{ uri: image }} style={{ width: 290, height: 120, marginTop: 20, }} />}
</View> 

        </View>
                 {/* <Body style={centerStyle}>
                 <Image
                   source={require('../../assets/Artboard.png')} style={licenseImage}
                 />
                 
                 </Body> */}
               </CardItem>
               <CardItem style={[transparentBackground,{marginTop:30}]}>
                 <Body style={centerStyle}>
                   <Button style={uploadButton} block 
                  //  onPress={()=>this.setState({showCameraView: true})}
                  // onPress={()=>{ this._takePicture() } }
                  onPress={() => this.start()}
                   >
                     <Text style={uploadLicenseText}>{strings('drivinglicense.upload_your_passport',lang)}</Text>
                   </Button>
                 </Body>
               </CardItem>
               <CardItem style={[transparentBackground]}>
                 <Button style={continueButton}
                 >
                 {lang=='ar'?
                   <Icon name='md-arrow-back' style={{color:'#fff'}}/> 
                   :null}
                   <Text style={continueText}>{strings('drivinglicense.continue',lang)}</Text>
                   {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                   </Button>
                 <Button style={skipButton} onPress={()=>this.goToAnotherPage()}>
                   <Text style={skipText}>{strings('drivinglicense.skip',lang)}</Text>
                 </Button>
               </CardItem>
               </Content>
               </Drawer>
           </ImageBackground>
        )
    }
    _pickImage = async () => {
      let result = await ImagePicker.launchImageLibraryAsync({
          allowsEditing: true,
          aspect: [4, 3],
      });

      console.log(result);

      if (!result.cancelled) {
          this.setState({ image: result.uri });
      }
  };
  _cam = async () => {
      let result = await ImagePicker.launchCameraAsync({
          allowsEditing: true,
          aspect: [4, 3],
      });

      console.log(result);

      if (!result.cancelled) {
          this.setState({ image: result.uri });
      }
  };

  
  _checkCameraPermissions = async () => {
      const { status } = await Permissions.getAsync(Permissions.CAMERA);
      //const { status } = await Permissions.getAsync(Permissions.CAMERA_ROLL);
      this.setState({ status });
  }
  _reqCameraPermissions = async () => {
      const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
      this.setState({ cameraPermission: status });
  };


  _checkCameraRollPermissions = async () => {
      const { status } = await Permissions.getAsync(Permissions.CAMERA);
      this.setState({ status });
  }
  _reqCameraRollPermissions = async () => {
      const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
      this.setState({ cameraRollPermission: status });
  };

  _pickImage = async () => {
      this._checkCameraRollPermissions();
      this._reqCameraRollPermissions();
      let result = await ImagePicker.launchImageLibraryAsync();

      console.log(result);
      if (!result.cancelled) {
          this.setState({ image: result.uri });
          CameraRoll.saveToCameraRoll(result.uri)
      }
  };

 

}

// export default DrivingLicense;
const drawerStyles = {
  drawer: {shadowOpacity: 0, elevation: 0},
  main: {shadowOpacity: 0, elevation: 0}
};
// START MAP STATE TO PROPS
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;
  const { information} = state.drivingLicenseReducer;
  return { information,lang};




  
}
// END MAP STATE TO PROPS
export default connect(mapStateToProps,drivingLicenseAction)(Uploadpassport);