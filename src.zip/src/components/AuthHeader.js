import React, { Component } from 'react';
import {Dimensions,Image,View,TouchableOpacity,Platform} from 'react-native';
import { connect } from 'react-redux';
import { Container, Header, Left, Body, Right, Title, Button, Text,Icon, CardItem } from 'native-base';
import { Actions} from "react-native-router-flux";
import { isLoggIn } from "../actions/authAction";
import {centerStyle,headerStyle,menuIcon,otherCardItemStyle} from '../theme';
import {translate} from '../../Locales/i18n';
import * as sideBarAction from '../actions/sideBarAction';
import {strings} from '../../Locales/i18n';
import * as homeAction from '../actions/homeAction';
import * as privacyAction from '../actions/privacyAction'
import * as orderPageAction from '../actions/ordersPageAction';
// import Icon from "react-native-vector-icons/FontAwesome";
const dimensions=Dimensions.get('window');
class AuthHeader extends Component {
  constructor(props){
    super(props);
    this.state ={
      lang:'',
    }

  }
  componentDidMount(){
    this.props.isLoggIn()
  }
  changelanguage=(language)=>{
    const {lang,user}=this.props
    if(language=='ar')
{

  this.setState({lang:'ar'})
  // AsyncStorage.setItem("locale", this.state.lang);

  // this.props.getLanguageText({
  //   prop: "lang",
  //   value: language  })
  this.props.getLanguageText(language)
 
    this.props.closeDrawer();
      // this.props.getCategories(4);
      // this.props.getPrivacy(4);
      // this.props.getUserAgreement(4);
      // this.props.getOrders(user.data[0].customers_id,4);

      


  //  AsyncStorage.setItem("locale", "ar");

}
else if (language=='en'){
  // I18n.currentLocale('en');
this.setState({lang:'en'})
this.props.getLanguageText(language)

this.props.closeDrawer();
  // this.props.getCategories(1);
  // this.props.getPrivacy(1);
  // this.props.getUserAgreement(1);
  // this.props.getOrders(user.data[0].customers_id,1);




// AsyncStorage.setItem("locale", this.state.lang);

}

translate(this.state.lang)
  }
    render(){
      const {user,show_icon}=this.props;


        return(
            
            <Header style={headerStyle}>
        <Left></Left>
        {Platform.OS=="ios"?
        <Body
          style={{
            justifyContent: "center",
            alignItems: "center",
            marginTop: 50,
            marginRight:30
          }}
        >
          <Image
            source={require("../assests/images/logo2.png")}
            style={{height: 150, width: 150}}
          />
        </Body>
        :
        <Body
          style={{
            justifyContent: "center",
            alignItems: "center",
            marginTop: 90,
            marginLeft:50
          }}
        >
          <Image
            source={require("../assests/images/logo2.png")}
            style={{height: 150, width: 150}}
          />
        </Body>
}
            {/* <Right>
          {user.isLoggedIn ?
              <Button transparent onPress={this.props.openDrawer} >
                <Icon name='menu' style={menuIcon} />
              </Button>
               :null}
        </Right> */}
   <Right style={{marginLeft:20}}>

<View style={{flexDirection:'row',marginTop:Platform.OS=="android"?15:null
// ,marginEnd:lang=='ar'?30:90
}}
>
           {/* <TouchableOpacity 
           onPress={()=>this.changelanguage('ar')}
           >
<CardItem style={[otherCardItemStyle,{marginLeft:30}]}>
                         <Right>
               <TouchableOpacity 
               onPress={()=>this.changelanguage('ar')}
               style={{width:57,height:35,backgroundColor:'#003580',borderColor:'#003580',borderRadius:3,paddingTop:3,alignItems:'center',justifyContent:'center'}}>
               <Text style={{color:"#fff",fontSize:14,fontFamily:'TajawalBold0'}}>ar</Text>
               </TouchableOpacity>
             </Right>
           </CardItem>
           </TouchableOpacity> */}
                 <TouchableOpacity style={{marginLeft:30}}
            onPress={()=>this.changelanguage('ar')}
            >
           <CardItem style={{backgroundColor:"transparent",marginLeft:Platform.OS == "android"?80:60,marginBottom:10}}>
          <View style={{width:20}}/>
             <Right>
             <TouchableOpacity 
             onPress={()=>this.changelanguage('ar')}
             style={{width:45,height:35,backgroundColor:'#fff',borderColor:'#003580',borderRadius:3,paddingTop:3,alignItems:'center',justifyContent:'center',marginLeft:20}}>
               <Text style={{color:'#003580',fontSize:14,fontFamily:'TajawalBold0'}}>ع</Text>
               </TouchableOpacity>
             </Right>
           </CardItem>

           </TouchableOpacity>
           <TouchableOpacity 
            onPress={()=>this.changelanguage('en')}
            >
           <CardItem style={{backgroundColor:"transparent",marginRight:Platform.OS == "ios"?5:-5,marginBottom:10}}>
          <View style={{width:20}}/>
             <Right>
             <TouchableOpacity 
             onPress={()=>this.changelanguage('en')}
             style={{width:45,height:35,backgroundColor:'#fff',borderColor:'#003580',borderRadius:3,paddingTop:3,alignItems:'center',justifyContent:'center',marginLeft:20}}>
               <Text style={{color:'#003580',fontSize:14,fontFamily:'TajawalBold0'}}>en</Text>
               </TouchableOpacity>
             </Right>
           </CardItem>

           </TouchableOpacity>
</View>

</Right>
          </Header>
        )
    }
}
// export default HeaderCustom;

const mapStateToProps = state =>
{
  const { categories,home_loading,customerInfo} = state.homeReducer;

  const { user } = state.authReducer;
  const { lang } = state.sideBarReducer;
  return { user,lang,categories,customerInfo};
}
export default connect(mapStateToProps,{isLoggIn,...sideBarAction,...homeAction,...privacyAction,...orderPageAction})(AuthHeader);