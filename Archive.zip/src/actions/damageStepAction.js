
import client from '../constants';
import {Actions} from "react-native-router-flux";

//  const base_URL = 'https://bolisati.qiotic.info/app';

export const sendOrder = (data) => {

console.log("dataaaaa",data)
    return (dispatch) => {
  
      
          client.post(`addneworder`, data).then(function(response) {
            console.log("response12345",response)
          Actions.payment({data:response.data.data[0]})
       
      
          }).catch(function(error) {
            console.log("error",error)
            const res = JSON.parse(error.request._response);
      
          
          });
        }
      
  
    // }
  };