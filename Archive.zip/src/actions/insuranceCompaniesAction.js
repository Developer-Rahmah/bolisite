import {SHOW_INSURANCE_COMPANY_MODAL,GET_ADDONS,GET_TERMS,GET_COMPANIES_TEXT,LIFE_INSURANCE_MESSAGE} from './types';
import client from '../constants';

  //START SHOW/HIDE MODAL
  export const showInsuranceCompanyModal = value => {
    return {type: SHOW_INSURANCE_COMPANY_MODAL, payload: value};
  };
  //END SHOW/HIDE MODAL

//START FETCHING ADDONS
export const getAddons = (manufacturers_id) => {
return (dispatch) => {
  client.post(`companyaddons?manufacturers_id=${manufacturers_id}`).then((response) => {
console.log("response",response)
    const res = response.data.data;
    dispatch({type: GET_ADDONS, payload: res})

  }).catch((error) => {
      console.log("error")
    dispatch({type: GET_ADDONS, payload: []})

  })
}
};
//END FETCHING ADDONS

//START FETCHING TERMS
export const getTerms = (manufacturers_id) => {
  return (dispatch) => {
    client.post(`companyinformation?manufacturers_id=${manufacturers_id}`).then((response) => {
  console.log("response of terms",response)
      const res = response.data.data;
      dispatch({type: GET_TERMS, payload: res})
  
    }).catch((error) => {
        console.log("error")
      dispatch({type: GET_TERMS, payload: []})
  
    })
  }
  };
  //END FETCHING TERMS


export const getInsuranceCompaniesText = ({prop, value}) => {
  console.log("value",value)
  return dispatch => {
    dispatch({type: GET_COMPANIES_TEXT, payload: {prop, value}});
  }
};

export const lifeInsuranceOrder=(insuranceCompaanyId,lifeInsuranceInformation)=>{
  console.log("lifeInsuranceInformation",lifeInsuranceInformation)
  return (dispatch) => {
    client.post(`addlifeorder`,{
      'national_id' :lifeInsuranceInformation.id_number,
      'name' :lifeInsuranceInformation.full_name,
      'age_from' :20,
      'age_to' :25,
      'company_id' :insuranceCompaanyId
    }).then(function(response) {
      console.log("responseeee",response)
      alert(response.data.message)

      dispatch({
        type: LIFE_INSURANCE_MESSAGE,
        payload: {
          isError: false,
          isSuccess: true,
          msg: "success"
        }
      });
 
    })
  }
}
export const travelInsuranceOrder=(insuranceCompaanyId,travelInformation)=>{
  console.log("lifeInsuranceInformation",travelInformation)
  return (dispatch) => {
    client.post(`addtravelorder`,{
      passport_number :travelInformation.passport_number,
      name :travelInformation.full_name,
      travel_date :travelInformation.travel_date,
      travel_from :travelInformation.from,
      travel_to :travelInformation.to,
      'company_id' :insuranceCompaanyId
    }).then(function(response) {
      console.log("responseeee",response)
      alert(response.data.message)

      dispatch({
        type: LIFE_INSURANCE_MESSAGE,
        payload: {
          isError: false,
          isSuccess: true,
          msg: "success"
        }
      });
 
    })
  }
}