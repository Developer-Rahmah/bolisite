import axios from 'axios';
import {
    GET_IMAGE_INFO,
 } from './types';
import client from '../constants';


//  const base_URL = 'https://bolisati.qiotic.info/app';

//START FETCHING imageOCR
export const getImageInfo = (uri) => {
  return (dispatch) => {
    axios.post(`https://api.ocr.space/parse/image`,{
        data:{ apikey:'103f8deacb88957',
      base64Image:uri,
      language:"ara",
      isOverlayRequired:true},
      headers: {'Content-Type': 'multipart/form-data' }

    })

    // axios.get(`https://api.ocr.space/parse/imageurl?apikey=103f8deacb88957&url=${uri}&language=ara&isOverlayRequired=true`
     // apikey:'103f8deacb88957',
      //url:uri,
      //language:"ara",
      //isOverlayRequired:true
    
    // )
    // https://api.ocr.space/parse/imageurl?apikey=helloworld&url=http://i.imgur.com/s1JZUnd.gif&language=chs&isOverlayRequired=true    
    .then((response) => {
      // debugger
  console.log("response for image",response)
      const res = response.data.data;
      dispatch({type: GET_IMAGE_INFO, payload: res})

    }).catch((error) => {
        console.log("error",error)
      dispatch({type: GET_IMAGE_INFO, payload: []})

    })
  }
};
//END FETCHING imageOCR