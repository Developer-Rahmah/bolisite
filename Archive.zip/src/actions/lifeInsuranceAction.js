// import axios from 'axios';
// import {GET_LIFE_INSURANCE_TEXTS,RESET_LIFE_INSURANCE_MESSAGE,LIFE_INSURANCE_MESSAGE} from './types';
// import client from '../constants';
// import { AsyncStorage } from 'react-native';
// import {Actions} from "react-native-router-flux";

// //  const base_URL = 'https://bolisati.qiotic.info/app';

// //START GETTING INPUTS TEXT ACTION
// export const getLifeInsuranceTexts = ({prop, value}) => {
//     return dispatch => {
//       dispatch({type: GET_LIFE_INSURANCE_TEXTS, payload: {prop, value}});
//     }
//   };
//   //END GETTING INPUTS TEXT ACTION

//   //START SHOW/HIDE MODAL
// export const resetLifeInsuranceMessage = value => {
//     return {type:RESET_LIFE_INSURANCE_MESSAGE};
//   };

  
//   //END SHOW/HIDE MODAL



//   export const goFromLifeInsurance = (full_name, id_number, age,user_id) => {

//     return (dispatch) => {
//       if (full_name == '' || id_number == '' || age == '') {
//         dispatch({
//           type: LIFE_INSURANCE_MESSAGE,
//           payload: {
//             isError: true,
//             isSuccess: false,
//             msg: "Please make sure to fill out all fields!"
//           }
//         });
     
  
//       }  
      
//           else{
//          const data={ 
//            full_name: full_name,
//           id_number: id_number,
//           age:age
//     }
//           client.post(`lifeinsurance`).then(function(response) {
//             console.log("response",response)
//             // dispatch({
//             //   type: START_AUTH_LOADING,
//             //   payload: {
//             //     signin_loading: false,
//             //     signup_loading: false,
//             //     recover_loading: false
//             //   }
//             // });
//             dispatch({
//               type: LIFE_INSURANCE_MESSAGE,
//               payload: {
//                 isError: false,
//                 isSuccess: true,
//                 msg: "success"
//               }
//             });
//             Actions.insurancecompanies({
//             insuranceCompanies:response.data.data,
//             lifeInsuranceInformation:data,
//             user_id:user_id            
//             });
//             AsyncStorage.setItem("life_insurance_information",JSON.stringify(data));

//           }).catch(function(error) {
//             console.log("error11111111",error)
//             const res = JSON.parse(error.request._response);
//             console.log("res",res)
//             dispatch({
//               type: LIFE_INSURANCE_MESSAGE,
//               payload: {
//                 isError: true,
//                 isSuccess: false,
//                 msg: res.message
//               }
//             });
//             // dispatch({
//             //   type: START_AUTH_LOADING,
//             //   payload: {
//             //     signin_loading: false,
//             //     signup_loading: false,
//             //     recover_loading: false
//             //   }
//             // });
  
//           });
//         }
//       }
    
//   };
//   //END Go  ACTION



import axios from 'axios';
import {GET_LIFE_INSURANCE_TEXTS,RESET_LIFE_INSURANCE_MESSAGE,LIFE_INSURANCE_MESSAGE} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getLifeInsuranceTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_LIFE_INSURANCE_TEXTS, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION

  //START SHOW/HIDE MODAL
export const resetLifeInsuranceMessage = value => {
    return {type:RESET_LIFE_INSURANCE_MESSAGE};
  };

  
  //END SHOW/HIDE MODAL



  export const goFromLifeInsurance = (full_name, id_number, age,user_id) => {

    return (dispatch) => {
      if (full_name == '' || id_number == '' || age == '') {
        dispatch({
          type: LIFE_INSURANCE_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg: "Please make sure to fill out all fields!"
          }
        });
     
  
      }  
      
          else{
         const data={ 
           full_name: full_name,
          id_number: id_number,
          age:age
    }
          client.post(`lifeinsurance`).then(function(response) {
            console.log("response",response)
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
            dispatch({
              type: LIFE_INSURANCE_MESSAGE,
              payload: {
                isError: false,
                isSuccess: true,
                msg: "success"
              }
            });
            Actions.insurancecompanies({
            insuranceCompanies:response.data.data,
            lifeInsuranceInformation:data,
            user_id:user_id            
            });
            AsyncStorage.setItem("life_insurance_information",JSON.stringify(data));

          })
         .catch(function(error) {
            console.log("error11111111",error)
            const res = JSON.parse(error.request._response);
            console.log("res",res)
            dispatch({
              type: LIFE_INSURANCE_MESSAGE,
              payload: {
                isError: true,
                isSuccess: false,
                msg: res.message
              }
            });
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
  
          });
        }
      }
    
  };
  //END Go  ACTION