// import axios from 'axios';
// import {GET_TRAVEL_INSURANCE_TEXTS,RESET_TRAVEL_INSURANCE_MESSAGE,TRAVEL_INSURANCE_MESSAGE} from './types';
// import client from '../constants';
// import { AsyncStorage } from 'react-native';
// import {Actions} from "react-native-router-flux";

// //  const base_URL = 'https://bolisati.qiotic.info/app';

// //START GETTING INPUTS TEXT ACTION
// export const getTravelInsuranceTexts = ({prop, value}) => {
//     return dispatch => {
//       dispatch({type: GET_TRAVEL_INSURANCE_TEXTS, payload: {prop, value}});
//     }
//   };
//   //END GETTING INPUTS TEXT ACTION

//   //START SHOW/HIDE MODAL
// export const resetTravelInsuranceMessage = value => {
//     return {type:RESET_TRAVEL_INSURANCE_MESSAGE};
//   };

  
//   //END SHOW/HIDE MODAL



//   export const goFromTravelInsurance = (full_name, passport_number, destination,user_id) => {

//     return (dispatch) => {
//       if (full_name == '' || passport_number == '' || destination == '') {
//         dispatch({
//           type: TRAVEL_INSURANCE_MESSAGE,
//           payload: {
//             isError: true,
//             isSuccess: false,
//             msg: "Please make sure to fill out all fields!"
//           }
//         });
     
  
//       }  
      
//           else{
//          const data={ 
//            full_name: full_name,
//            passport_number:passport_number,
//            destination:destination
//     }
//           client.post(`travelinsurance`).then(function(response) {
//             console.log("response",response)
//             // dispatch({
//             //   type: START_AUTH_LOADING,
//             //   payload: {
//             //     signin_loading: false,
//             //     signup_loading: false,
//             //     recover_loading: false
//             //   }
//             // });
//             dispatch({
//               type: TRAVEL_INSURANCE_MESSAGE,
//               payload: {
//                 isError: false,
//                 isSuccess: true,
//                 msg: "success"
//               }
//             });
//             Actions.insurancecompanies({
//             insuranceCompanies:response.data.data,
//             travelInformation:data,
//             user_id:user_id            
//             });
//             AsyncStorage.setItem("travel_information",JSON.stringify(data));

//           }).catch(function(error) {
//             console.log("error11111111",error)
//             const res = JSON.parse(error.request._response);
//             console.log("res",res)
//             dispatch({
//               type: TRAVEL_INSURANCE_MESSAGE,
//               payload: {
//                 isError: true,
//                 isSuccess: false,
//                 msg: res.message
//               }
//             });
//             // dispatch({
//             //   type: START_AUTH_LOADING,
//             //   payload: {
//             //     signin_loading: false,
//             //     signup_loading: false,
//             //     recover_loading: false
//             //   }
//             // });
  
//           });
//         }
//       }
    
//   };
//   //END Go  ACTION






import axios from 'axios';
import {GET_TRAVEL_INSURANCE_TEXTS,RESET_TRAVEL_INSURANCE_MESSAGE,TRAVEL_INSURANCE_MESSAGE} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getTravelInsuranceTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_TRAVEL_INSURANCE_TEXTS, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION

  //START SHOW/HIDE MODAL
export const resetTravelInsuranceMessage = value => {
    return {type:RESET_TRAVEL_INSURANCE_MESSAGE};
  };

  
  //END SHOW/HIDE MODAL



  export const goFromTravelInsurance = (full_name, passport_number, from,to,travel_date,user_id) => {

    return (dispatch) => {
      if (full_name == '' || passport_number == '' || from == ''||to==''||travel_date=='') {
        dispatch({
          type: TRAVEL_INSURANCE_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg: "Please make sure to fill out all fields!"
          }
        });
     
  
      }  
      
          else{
         const data={ 
           full_name: full_name,
           passport_number:passport_number,
           from:from,
           to:to,
           travel_date:travel_date
    }
          client.post(`travelinsurance`).then(function(response) {
            console.log("response",response)
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
            dispatch({
              type: TRAVEL_INSURANCE_MESSAGE,
              payload: {
                isError: false,
                isSuccess: true,
                msg: "success"
              }
            });
            Actions.insurancecompanies({
            insuranceCompanies:response.data.data,
            travelInformation:data,
            user_id:user_id            
            });
            AsyncStorage.setItem("travel_information",JSON.stringify(data));

          }).catch(function(error) {
            console.log("error11111111",error)
            const res = JSON.parse(error.request._response);
            console.log("res",res)
            dispatch({
              type: TRAVEL_INSURANCE_MESSAGE,
              payload: {
                isError: true,
                isSuccess: false,
                msg: res.message
              }
            });
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
  
          });
        }
      }
    
  };
  //END Go  ACTION