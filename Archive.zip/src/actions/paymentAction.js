import axios from 'axios';
import {GET_PAYMENT_TEXT,SHOW_PAYMENT_ONLINE_MODAL,SHOW_PAYMENT_UPON_DELIVERY_MODAL} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getPaymentTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_PAYMENT_TEXT, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION

  //START SHOW/HIDE MODAL
  export const showPaymentOnlineModal = value => {
    return {type: SHOW_PAYMENT_ONLINE_MODAL, payload: value};
  };
  //END SHOW/HIDE MODAL

  //START SHOW/HIDE MODAL
  export const showPaymentUponDeliveryModal = value => {
    return {type: SHOW_PAYMENT_UPON_DELIVERY_MODAL, payload: value};
  };
  //END SHOW/HIDE MODAL








    