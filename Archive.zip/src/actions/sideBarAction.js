import {GET_LANGUAGE_TEXT } from './types';

import {AsyncStorage} from 'react-native';
// export const getLanguageText = ({prop, value}) => {
//   console.log("valuekk",value)
//   return dispatch => {
//     dispatch({type: GET_LANGUAGE_TEXT, payload: {prop, value}});
//   }
// }

//START FETCHING CATEGORIES
export const getLanguageText = (language) => {
console.log("in action",language)
return (dispatch) => {
  AsyncStorage.setItem("locale", language);

  AsyncStorage.getItem("locale").then((value) => {
 
    dispatch({type: GET_LANGUAGE_TEXT, payload: value})
    });
    // dispatch({type: GET_LANGUAGE_TEXT, payload: language})




}
};
//END FETCHING CATEGORIES