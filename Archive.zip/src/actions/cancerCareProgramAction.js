import axios from 'axios';
import {GET_CANCER_CARE_PROGRAM_TEXTS,RESET_CANCER_CARE_PROGRAM_MESSAGE,CANCER_CARE_PROGRAM_MESSAGE} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getCancerCareProgramTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_CANCER_CARE_PROGRAM_TEXTS, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION

  //START SHOW/HIDE MODAL
export const resetCancerCareProgramMessage = value => {
    return {type:RESET_CANCER_CARE_PROGRAM_MESSAGE};
  };

  
  //END SHOW/HIDE MODAL



  export const goFromCancerCareProgram = (full_name, id_number,user_id) => {

    return (dispatch) => {
      if (full_name == '' || id_number == '') {
        dispatch({
          type: CANCER_CARE_PROGRAM_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg: "Please make sure to fill out all fields!"
          }
        });
     
  
      }  
      
          else{
         const data={ 
             full_name: full_name,
          id_number: id_number
    }
          client.post(`cancercare`).then(function(response) {
            console.log("response",response)
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
            dispatch({
              type: CANCER_CARE_PROGRAM_MESSAGE,
              payload: {
                isError: false,
                isSuccess: true,
                msg: "success"
              }
            });
            Actions.insurancecompanies({
            insuranceCompanies:response.data.data,
            cancerCarProgramInformation:data,
            user_id:user_id            
            });
            AsyncStorage.setItem("cancer_car_program_information",JSON.stringify(data));

          }).catch(function(error) {
            console.log("error11111111",error)
            const res = JSON.parse(error.request._response);
            console.log("res",res)
            dispatch({
              type: CANCER_CARE_PROGRAM_MESSAGE,
              payload: {
                isError: true,
                isSuccess: false,
                msg: res.message
              }
            });
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
  
          });
        }
      }
    
  };
  //END Go  ACTION