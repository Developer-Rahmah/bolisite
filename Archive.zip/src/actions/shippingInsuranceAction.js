import axios from 'axios';
import {GET_SHIPPING_INSURANCE_TEXTS,RESET_SHIPPING_INSURANCE_MESSAGE,SHIPPING_INSURANCE_MESSAGE} from './types';
import client from '../constants';
import { AsyncStorage } from 'react-native';
import {Actions} from "react-native-router-flux";

//  const base_URL = 'https://bolisati.qiotic.info/app';

//START GETTING INPUTS TEXT ACTION
export const getShippingInsuranceTexts = ({prop, value}) => {
    return dispatch => {
      dispatch({type: GET_SHIPPING_INSURANCE_TEXTS, payload: {prop, value}});
    }
  };
  //END GETTING INPUTS TEXT ACTION

  //START SHOW/HIDE MODAL
export const resetShippingInsuranceMessage = value => {
    return {type:RESET_SHIPPING_INSURANCE_MESSAGE};
  };

  
  //END SHOW/HIDE MODAL



  export const goFromShippingInsurance = (bill_of_lading_number,user_id) => {

    return (dispatch) => {
      if (bill_of_lading_number == '') {
        dispatch({
          type: SHIPPING_INSURANCE_MESSAGE,
          payload: {
            isError: true,
            isSuccess: false,
            msg: "Please make sure to fill out all fields!"
          }
        });
     
  
      }  
      
          else{
         const data={ 
            bill_of_lading_number: bill_of_lading_number
    }
          client.post(`cargoinsurance`).then(function(response) {
            console.log("response",response)
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
            dispatch({
              type: SHIPPING_INSURANCE_MESSAGE,
              payload: {
                isError: false,
                isSuccess: true,
                msg: "success"
              }
            });
            Actions.insurancecompanies({
            insuranceCompanies:response.data.data,
            shippingInformation:data,
            user_id:user_id            
            });
            AsyncStorage.setItem("shipping_information",JSON.stringify(data));

          }).catch(function(error) {
            console.log("error11111111",error)
            const res = JSON.parse(error.request._response);
            console.log("res",res)
            dispatch({
              type: SHIPPING_INSURANCE_MESSAGE,
              payload: {
                isError: true,
                isSuccess: false,
                msg: res.message
              }
            });
            // dispatch({
            //   type: START_AUTH_LOADING,
            //   payload: {
            //     signin_loading: false,
            //     signup_loading: false,
            //     recover_loading: false
            //   }
            // });
  
          });
        }
      }
    
  };
  //END Go  ACTION