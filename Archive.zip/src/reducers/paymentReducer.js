import {GET_PAYMENT_TEXT,SHOW_PAYMENT_ONLINE_MODAL,SHOW_PAYMENT_UPON_DELIVERY_MODAL} from '../actions/types';
  
  const INITIAL_STATE = {
     payment_online:false,
     payment_upon_delivery:false,
     show_payment_online_modal:false,
     show_payment_upon_delivery_modal:false,
     payment_info_name:'',
     payment_info_credit_Card:'',
     payment_info_cvv:'',
     payment_info_ExMonth:'',
     payment_info_ExYear:'',
     months :[
      // {id:1,month:'Expiry Month',value:''},
      {id:2,month:'January',value:'01'},
      {id:3,month:'February',value:'02'},
      {id:4,month:'March',value:'03'},
      {id:5,month:'April',value:'04'},
      {id:6,month:'May',value:'05'},
      {id:7,month:'June',value:'06'},
      {id:8,month:'July',value:'07'},
      {id:9,month:'August',value:'08'},
      {id:10,month:'September',value:'09'},
      {id:11,month:'October',value:'10'},
      {id:12,month:'November',value:'11'},
      {id:13,month:'December',value:'12'},
    ]
     }
  
  export default(state = INITIAL_STATE, action) => {
    switch (action.type) {
        case GET_PAYMENT_TEXT:
        return {...state,[action.payload.prop]:action.payload.value}

        case SHOW_PAYMENT_ONLINE_MODAL:
        return {...state, show_payment_online_modal: action.payload};

        case SHOW_PAYMENT_UPON_DELIVERY_MODAL:
        return {...state, show_payment_upon_delivery_modal: action.payload};
  
      default:
        return state;
  
    }
  }
  