import {
    GET_CANCER_CARE_PROGRAM_TEXTS,RESET_CANCER_CARE_PROGRAM_MESSAGE,CANCER_CARE_PROGRAM_MESSAGE,
    START_LOADING,

  } from '../actions/types';
  
  const INITIAL_STATE = {
   full_name:'',
  id_number:'',
   cancer_care_program_msg:null,
   cancer_care_program_loading:false,

   

  }
  
  export default (state = INITIAL_STATE, action) =>{
    switch (action.type) {
      case GET_CANCER_CARE_PROGRAM_TEXTS:
       return {...state,[action.payload.prop]:action.payload.value}
  
       case CANCER_CARE_PROGRAM_MESSAGE:
       return {...state,cancer_care_program_msg:action.payload}

     case RESET_CANCER_CARE_PROGRAM_MESSAGE:
      return {...state,cancer_care_program_msg:null}

     case START_LOADING:
      return { ...state,life_insurance_loading:action.payload }


  
      default:
     return state;
    }
  };
  