import {
    GET_SHIPPING_INSURANCE_TEXTS,RESET_SHIPPING_INSURANCE_MESSAGE,SHIPPING_INSURANCE_MESSAGE,
    START_LOADING,

  } from '../actions/types';
  
  const INITIAL_STATE = {
    bill_of_lading_number:'',
   shipping_insurance_msg:null,
   shipping_insurance_loading:false,

   

  }
  
  export default (state = INITIAL_STATE, action) =>{
    switch (action.type) {
      case GET_SHIPPING_INSURANCE_TEXTS:
       return {...state,[action.payload.prop]:action.payload.value}
  
       case SHIPPING_INSURANCE_MESSAGE:
       return {...state,shipping_insurance_msg:action.payload}

     case RESET_SHIPPING_INSURANCE_MESSAGE:
      return {...state,shipping_insurance_msg:null}

     case START_LOADING:
      return { ...state,shipping_insurance_loading:action.payload }


  
      default:
     return state;
    }
  };
  