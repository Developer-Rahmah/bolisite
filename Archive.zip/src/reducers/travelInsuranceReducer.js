import {
    GET_TRAVEL_INSURANCE_TEXTS,RESET_TRAVEL_INSURANCE_MESSAGE,TRAVEL_INSURANCE_MESSAGE,
    START_LOADING,

  } from '../actions/types';
  
  const INITIAL_STATE = {
   full_name:'',
  passport_number:'',
destination:'',
   travel_insurance_msg:null,
   life_insurance_loading:false,

   

  }
  
  export default (state = INITIAL_STATE, action) =>{
    switch (action.type) {
      case GET_TRAVEL_INSURANCE_TEXTS:
       return {...state,[action.payload.prop]:action.payload.value}
  
       case TRAVEL_INSURANCE_MESSAGE:
       return {...state,travel_insurance_msg:action.payload}

     case RESET_TRAVEL_INSURANCE_MESSAGE:
      return {...state,travel_insurance_msg:null}

     case START_LOADING:
      return { ...state,life_insurance_loading:action.payload }


  
      default:
     return state;
    }
  };
  