
import { StyleSheet } from 'react-native';
module.exports  = StyleSheet.create({
  inputNameStyle:{
    marginRight:10,borderRadius:5,marginBottom:5,backgroundColor:"#fff"
  }
  })