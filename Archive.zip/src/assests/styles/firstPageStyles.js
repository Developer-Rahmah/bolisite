import { StyleSheet } from 'react-native';
module.exports  = StyleSheet.create({
cardItem:{
    backgroundColor:"transparent",flex:0.77,justifyContent:'center',alignItems:'center'
},
signInButton:{
    backgroundColor:'#edc68c',justifyContent:'center',alignItems:'center'
},
signInText:{
    color:"#003580",fontSize:16,fontFamily:'TajawalBold0',textAlign:'center',marginTop:5
},
orText:{
    color:"#171717",marginTop:12,fontFamily:'TajawalRegular0',fontSize:15
},
signUpButton:{
    backgroundColor:'#003580',justifyContent:'center',alignItems:'center',
}
  })