import {React} from 'react';
import { StyleSheet, Platform } from 'react-native';
module.exports  = StyleSheet.create({


  imagesStyle:{
      height:129
  },
  imagesCradItem:{
    backgroundColor:"transparent",
    borderColor:"transparent",
    // borderWidth:1,
    // borderRadius:5,
    // height:129
  },
  categoriesText:{
    color:"#ffffff",fontSize:14
  }
  })