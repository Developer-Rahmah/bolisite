import React, { Component } from 'react';
import {ImageBackground,Dimensions,Image,TouchableOpacity,AsyncStorage,View} from 'react-native';
import {List,ListItem,Left,Right,Body,Icon,Text,Content, CardItem} from 'native-base';
import {transparentBackGround,transparentBorder} from '../theme';
import { signOut,isLoggIn,changeLocale } from "../actions/authAction";
import { connect } from 'react-redux';
import I18n from 'react-native-i18n';
import {currentLocale} from '../../Locales/i18n';
import {profileNameText,homeCardItem,otherCardItemStyle,otherTextsStyle,profileImageStyle,listStyle} from '../assests/styles/sideBarStyles';
import { Actions } from 'react-native-router-flux';
import {translate} from '../../Locales/i18n';
import * as sideBarAction from '../actions/sideBarAction';
import {strings} from '../../Locales/i18n';

const dimensions=Dimensions.get('window');
class SideBar extends Component{
  constructor(props){
    super(props);
    this.state ={
      lang:'',

    }

  }
  //START SIGN OUT
  componentDidMount(){
    this.props.isLoggIn()

  }
  signOutHandler = () => {
    this.props.closeDrawer();
    this.props.signOut();
    Actions.firstpage()
  };
  goToSettingPage=()=>
  {
    const {user}=this.props;
    this.props.closeDrawer();
Actions.setting({user:user})
  }
  
  //END SIGN OUT
  changelanguage=(language)=>{
    const {lang}=this.props
    console.log("language",language)
    if(language=='ar')
{

  this.setState({lang:'ar'})
  // AsyncStorage.setItem("locale", this.state.lang);

  // this.props.getLanguageText({
  //   prop: "lang",
  //   value: language  })
  this.props.getLanguageText(language)
    this.props.closeDrawer();

  //  AsyncStorage.setItem("locale", "ar");

}
else if (language=='en'){
  // I18n.currentLocale('en');
this.setState({lang:'en'})
this.props.getLanguageText(language)
this.props.closeDrawer();

// AsyncStorage.setItem("locale", this.state.lang);

}

translate(this.state.lang)
  }
    render(){

      const {user,lang}=this.props;

        return(
            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:300,height:dimensions.height}}>
               <Content style={{backgroundColor:"transparent"}}>
                 <List style={listStyle}>
                   <ListItem style={transparentBorder}></ListItem>
                   {/* <View style={{backgroundColor:'red',}}> */}
                   <CardItem style={[transparentBackGround,{borderColor:"transparent",marginTop:50}]}>
                     <Right>
                       <Image
                           source={require("../assests/images/avatar-1577909_960_720.png")}
                            style={profileImageStyle}
                        />
                     </Right>
                   </CardItem>
                   {user.data?
                   <CardItem style={[transparentBackGround,{borderColor:"transparent"}]}>
                     <Right style={{display:'flex',flexDirection: 'row',alignItems:'center', justifyContent: 'space-between'}}>
                       <Text style={profileNameText}>{user.data[0].customers_firstname}</Text>
                       <Text style={profileNameText}> {user.data[0].customers_lastname}</Text>

                     </Right>
                   </CardItem>
                   :null}
                          {/* </View>   */}
                                    <View style={{width:'100%',height:1,backgroundColor:'white'}}></View>

                   <CardItem style={homeCardItem}>
                     <Right>
                       <Text style={otherTextsStyle}>{strings('header.home',lang)}</Text>
                     </Right>
                   </CardItem>
                   <CardItem style={otherCardItemStyle}>
                     <Right>
                       <Text style={otherTextsStyle}>{strings('header.notification',lang)}</Text>
                     </Right>
                   </CardItem>
                   <CardItem style={otherCardItemStyle}>
                     <Right>
                       <Text style={otherTextsStyle}>{strings('header.help',lang)}</Text>
                     </Right>
                   </CardItem>
                   <TouchableOpacity onPress={this.goToSettingPage}>
                   <CardItem style={otherCardItemStyle}>
                     <Right>
                       <Text style={otherTextsStyle}>{strings('header.setting',lang)}</Text>
                     </Right>
                   </CardItem>
                   </TouchableOpacity>
                   <TouchableOpacity onPress={this.signOutHandler}>
                   <CardItem style={otherCardItemStyle}>
                  
                     <Right>
                       <Text style={otherTextsStyle}>{strings('header.logout',lang)}</Text>
                     </Right>
                   </CardItem>
                   </TouchableOpacity>

                   <TouchableOpacity onPress={()=>this.changelanguage('ar')}>
                   <CardItem style={otherCardItemStyle}>
                  
                     <Right>
                       <Text style={otherTextsStyle}>{strings('header.Arabic',lang)}</Text>
                     </Right>
                   </CardItem>
                   </TouchableOpacity>
                   <TouchableOpacity onPress={()=>this.changelanguage('en')}>
                   <CardItem style={otherCardItemStyle}>
                  
                     <Right>
                       <Text style={otherTextsStyle}>{strings('header.english',lang)}</Text>
                     </Right>
                   </CardItem>
                   </TouchableOpacity>

                   {/* <CardItem style={otherCardItemStyle}>
                     <Right>
                     <TouchableOpacity onPress={this.changelanguage('ar')}>
                       <Text style={otherTextsStyle}>  العربية</Text>
                       </TouchableOpacity>
                     </Right>
                     <Body>
                     <TouchableOpacity onPress={this.changelanguage('en')}>
                         <Text style={otherTextsStyle} >الإنجليزية</Text>
                         </TouchableOpacity>
                     </Body>
                   </CardItem>  */}

                 </List>
                </Content>
           </ImageBackground>
        )
    }
}
const mapStateToProps = state =>
{
  const { user } = state.authReducer;
  const { lang } = state.sideBarReducer;
  return { user,lang};
}
export default connect(mapStateToProps,{signOut,isLoggIn,...sideBarAction})(SideBar);