import React,{Component} from 'react';
import {ImageBackground,Dimensions,Image,TouchableHighlight,TouchableOpacity,Modal,TouchableWithoutFeedback} from 'react-native';
import {CardItem,Body,Button,Text,Right,Left, Icon,View,Item, Content,Input,CheckBox,Card,Label,ListItem} from 'native-base';
import {transparentBackground,centerStyle,sevicesCardItemStyle,servicesText,buttonText,transparentBorder,inputStyle} from '../theme';
import { Actions } from 'react-native-router-flux';
const dimensions=Dimensions.get('window');
import { connect } from 'react-redux';

import {strings} from '../../Locales/i18n';
import * as profileAction from "../actions/profileAction";

class Setting extends Component{
    render(){
        const {user,lang}=this.props;
        console.log("this.props in setting",this.props);
return(
    <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:dimensions.height}}>
    <Content>
    <TouchableOpacity onPress={()=>Actions.profile()}>
  <CardItem style={[transparentBackground,{marginTop:40,direction:lang=='ar'?"rtl":"ltr"}]} bordered>
              <Left>
                 <Text style={{fontSize:10,textAlign:"right",color:"#ffffff",fontFamily:'TajawalRegular0'}}>{strings('setting.profile',lang)}</Text>
              </Left>
              <Right>
                 <Text style={{fontSize:10,textAlign:"right",color:"#ffffff",fontFamily:'TajawalRegular0'}}>{user.data[0].customers_firstname} {user.data[0].customers_lastname}</Text>
              </Right>
            </CardItem>
            </TouchableOpacity>
            <CardItem style={[transparentBackground,{marginTop:40,direction:lang=='ar'?"rtl":"ltr"}]} bordered>
              <Left>
                 <Text style={{fontSize:10,textAlign:lang=='ar'?"right":"left",color:"#ffffff",fontFamily:'TajawalRegular0'}}>{strings('setting.language',lang)}</Text>
              </Left>
              <Right>
                 {lang=='ar'?
                 <Text style={{fontSize:12,textAlign:lang=='ar'?"right":"left",color:"#ffffff",fontFamily:'TajawalBold0'}}>عربي</Text>
                 :
                 <Text style={{fontSize:12,textAlign:lang=='ar'?"right":"left",color:"#ffffff",fontFamily:'TajawalBold0'}}>English</Text>
                 }
              </Right>
            </CardItem>
            <CardItem style={[transparentBackground,{marginTop:40,direction:lang=='ar'?"rtl":"ltr"}]} bordered>
              <Left>
                 <Text style={{fontSize:10,textAlign:lang=='ar'?"right":"left",color:"#ffffff",fontFamily:'TajawalRegular0'}}>{strings('setting.notifications',lang)}</Text>
              </Left>
              <Right>
                 <Text style={{fontSize:10,textAlign:lang=='ar'?"right":"left",color:"#ffffff",fontFamily:'TajawalRegular0'}}>470.00 JOD</Text>
              </Right>
            </CardItem>
            <CardItem style={[transparentBackground,{marginTop:40,direction:lang=='ar'?"rtl":"ltr"}]} bordered>
              <Left>
                 <Text style={{fontSize:10,textAlign:lang=='ar'?"right":"left",color:"#ffffff",fontFamily:'TajawalRegular0'}}>{strings('setting.privacy',lang)}</Text>
              </Left>
              <Right>
                 <Text style={{fontSize:12,textAlign:lang=='ar'?"right":"left",color:"#ffffff",fontFamily:'TajawalBold0'}}>فقط أنا</Text>
              </Right>
            </CardItem>
            </Content>
    </ImageBackground>

)
    }
}
const mapStateToProps = state => {
   const { lang } = state.sideBarReducer;
   return {lang};
 };
 // END MAP STATE TO PROPS
 
 export default connect(mapStateToProps, profileAction)(Setting);