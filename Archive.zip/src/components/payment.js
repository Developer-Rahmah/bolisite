import React, { Component } from 'react';
import {ImageBackground,Dimensions,Image,TouchableHighlight,TouchableOpacity,Modal,TouchableWithoutFeedback,Platform} from 'react-native';
import {CardItem,Body,Button,Text,Right,Left, Icon,View,Item, Content,Input,CheckBox,Card,Label,ListItem,Picker} from 'native-base';
import {transparentBackground,centerStyle,sevicesCardItemStyle,servicesText,buttonText,transparentBorder,inputStyle} from '../theme';
import {Actions} from "react-native-router-flux";
import { connect } from 'react-redux';
import * as paymentAction from '../actions/paymentAction';
const dimensions=Dimensions.get('window');
import {strings} from '../../Locales/i18n';

class Payment extends Component{
  state = {
    form_submitted: false,

  };
    changePaymentOnline=(payment_online)=>{
        const {show_payment_online_modal,show_payment_upon_delivery_modal}=this.props
        this.props.getPaymentTexts({
                  prop: "payment_online",
                  value: !payment_online
                })
            
                if(!payment_online)
                this.props.showPaymentOnlineModal(!show_payment_online_modal)
             
    }
    changePaymentUponDelivery=(payment_upon_delivery)=>{
        const {show_payment_upon_delivery_modal,payment_online}=this.props
        this.props.getPaymentTexts({
                  prop: "payment_upon_delivery",
                  value: !payment_upon_delivery
                })
       
                if(!payment_upon_delivery)
                this.props.showPaymentUponDeliveryModal(!show_payment_upon_delivery_modal)
             
    }
  render(){
      console.log("this.props in payment",this.props)
  const{payment_online,payment_upon_delivery,show_payment_online_modal,show_payment_upon_delivery_modal,data,months,payment_info_name,payment_info_credit_Card,payment_info_cvv,payment_info_ExMonth,payment_info_ExYear,lang}=this.props;
  const {form_submitted}=this.state
    return(

      <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
        <Content>
        <CardItem style={[sevicesCardItemStyle, {width: dimensions.width}]}>
          <Right>
            <Text style={servicesText}>{strings('payment.payment',lang)}</Text>
          </Right>
        </CardItem>
        <CardItem style={transparentBackground}>
          <Item style={transparentBorder}> 
            <Input
              color="#fff"
              onChangeText={value =>this.props.getUserText({prop:'password',value})}
              value =""
              placeholder ={strings('payment.name_of_insured',lang)}
              style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=="ar"?"right":"left"}]}
            />
              </Item>
            </CardItem>
            <CardItem style={transparentBackground}>
          <Item style={transparentBorder}> 
            <Input
              color="#fff"
              onChangeText={value =>this.props.getUserText({prop:'password',value})}
              value =""
              placeholder ={strings('carInformation.car_type',lang)}
              style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=="ar"?"right":"left"}]}
            />
              </Item>
            </CardItem>
            <CardItem style={transparentBackground}>
          <Item style={transparentBorder}> 
            <Input
              color="#fff"
              onChangeText={value =>this.props.getUserText({prop:'password',value})}
              value =""
              placeholder ={strings('payment.insurance_company',lang)}
              style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=="ar"?"right":"left"}]}
            />
              </Item>
            </CardItem>
        
            <View style={{marginRight:30,marginTop:20}}>
              <Text style={{fontSize:16,textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBlack0'}}>{strings('payment.Additional_Services',lang)}</Text>     
            </View>
            <View style={{marginRight:30,marginTop:15}}>
              <Text style={{fontSize:14,textAlign:lang=='ar'?"right":"left",color:"gray",fontFamily:'TajawalBold0'}}> لوريم ايبسوم دولار سيت أميت </Text>     
            </View>
            <View style={{marginRight:30,marginTop:15}}>
              <Text style={{fontSize:14,textAlign:lang=='ar'?"right":"left",color:"gray",fontFamily:'TajawalBold0'}}> لوريم ايبسوم دولار سيت أميت </Text>     
            </View>
            <CardItem style={[transparentBackground,{marginTop:40,direction:lang=='ar'?"rtl":"ltr"}]} bordered>
              <Left>
                 <Text style={{fontSize:16,textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBlack0'}}>{strings('payment.total',lang)}</Text>
              </Left>
              <Right>
                 <Text style={{fontSize:16,textAlign:lang=='ar'?"right":"left",color:"#171717",fontFamily:'TajawalBlack0'}}>470.00 JOD</Text>
              </Right>
            </CardItem>
           
            <CardItem style={[transparentBackground,{marginTop:40,direction:lang=='ar'?"rtl":"ltr"}]} bordered>
              {Boolean(data.accept_visa)?
                            <Left>

              <CheckBox
                        style={{marginRight:15,borderRadius:30}}
                        checked={payment_online}
                        color="#003580"
                        onPress={() =>this.changePaymentOnline(payment_online)
                      
                    }
                        // onPress={() =>
                        //     this.props.getPaymentTexts({
                        //       prop: "payment_online",
                        //       value: !payment_online
                        //     })
                        //   }
                      /> 
                      <Text style={{fontFamily:"TajawalMedium0",fontSize:12}}>{strings('payment.Online_payment',lang)}</Text>
                   
                      </Left>
                      :null}
                      {Boolean(data.accept_cash)?
              <Right>

              <CheckBox
                        style={{borderRadius:30}}
                        checked={payment_upon_delivery}
                        color="#003580"
                        onPress={() =>this.changePaymentUponDelivery(payment_upon_delivery)
                            // this.props.getPaymentTexts({
                            //   prop: "payment_upon_delivery",
                            //   value: !payment_upon_delivery
                            // })
                          }
                      /> 
                                    <Text style={{fontFamily:"TajawalMedium0",fontSize:12}}>{strings('payment.Payment_upon_delivery',lang)}</Text>

                      </Right>
                      :null}
            </CardItem>
            <Modal
            visible={show_payment_online_modal}
            animationType={"slide"}
            onRequestClose={() =>
              this.props.showPaymentOnlineModal(!show_payment_online_modal)
            }
            supportedOrientations={[
              "portrait",
              "portrait-upside-down",
              "landscape",
              "landscape-left",
              "landscape-right"
            ]}
            transparent
          >
             <TouchableWithoutFeedback
              onPress={() => this.props.showPaymentOnlineModal(!show_payment_online_modal)}
            >
              <View style={{backgroundColor:'rgba(0,0,0,0.50)',position:'relative',flex:1,justifyContent:'center'}}>
                <View style={{  borderWidth:1,borderRadius:5,borderColor:'#e3e3e3',padding:0,backgroundColor:'#fff',marginLeft:15,marginRight:15}}>
                    <CardItem>
                  <Label style={{
                    fontSize:8,fontFamily:"arialbd",
                      color:
                        form_submitted && payment_info_credit_Card == ""
                          ? "red"
                          : "#171717"
                    }}>Card Number</Label>
                  </CardItem>
                  <CardItem>
                  <Item regular>
                  <Input
                  style={{fontFamily:'TajawalRegular0',}}
                    maxLength={16}
                    autoCorrect={false}
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_credit_Card",
                        value
                      })
                    }
                    value={payment_info_credit_Card}
                    placeholder="1234   5678   3456   2456"
                    placeholderTextColor="gray"
                  />
                </Item>
                  </CardItem>
                  <CardItem>
                  <Label style={{
                    fontSize:8,fontFamily:"arialbd",
                      color:
                        form_submitted && payment_info_name == ""
                          ? "red"
                          : "#171717"
                    }}>CARDHOLDER NAME</Label>
         
                  </CardItem>
                  <CardItem>
            <Item regular>
              <Input
              style={{fontFamily:'TajawalRegular0',}}
                autoCorrect={false}
                onChangeText={value =>
                  this.props.getPaymentTexts({
                    prop: "payment_info_name",
                    value
                  })
                }
                value={payment_info_name}
                placeholder="e.g John Doe"
                placeholderTextColor="gray"
              />
            </Item>
                  </CardItem>
                  <CardItem>
                  <Label style={{
                    fontSize:8,fontFamily:"arialbd",
                      color:
                        form_submitted && payment_info_ExMonth== "" &&payment_info_ExYear==""
                          ? "red"
                          : "#171717"
                    }}> EXPIRE DATE</Label>
                  </CardItem>
                  <CardItem>
                    <Left>
                  <Item>
                  <Picker
                    mode="dropdown"
              
                    // iosHeader="Expiry Month"
                    placeholder="Expiry Month"
                    iosIcon={<Icon name="ios-arrow-down" />}
                    style={{fontFamily:'TajawalRegular0', width: Platform.OS === "ios" ? 120 : 120}}
                    selectedValue={payment_info_ExMonth}
                    placeholderTextColor={
                      form_submitted && payment_info_ExMonth == ""
                        ? "red"
                        : "gray"
                    }
                    onValueChange={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_ExMonth",
                        value
                      })
                    }
                  >
                    {months.map((item, index) => {
                      return (
                        <Picker.Item
                          key={item.id}
                          style={{fontFamily:'TajawalRegular0',}}
                          label={item.month}
                          value={item.value}
                        />
                      );
                    })}
                  </Picker>
                </Item>
                </Left>
                <Right>
                <Item inlineLabel>
                  {/* <Label
                    style={{
                      color:
                        payment_info_ExYear == ""
                          ? "red"
                          : "#646464"
                    }}
                  >
                    Expiry Year
                  </Label> */}
                  <Input
                  style={{fontFamily:'TajawalRegular0',}}
                    maxLength={4}
                    autoCorrect={false}
                    placeholder="Expiry Year"
                    placeholderTextColor={
                      form_submitted && payment_info_ExYear == ""
                        ? "red"
                        : "gray"
                    }
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_ExYear",
                        value
                      })
                    }
                    value={payment_info_ExYear}
                  />
                </Item>
                </Right>
            </CardItem>
            <CardItem>
              <Label style={{
                    fontSize:8,fontFamily:"arialbd",
                      color:
                        form_submitted && payment_info_cvv == ""
                          ? "red"
                          : "#171717"
                    }}> CVV</Label>
            </CardItem>
             <CardItem>
                 <Item regular>
                 <Input
                 style={{fontFamily:'TajawalRegular0',}}
                    maxLength={3}
                    placeholder="e.g 123"
                    placeholderTextColor={
                      form_submitted && payment_info_cvv == ""
                        ? "red"
                        : "gray"
                    }
                    autoCorrect={false}
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_cvv",
                        value
                      })
                    }
                    value={payment_info_cvv}
                  />
                 </Item>
             </CardItem>
             <ListItem>
                    <Left>
                    <CheckBox
                        style={{marginRight:15,borderRadius:50}}
                        checked={false}
                        color="#003580"
                    
                      />
                    <Text style={{fontSize:8,fontFamily:"arialbd"}}>SAVE CARD</Text>
                    </Left>
                  </ListItem>

                  <ListItem style={{borderBottomWidth: 0}}>
                    <Body>
                    <Button style={{backgroundColor:"#003580"}}block onPress={()=>this.setState({form_submitted:true})}>
                      <Text style={buttonText}>{strings('payment.Pay_now',lang)}</Text>
                    </Button>
                    </Body>
                  </ListItem>
                </View>
              </View>
              </TouchableWithoutFeedback>
          </Modal>
          {/* ***************** */}
          <Modal
            visible={show_payment_upon_delivery_modal}
            animationType={"slide"}
            onRequestClose={() =>
              this.props.showPaymentUponDeliveryModal(!show_payment_upon_delivery_modal)
            }
            supportedOrientations={[
              "portrait",
              "portrait-upside-down",
              "landscape",
              "landscape-left",
              "landscape-right"
            ]}
            transparent
          >
             <TouchableWithoutFeedback
              onPress={() => this.props.showPaymentUponDeliveryModal(!show_payment_upon_delivery_modal)}
            >
              <View style={{backgroundColor:'rgba(0,0,0,0.50)',position:'relative',flex:1,justifyContent:'center'}}>
                <View style={{  borderWidth:1,borderRadius:5,borderColor:'#e3e3e3',padding:0,backgroundColor:'#fff',marginLeft:15,marginRight:15}}>
                    <CardItem>
                  <Label style={{fontSize:8,fontFamily:"arialbd"}}>Address</Label>
                  </CardItem>
                  <CardItem>
                  <Item regular>
                  <Input
                  style={{fontFamily:'TajawalRegular0',}}
                    maxLength={16}
                    autoCorrect={false}
                    onChangeText={value =>
                      this.props.getPaymentTexts({
                        prop: "payment_info_credit_Card",
                        value
                      })
                    }
                    value=""
                    placeholder="Address"
                    placeholderTextColor="gray"
                  />
                </Item>
                  </CardItem>
 
                </View>
              </View>
              </TouchableWithoutFeedback>
          </Modal>
        </Content>
      </ImageBackground>
        )
    }
}
// START MAP STATE TO PROPS
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;
    const { payment_online,payment_upon_delivery,show_payment_online_modal,show_payment_upon_delivery_modal,months,payment_info_name,payment_info_credit_Card,payment_info_cvv,payment_info_ExMonth,payment_info_ExYear} = state.paymentReducer;
    return {  payment_online,payment_upon_delivery,show_payment_online_modal,show_payment_upon_delivery_modal,months,payment_info_name,payment_info_credit_Card,payment_info_cvv,payment_info_ExMonth,payment_info_ExYear,lang};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,paymentAction)(Payment);