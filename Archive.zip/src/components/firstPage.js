import React,{Component} from 'react';
import {ImageBackground,Dimensions,Text,AsyncStorage,TouchableOpacity,Image,View} from 'react-native';
import {Body,CardItem,Button,Root} from 'native-base';
import {Actions} from "react-native-router-flux";
import{centerStyle,buttonText} from '../theme'
import {cardItem,signInButton,signInText,orText,signUpButton} from '../assests/styles/firstPageStyles';
import {strings} from '../../Locales/i18n';
import * as sideBarAction from '../actions/sideBarAction';
import { connect } from 'react-redux';
import { SocialIcon } from 'react-native-elements';
import { Font, AppLoading,SplashScreen} from 'expo';
import Expo from 'expo';


const dimensions=Dimensions.get('window');
class FirstPage extends Component{
  constructor(props) {
    super(props);
  this.state={language:"",
loading:true,
isReady: false,
}}
  // componentWillMount() {
  //   AsyncStorage.getItem("locale").then((value) => {
 
  //     this.setState({language:value})
  //     });
  
    
  // }
  async  componentDidMount() {
    SplashScreen.preventAutoHide();



   

}

  async componentWillMount() {
    AsyncStorage.getItem("locale").then((value) => {
 
      this.setState({language:value})
      });
  
    await Font.loadAsync({
      arial: require("../../assets/fonts/arial.ttf"),
      arialbd:require("../../assets/fonts/arialbd.ttf"),
      arialbi:require("../../assets/fonts/arialbi.ttf"),
      ariali:require("../../assets/fonts/ariali.ttf"),
      ariblk:require("../../assets/fonts/ariblk.ttf"),
      TajawalBlack0:require("../../assets/fonts/TajawalBlack0.ttf"),
      TajawalBold0:require("../../assets/fonts/TajawalBold0.ttf"),
      TajawalExtraBold0:require("../../assets/fonts/TajawalExtraBold0.ttf"),
      TajawalExtraLight0:require("../../assets/fonts/TajawalExtraLight0.ttf"),
      TajawalLight0:require("../../assets/fonts/TajawalLight0.ttf"),
      TajawalMedium0:require("../../assets/fonts/TajawalMedium0.ttf"),
      TajawalRegular0:require("../../assets/fonts/TajawalRegular0.ttf"),



    });
    this.setState({ loading: false });
  }

    render(){


//       if (!this.state.isReady) {


//         return (
//             <View style={{ height: Dimensions.get('window').height, width: Dimensions.get('window').width, }}>

//                 <ImageBackground 
//                 source={require('../assests/images/splash–1.png')}
//                 style={{ height: Dimensions.get('window').height, width: Dimensions.get('window').width, justifyContent: 'center', alignItems: 'center', }}
// >                   
//  <View style={{ height: Dimensions.get('window').height / 5 }}>
//                     </View>

//                     <Image
//                         source={require('../assests/images/Artboard–3.png')}
//                         style={{
//                             width: 214.1,
//                             height: 60.1, paddingTop: 2,
//                             resizeMode: 'contain'
//                         }}
//                         onLoad={this._cacheResourcesAsync}
//                     />
//                     <View style={{ height: Dimensions.get('window').height / 2.5 }}>


//                     </View>
                    
//                 </ImageBackground>

//             </View>
//         );
//     }

      if (this.state.loading) {
        return (
          <Root>
            <AppLoading />
          </Root>
        );
      }

console.log("this.state.language",this.state.language)
      const {lang}=this.props
   console.log("lang in first ",lang)
  
      return(
<ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:dimensions.height}}>
<CardItem style={cardItem}>
         <Body style={centerStyle}>
          <Button style={signInButton}block onPress={() => Actions.login()}>
            <Text style={signInText}>{strings('login.login_button',lang)}</Text>
          </Button>
          <Text style={orText}>{strings('login.or',lang)}</Text>
          <Button style={signUpButton}block onPress={() => Actions.signup()}>
            <Text style={buttonText}>{strings('login.signup_button',lang)}</Text>
          </Button>
          <View style={{height:25}}/>
       







<View style={{ width: Dimensions.get('window').width, alignItems: 'center' ,marginTop:15}}>
                        <Text style={[orText,{marginBottom:10}]}>{strings('login.orSignUpWith',lang)}</Text></View>

                    <View style={{ flexDirection: 'row', width: Dimensions.get('window').width, justifyContent: 'center' }}>
                        <TouchableOpacity style={{ flexDirection: 'row', borderRadius: 5, backgroundColor: 'rgba(59, 89, 152, 1)', width: Dimensions.get('window').width / 2.4, height: 48, alignItems: 'center' ,justifyContent:'center'}}>

                            <SocialIcon type='facebook' style={{ width: 36, height: 36, elevation: 0, backgroundColor: null }} />
                            <Text style={{
                                width: Dimensions.get('window').width / 4, alignItems: 'center', fontSize: 16,
                                fontWeight: "normal",marginStart:-3,marginTop:3,
                                fontStyle: "normal",
                                lineHeight: 19, color: 'white', fontFamily: 'TajawalMedium0'
                            }}>{strings('login.signInWithFacebook',lang)}</Text>
                              
                        </TouchableOpacity>

                        <View style={{ width: 14 }} />
                        <TouchableOpacity style={{ flexDirection: 'row', marginBottom: 20, borderRadius: 5, backgroundColor: '#f24a38', width: Dimensions.get('window').width / 2.4, height: 48, alignItems: 'center' ,justifyContent:'center'}}>

                            <Image
                                source={require('../../assets/g.png')}
                                style={{
                                    width: 25,
                                    height: 25, marginEnd: 7, marginStart: 15,
                                    resizeMode: 'contain'
                                }} />
                            <Text style={{
                               width: Dimensions.get('window').width / 4,
                                 alignItems: 'center', fontSize: 16,marginStart:5,
                                fontWeight: "normal", fontFamily: 'TajawalMedium0',marginTop:3,
                                
                                lineHeight: 19, color: 'white'
                            }}>{strings('login.signInWithGoogle',lang)}</Text>
                        </TouchableOpacity>
                    </View>
         </Body>
        </CardItem>
</ImageBackground>
      )

      
    }
    _cacheSplashResourcesAsync = async () => {
      const gif = require('../assests/images/Artboard–3.png');
      return Asset.fromModule(gif).downloadAsync()
  }

  _cacheResourcesAsync = async () => {
      SplashScreen.hide();
      const images = [
          require('../assests/images/Artboard–3.png'),
          require('../assests/images/Artboard–3.png'),
      ];

      const cacheImages = images.map((image) => {
          return Asset.fromModule(image).downloadAsync();
      });

      await Promise.all(cacheImages);
      this.setState({ isReady: true });
  }
}
// export default FirstPage;
const mapStateToProps = state =>
{
  const { lang } = state.sideBarReducer;
  return {lang};
}
export default connect(mapStateToProps,{sideBarAction})(FirstPage);