import React, { Component } from 'react';
import {ImageBackground,Dimensions,ScrollView,View,Image} from 'react-native';
import {CardItem,Body,Button,Text, Icon,Form,Item,Input,Picker,Right,Left,Card} from 'native-base';
import {transparentBackground,transparentBorder,inputStyle,centerStyle,buttonStyle,buttonText,pickerStyle,datePickerStyle} from '../theme';
import * as cancerCareProgramAction from '../actions/cancerCareProgramAction';
import DropdownAlert from 'react-native-dropdownalert';
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';
const dimensions=Dimensions.get('window');
class CancerCareProgram extends Component{

    componentDidUpdate (){
        const { cancer_care_program_msg} = this.props;
         if (cancer_care_program_msg != null) {
           setTimeout(()=> this.props.resetCancerCareProgramMessage(),300);
         }
      }

    //START DROPDOWN MESSAGES
  onError = (error) => {
    if (error) {
    console.log("error",error)
    this.dropdown.alertWithType('error', 'Error', error);
  }
}

  onSuccess = success => {
    if (success) {
    this.dropdown.alertWithType('success', 'Success', success);
  }
}
 
//END DROPDOWN MESSAGES
     //START SHOW ALERT FUNC
     showAlert = () => {
      const {cancer_care_program_msg} = this.props;
      if (cancer_care_program_msg != null) {
        if (cancer_care_program_msg.isError) {
          this.onError(cancer_care_program_msg.msg);
        } else if (cancer_care_program_msg.isSuccess) {
          this.onSuccess(cancer_care_program_msg.msg);
        } else {
          return;
        }
      }
    };
    goFromCancerCareProgram=()=>{
        const {full_name, id_number,user_id} = this.props;
        this.props.goFromCancerCareProgram(full_name, id_number,user_id);
    
 
      }
    render(){
      console.log("this.props in car information",this.props)
      const {full_name,id_number,lang}=this.props


        return(

            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
                      <ScrollView ref={(ref)=> {this._scrollView = ref}}>

              <Card style={{backgroundColor:'transparent',borderColor:'transparent'}}>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={full_name}
                     placeholder ={strings('carInformation.full_name',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getCancerCareProgramTexts({prop:"full_name",value})}
                   />
                 </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={id_number}
                     placeholder ={strings('carInformation.id_number',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getCancerCareProgramTexts({prop:"id_number",value})}
                   />
                 </Item>
               </CardItem>
     
         
               <CardItem style={transparentBackground}>
               
                <Body style={centerStyle}>
               
                  <Button style={buttonStyle}  block onPress={this.goFromCancerCareProgram}>
                  {lang=='ar'?
                    <Icon name='md-arrow-back' style={{color:'#fff'}}/>
                    :null}
                    <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
                    {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                  </Button>
                </Body>
            </CardItem>

            </Card>
           

            </ScrollView>
            <Text>{this.showAlert()}</Text>

<DropdownAlert ref={ref => (this.dropdown = ref)} style={{fontFamily:'TajawalRegular0',}} />
            </ImageBackground>

            

        )
    }
}
// export default LifeInsurance;
const mapStateToProps = state => {
    const { lang } = state.sideBarReducer;
    const { full_name,id_number,cancer_care_program_msg} = state.cancerCareProgramReducer;
    return {full_name,id_number,cancer_care_program_msg,lang};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,cancerCareProgramAction)(CancerCareProgram);