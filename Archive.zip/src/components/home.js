import React,{Component} from 'react';
import {ImageBackground,Dimensions,Text,ScrollView,View,TouchableOpacity,Image,AsyncStorage} from 'react-native';
import {CardItem,Card,Left,Right,Body,Container,Content} from 'native-base';
import{Bold} from './common/Bold';
import {imagesStyle,imagesCradItem,categoriesText} from '../assests/styles/homeStyles';
import {centerStyle,servicesText,sevicesCardItemStyle,transparentBackGround} from '../theme';
import {Actions} from "react-native-router-flux";
import {Spinner} from "./common/Spinner";
import * as homeAction from '../actions/homeAction';
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';

const IMAGE_BASE_URL='https://bolisati1.qiotic.info/'
const dimensions=Dimensions.get('window');
class Home extends Component{
  constructor(props){
    super(props);
    this.state ={
      user_id:0
    }
  }
    componentWillMount() {
      const {lang}=this.props;
      if(lang=='en'){
        this.props.getCategories(1);
      }
      else if (lang=='ar'){
        this.props.getCategories(4);

      }
        
      }
      componentDidMount() {
        AsyncStorage.getItem('user', (err, result) => {
          console.log("result", JSON.parse(result))
          result=JSON.parse(result)
         if (result != null) {
           this.setState({ user_id: result[0].customers_id });
         }
     
        
       });
     }
     goTo=(category)=>{
       console.log("category name",category)
       if (category=="تأمين السيارة"){
      Actions.drivinglicense({user_id:this.state.user_id})
       }
       else if (category=="تأمين الحياة"){
         Actions.lifeinsurance({user_id:this.state.user_id})
        // Actions.test()
       }
       else if(category=="تأمين السفر"){
        Actions.travelinsurance({user_id:this.state.user_id})

       }
       else if (category== "برنامج رعاية السرطان"){
        Actions.cancercareprogram({user_id:this.state.user_id})

       }
       else if(category== "تأمين الشحن"){
        Actions.shippinginsurance({user_id:this.state.user_id})

       }
     }
render(){
    const {categories,home_loading,lang}=this.props;
    console.log("this.state.user_id",this.state.user_id)
    console.log("categories",categories);
    return(
        // <ScrollView ref={(ref)=> {this._scrollView = ref}}>
        <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>

<Container style={{backgroundColor:"transparent"}}>
<Content style={{backgroundColor:"transparent"}}>
{!home_loading?
(categories.length>0?
<View style={[imagesCradItem,{width:dimensions.width}]}>
{categories.map((category, index) => {
 return (
    
  <View style={[imagesCradItem,{width:dimensions.width}]} key={category.id}>
<TouchableOpacity onPress={() => this.goTo(category.name)}>


<ImageBackground source={{uri: `${IMAGE_BASE_URL}${category.image}`}} style={imagesStyle}>

<CardItem style={{backgroundColor:'transparent',display:'flex',direction:lang=='ar'?'rtl':'ltr',marginTop:50}}>

<Image source={{uri: `${IMAGE_BASE_URL}${category.icon}`}} style={{height:50,width:50,marginRight:-40}}/>
<View style={{marginLeft:50}}>
<Text style={{color:"#ffffff",fontSize:17,fontFamily:'TajawalBold0',marginRight:30}}>
     {category.name}
    </Text>
    {lang=='ar'?
<Text style={{color:"#ffffff",fontSize:10,fontFamily:'TajawalBold0'}}>
{category.descriptionar}
</Text>
:
<Text style={{color:"#ffffff",fontSize:10,fontFamily:'TajawalBold0'}}>
{category.description}
</Text>}
</View>

</CardItem>


</ImageBackground> 
 </TouchableOpacity>
     </View>
   )

})}
 </View>
 :null)
 :
//  <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>

 <CardItem style={{backgroundColor:'tranparent'}} >
 <Body>
   <View style={{  alignItems:'center',alignSelf:'center',justifyContent:'center',marginTop:250}}>
     <Spinner Size="large" color="#003580" />
   </View>
 </Body>
</CardItem>
// </ImageBackground>
} 
 </Content>
</Container>
</ImageBackground>


    )
}
}
// export default Home

// START MAP STATE TO PROPS
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;

    const { categories,home_loading} = state.homeReducer;
    return { categories,home_loading,lang};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,homeAction)(Home);