import React, { Component } from 'react';
import {ImageBackground,Dimensions,Image,TouchableHighlight,TouchableOpacity} from 'react-native';
import {CardItem,Body,Button,Text,Right,Left, Icon,View,Item, Content} from 'native-base';
import * as damageStepAction from '../actions/damageStepAction';
import { connect } from 'react-redux';
import {transparentBackground,centerStyle,sevicesCardItemStyle,servicesText,buttonText,whiteBackground} from '../theme';
import {Actions} from "react-native-router-flux";
// import {RNCamera,Camera} from 'react-native-camera';
// import {RNCamera} from 'react-native-camera';
// import DeviceInfo from 'react-native-device-info';
import {strings} from '../../Locales/i18n';
import {  ImagePicker, Camera, Permissions } from 'expo';

// const deviceId = DeviceInfo.getDeviceId();
const dimensions=Dimensions.get('window');
class DamageStep extends Component{
  constructor(props){
    super(props);
    this.state ={
      showCameraView1:false ,
      showCameraView2:false ,
      showCameraView3:false ,
      showCameraView4:false ,
      type: Camera.Constants.Type.back,
      leftCarPic: null,
      rightCarPic:null,
      frontCarPic: null,
      backCarPic: null,

      cameraPermission: null,
      cameraRollPermission: null,
    leftImage:{},
    rightImage:{},
    frontImage:{},
    backImage:{}
   }
  }
  // clicked(){
  //   alert('was touched')
  //     }
  clicked(){
    alert('was touched')
      }
// gotToPayment=(leftImage,rightImage,frontImage,backImage)=>{
//   const {carInformation,insuranceCompaanyId,addons,total,user_id}=this.props
//  var addons1=[]
//  for(var i=0;i<addons.length;i++){
//    addons1.push(addons[i].id)
//  }
//  leftImage.base64='data:image/jpg;base64,'+leftImage.base64
//  rightImage.base64='data:image/jpg;base64,'+rightImage.base64
//  frontImage.base64='data:image/jpg;base64,'+frontImage.base64
//  backImage.base64='data:image/jpg;base64,'+backImage.base64
//   var images=[]
//   images.push({leftImage:leftImage});
//   images.push({rightImage:rightImage});
//   images.push({frontImage:frontImage});
//   images.push({backImage:backImage});
//   var image_test=source=require('../assests/images/a.jpg')
//   console.log("images",images)
//   console.log("images[0",images[0].leftImage.uri)
//   var data = new FormData();  
//   data.append('full_name', carInformation.full_name)
//   data.append('id_number', carInformation.id_number)
//   data.append('insurance_type',carInformation.insurance_type)
//   data.append('car_type',carInformation.car_type)
//   data.append('vehicle_number',carInformation.vehicle_number)
//   data.append('car_model',carInformation.car_model)
//   data.append('manufacturing_year',carInformation.manufacturing_year)
//   data.append('driver',carInformation.driver)
//   data.append('fuel_type',carInformation.fuel_type)
//   data.append('car_salary',carInformation.car_salary)
//   data.append('start_date',carInformation.start_date)
//   data.append('end_date',carInformation.end_date)
//   data.append('addons',addons1)
//   data.append('insuranceCompaanyId',insuranceCompaanyId)
//   data.append('total',total)
//   data.append('leftImage',images[0].leftImage.uri)
//   data.append('user_id',user_id)
// console.log("data555",data)
//   const headers = { 
//     'content-type': 'multipart/form-data;',
//     'consumer-key':'6df56cf915318431043dd7a75d',
//     'consumer-secret':'95032b42153184310488f5fb8f',
//     'consumer-nonce':'afczxcfasd',
//     'consumer-device-id':deviceId
  
//    }
//   const config = { 
//     method: 'POST', 
//     headers,
//     body: data
//    };
//    console.log("config",config)
//   const URL = 'https://bolisati1.qiotic.info/app/addneworder';
//   fetch(URL, config ).then(res=>{
//     console.log('response',res)
//   })
// }

gotToPayment=(leftImage,rightImage,frontImage,backImage)=>{
  const {carInformation,insuranceCompaanyId,addons,total,user_id}=this.props
 var addons1=[]
 for(var i=0;i<addons.length;i++){
   addons1.push(addons[i].id)
 }
  leftImage.base64='data:image/jpg;base64,'+leftImage.base64
 rightImage.base64='data:image/jpg;base64,'+rightImage.base64
 frontImage.base64='data:image/jpg;base64,'+frontImage.base64
 backImage.base64='data:image/jpg;base64,'+backImage.base64

  var images=[]
  images.push({leftImage:leftImage});
  images.push({rightImage:rightImage});
  images.push({frontImage:frontImage});
  images.push({backImage:backImage});
  var image_test=source=require('../assests/images/a.jpg')
  console.log("images",images)
  console.log("images[0",images[0].leftImage.uri)
  var formData = new FormData();
   // formData.append('rightImage', {
   //   right_uri,
   //   name: `rightImage.${fileType2}`,
   //   type: `image/${fileType2}`,
   // });
   // formData2.append('leftImage', {
   //   left_uri,
   //   name: `leftImage.${fileType}`,
   //   type: `image/${fileType}`,
   // });
   // this.setState({formData : formData2})
   // formData.append('frontImage', {
   //   front_uri,
   //   name: `frontImage.${fileType3}`,
   //   type: `image/${fileType3}`,
   // });
   // formData.append('backImage', {
   //   back_uri,
   //   name: `backImage.${fileType4}`,
   //   type: `image/${fileType4}`,
   // });

       formData.append('leftdate', this.state.leftImage.date)
       formData.append('rightdate', this.state.rightImage.date)
       formData.append('frontdate', this.state.frontImage.date)
       formData.append('backdate', this.state.backImage.date)

   formData.append("leftImage", {
     name: 'uiyutesttest5:30.jpg',
     type: 'jpg',
     uri:
       this.state.leftCarPic.replace("file://", "")
   });
   formData.append("rightImage", {
     name: 'uiyutesttest5:30.jpg',
     type: 'jpg',
     uri:
       this.state.rightCarPic.replace("file://", "")
   });
   formData.append("frontImage", {
     name: 'uiyutesttest5:30.jpg',
     type: 'jpg',
     uri:
       this.state.frontCarPic.replace("file://", "")
   });
   formData.append("backImage", {
     name: 'uiyutesttest5:30.jpg',
     type: 'jpg',
     uri:
       this.state.backCarPic.replace("file://", "")
   });
   let options = {
     method: 'POST',
     body: formData,
     headers: {
       Accept: 'application/x-www-from-urlencoded',
       'Content-Type': 'multipart/form-data',
     },
   };
   fetch(apiUrl, options).then(res=>{
             console.log('response test',res)
   })
  const data={
    full_name: carInformation.full_name,
    id_number: carInformation.id_number,
    insurance_type:carInformation.insurance_type,
    car_type: carInformation.car_type,
    vehicle_number:carInformation.vehicle_number,
    car_model:carInformation.car_model,
    manufacturing_year:carInformation.manufacturing_year,
    driver:carInformation.driver,
    fuel_type:carInformation.fuel_type,
    car_salary:carInformation.car_salary,
    start_date:carInformation.start_date,
    end_date:carInformation.end_date,
    addons:addons1,
    insuranceCompaanyId:insuranceCompaanyId,
    total:total,
    leftImage:images[0].leftImage.uri,
    user_id:user_id
  }
  this.props.sendOrder(data)


}


// gotToPayment=(leftImage,rightImage,frontImage,backImage)=>{

//   const {carInformation,insuranceCompaanyId,addons,total,user_id}=this.props
//   console.log("carInformation",carInformation)
//   console.log("addons",addons)
//  var addons1=[]
//  for(var i=0;i<addons.length;i++){
//    addons1.push(addons[i].id)
//  }
//  console.log("insuranceCompaanyId",insuranceCompaanyId)
//  console.log("carInformation",carInformation)
//  console.log("addons",addons1)
//  console.log("total",total)
//  console.log("user_id",user_id)
//  leftImage.base64='data:image/jpg;base64,'+leftImage.base64
//  rightImage.base64='data:image/jpg;base64,'+rightImage.base64
//  frontImage.base64='data:image/jpg;base64,'+frontImage.base64
//  backImage.base64='data:image/jpg;base64,'+backImage.base64
//   var images=[]
//   images.push({leftImage:leftImage});
//   images.push({rightImage:rightImage});
//   images.push({frontImage:frontImage});
//   images.push({backImage:backImage});
//   var image_test=source=require('../assests/images/a.jpg')
//   console.log("images",images)
//   console.log("images[0",images[0].leftImage.uri)

//   // const headers = { 
//   //   'content-type': 'multipart/form-data;',
//   //   'consumer-key':'6df56cf915318431043dd7a75d',
//   //   'consumer-secret':'95032b42153184310488f5fb8f',
//   //   'consumer-nonce':'afczxcfasd',
//   //   'consumer-device-id':deviceId
  
//   //  }
//   // const config = { 
//   //   method: 'POST', 
//   //   headers,
//   //   body: data
//   //  };
//   //  console.log("config",config)
//   // const URL = 'https://bolisati1.qiotic.info/app/addneworder';
//   // fetch(URL, config ).then(res=>{
//   //   console.log('response',res)
//   // })
//   let apiUrl = 'https://bolisati1.qiotic.info/app/addneworder';

//   let uri=leftImage.uri
//     let uriParts = leftImage.uri.split('.');
//     let fileType = uriParts[uriParts.length - 1];
  
//     let formData = new FormData();
//     // formData.append('leftImage', {
//     //   uri,
//     //   name: `leftImage.${fileType}`,
//     //   type: `image/${fileType}`,
//     // });
//     formData.append('full_name', carInformation.full_name)
//     formData.append('id_number', carInformation.id_number)
//     formData.append('insurance_type',carInformation.insurance_type)
//     formData.append('car_type',carInformation.car_type)
//     formData.append('vehicle_number',carInformation.vehicle_number)
//     formData.append('car_model',carInformation.car_model)
//     formData.append('manufacturing_year',carInformation.manufacturing_year)
//     formData.append('driver',carInformation.driver)
//     formData.append('fuel_type',carInformation.fuel_type)
//     formData.append('car_salary',carInformation.car_salary)
//     formData.append('start_date',carInformation.start_date)
//     formData.append('end_date',carInformation.end_date)
//     formData.append('addons',addons1)
//     formData.append('insuranceCompaanyId',insuranceCompaanyId)
//   formData.append('total',total)
//   formData.append('user_id',user_id)
//     let options = {
//       method: 'POST',
//       body: formData,
//       headers: {
//         // Accept: 'application/json',
//         'Content-Type': 'multipart/form-data',
//         "consumer-key":"6df56cf915318431043dd7a75d",
//         "consumer-secret":"95032b42153184310488f5fb8f",
//         "consumer-nonce":"afczxcfasd",
//         "consumer-device-id":deviceId
//       },
//     };
  
//     return fetch(apiUrl, options).then(res=>{
//         console.log('response',res)
//       });
// }
async componentWillMount() {
    
  this.setState({ loading: false });
  const { status } = await Permissions.askAsync(Permissions.CAMERA);
  this.setState({ hasCameraPermission: status === 'granted' });
}


async componentDidMount() {
  const cameraPermission = await Permissions.getAsync(Permissions.CAMERA)
  const cameraRollPermission = await Permissions.getAsync(Permissions.CAMERA_ROLL);

  this.setState({
      cameraPermission: cameraPermission.status,
      cameraRollPermission: cameraRollPermission.status,
  })
}
takePicture = async function(a) {

  if (this.camera) {
    const options = { quality: 0.5, base64: true };
    const data = await this.camera.takePictureAsync(options);

    console.log("data",data)
    console.log(data.uri);
    if(a=="Left")
    {
    this.setState({leftImage:data})
    this.setState({showCameraView1:false})
    this.state.leftImage.date=Date()
    }
    else if(a=="Right")
    {
      this.setState({rightImage:data})
      this.setState({showCameraView2:false})
      this.state.rightImage.date=Date()
    }
    else if(a=="Front")
    {
      this.setState({frontImage:data})
      this.setState({showCameraView3:false})
      this.state.frontImage.date=Date()
    }
    else if(a="Back")
    {
      this.setState({backImage:data})
      this.setState({showCameraView4:false})
      this.state.backImage.date=Date()

    }

  }
};

    render(){
      let { leftCarPic } = this.state;
      let { rightCarPic } = this.state;
      let { frontCarPic } = this.state;
      let { backCarPic } = this.state;

      console.log("this.props in damage step",this.props)
      const{imageView,showCameraView,leftImage,rightImage,frontImage,backImage}=this.state
      const {lang}=this.props
 
        return(

            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>

<Content>

<CardItem style={[sevicesCardItemStyle, {width: dimensions.width}]}>
      {lang=='ar'?
                <Right style={{marginLeft:100}}>
                  <Text style={servicesText}>{strings('damagestep.Car_photos',lang)}</Text>
                </Right>
                :
                <Left style={{marginLeft:100}}>
                <Text style={servicesText}>{strings('damagestep.Car_photos',lang)}</Text>
              </Left>
}
              </CardItem>
            <CardItem style={{width: dimensions.width,backgroundColor:"#fff",height:120,marginTop:15,flexDirection:'row'}}>
            
              {/* <Image source={{ uri: leftCarPic }} style={{height:100,width:100}}/> */}
            
    {leftCarPic &&
        <Image source={{ uri: leftCarPic }} style={{ width: 100, height: 100,  }} />}
        {rightCarPic &&
        <Image source={{ uri: rightCarPic }} style={{ width: 100, height: 100, }} />}
        {frontCarPic &&
        <Image source={{ uri: frontCarPic }} style={{ width: 100, height: 100,  }} />}
        {backCarPic &&
        <Image source={{ uri: backCarPic }} style={{ width: 100, height: 100,  }} />}

{/* 
              <Image source={{uri: `${rightImage.uri}`}} style={{height:100,width:100}}/>
              <Image source={{uri: `${frontImage.uri}`}} style={{height:100,width:100}}/>
              <Image source={{uri: `${backImage.uri}`}} style={{height:100,width:100}}/> */}


            </CardItem>
        
            
              <CardItem style={transparentBackground}>
            <View style={{flexDirection:'row',width:dimensions.width,justifyContent:'space-between',}}>
                <Body style={{borderColor: "transparent",display:'flex',flexDirection: 'row',alignItems:'center', justifyContent: 'space-between',marginTop:20}}>
                <Button style={whiteBackground}
                // onPress={() =>this.setState({showCameraView3:true})}
                onPress={()=>{ this._takePictureF() } }     
                >
                {Object.keys(frontImage).length > 0?
                   <Icon name='md-checkmark-circle' style={{color:'green'}}/> 
                   :null}
                   <Text style={{color:'#003580',fontFamily:'TajawalRegular0'}}>{strings('damagestep.front',lang)}</Text>
                
                   </Button>
                  <Button style={whiteBackground} 
                  // onPress={() =>this.setState({showCameraView4:true})}
                  onPress={()=>{ this._takePictureB() } }     
                   >
                  {Object.keys(backImage).length > 0?
                   <Icon name='md-checkmark-circle' style={{color:'green'}}/> 
                   :null}
                  <Text style={{color:'#003580',fontFamily:'TajawalRegular0'}}>{strings('damagestep.back',lang)}</Text>
                 
                  </Button>
               
                </Body>

                <Body style={{borderColor: "transparent",display:'flex',flexDirection: 'row',alignItems:'center', justifyContent: 'space-between',marginTop:20}}>
                <Button style={whiteBackground}
  onPress={()=>{ this._takePicture() } }                >
                {Object.keys(frontImage).length > 0?
                   <Icon name='md-checkmark-circle' style={{color:'green'}}/> 
                   :null}
                   <Text style={{color:'#003580',fontFamily:'TajawalRegular0'}}>{strings('damagestep.left',lang)}</Text>
                
                   </Button>
                  <Button style={whiteBackground} 
 onPress={()=>{ this._takePictureR() } }                        >
                  {Object.keys(backImage).length > 0?
                   <Icon name='md-checkmark-circle' style={{color:'green'}}/> 
                   :null}
                  <Text style={{color:'#003580',fontFamily:'TajawalRegular0'}}>{strings('damagestep.right',lang)}</Text>
                 
                  </Button>
               
                </Body>
                </View>
              </CardItem>

              <CardItem style={[transparentBackground,{marginTop:50}]}>
                <Body style={centerStyle}>
                  <Image source={require("../assests/images/car.png")}
                         style={{height:142.6,width:256}}
                   />
                </Body>

              </CardItem>
             { (Object.keys(leftImage).length > 0) &&(Object.keys(rightImage).length > 0) &&(Object.keys(frontImage).length > 0) &&(Object.keys(backImage).length > 0) ?
              <CardItem style={[transparentBackground,{marginTop:50}]}>
                <Body style={centerStyle}>
                  <Button style={{backgroundColor:'#003580',width:335,justifyContent:'center',marginTop:10}} onPress={() =>this.gotToPayment(leftImage,rightImage,frontImage,backImage)}>
                  
                          {lang=='ar'?
                   <Icon name='md-arrow-back' style={{color:'#fff'}}/> 
                   :null}
                   <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
                   {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                  </Button>
                </Body>
            </CardItem>
            :null}
</Content>









            {/* <Content>
{this.state.showCameraView1||this.state.showCameraView2||this.state.showCameraView3||this.state.showCameraView4?
            <View style={{flex: 1,flexDirection: 'column',backgroundColor: 'black',width:dimensions.width,height:dimensions.height/1.2}}>




        
{this.state.showCameraView1?
        <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center' }}>
          <TouchableOpacity onPress={this.takePicture.bind(this,"Left")} style={{flex: 0,backgroundColor: '#fff',borderRadius: 5,padding: 15,paddingHorizontal: 20,alignSelf: 'center',margin: 20,}}>
          <Icon name='md-camera'/> 
          </TouchableOpacity>
        </View>
        : this.state.showCameraView2?
        <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center' }}>
        <TouchableOpacity onPress={this.takePicture.bind(this,"Right")} style={{flex: 0,backgroundColor: '#fff',borderRadius: 5,padding: 15,paddingHorizontal: 20,alignSelf: 'center',margin: 20,}}>
        <Icon name='md-camera'/> 
        </TouchableOpacity>
      </View>
        
:
        this.state.showCameraView3?
        <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center' }}>
        <TouchableOpacity onPress={this.takePicture.bind(this,"Front")} style={{flex: 0,backgroundColor: '#fff',borderRadius: 5,padding: 15,paddingHorizontal: 20,alignSelf: 'center',margin: 20,}}>
        <Icon name='md-camera'/> 
        </TouchableOpacity>
      </View>
        
:
        this.state.showCameraView4?
        <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center' }}>
        <TouchableOpacity onPress={this.takePicture.bind(this,"Back")} style={{flex: 0,backgroundColor: '#fff',borderRadius: 5,padding: 15,paddingHorizontal: 20,alignSelf: 'center',margin: 20,}}>
        <Icon name='md-camera'/> 
        </TouchableOpacity>
      </View>
        
:null}
      </View>
      :null}
      <CardItem style={[sevicesCardItemStyle, {width: dimensions.width}]}>
      {lang=='ar'?
                <Right style={{marginLeft:100}}>
                  <Text style={servicesText}>{strings('damagestep.Car_photos',lang)}</Text>
                </Right>
                :
                <Left style={{marginLeft:100}}>
                <Text style={servicesText}>{strings('damagestep.Car_photos',lang)}</Text>
              </Left>
}
              </CardItem>
            <CardItem style={{width: dimensions.width,backgroundColor:"#fff",height:120,marginTop:15,flexDirection:'row'}}>
            
              {leftCarPic &&
        <Image source={{ uri: leftCarPic }} style={{ height:100,width:100 }} />}
              <Image source={{uri: `${rightImage.uri}`}} style={{height:100,width:100}}/>
              <Image source={{uri: `${frontImage.uri}`}} style={{height:100,width:100}}/>
              <Image source={{uri: `${backImage.uri}`}} style={{height:100,width:100}}/>


            </CardItem>
        
            
              <CardItem style={transparentBackground}>
            
                <Body style={{borderColor: "transparent",display:'flex',flexDirection: 'row',alignItems:'center', justifyContent: 'space-between',marginTop:20}}>
                <Button style={whiteBackground}onPress={() =>this.setState({showCameraView3:true})}>
                {Object.keys(frontImage).length > 0?
                   <Icon name='md-checkmark-circle' style={{color:'green'}}/> 
                   :null}
                   <Text style={{color:'#003580',fontFamily:'TajawalRegular0'}}>{strings('damagestep.front',lang)}</Text>
                
                   </Button>
                  <Button style={whiteBackground} onPress={() =>this.setState({showCameraView4:true})} >
                  {Object.keys(backImage).length > 0?
                   <Icon name='md-checkmark-circle' style={{color:'green'}}/> 
                   :null}
                  <Text style={{color:'#003580',fontFamily:'TajawalRegular0'}}>{strings('damagestep.back',lang)}</Text>
                 
                  </Button>
               
                </Body>
              </CardItem>
              <CardItem style={transparentBackground}>
                <Body style={{borderColor: "transparent",display:'flex',flexDirection: 'row',alignItems:'center', justifyContent: 'space-between',marginTop:20}}>
            
                  <Button style={whiteBackground} onPress={() =>this.setState({showCameraView2:true})} >
                  {Object.keys(rightImage).length > 0?
                   <Icon name='md-checkmark-circle' style={{color:'green'}}/> 
                   :null}
                  <Text style={{color:'#003580',fontFamily:'TajawalRegular0'}}>{strings('damagestep.right',lang)}</Text>
                  
                  </Button>
                  <Button style={whiteBackground}
                  onPress={()=>{ this._takePicture() } }
                   >
                  {Object.keys(leftImage).length > 0?
                   <Icon name='md-checkmark-circle' style={{color:'green'}}/> 
                   :null}
                  <Text style={{color:'#003580',fontFamily:'TajawalRegular0'}}>{strings('damagestep.left',lang)}</Text>
                  
                  </Button>
                </Body>
              </CardItem>
              <CardItem style={[transparentBackground,{marginTop:50}]}>
                <Body style={centerStyle}>
                  <Image source={require("../assests/images/car.png")}
                         style={{height:142.6,width:256}}
                   />
                </Body>

              </CardItem>
             { (Object.keys(leftImage).length > 0) &&(Object.keys(rightImage).length > 0) &&(Object.keys(frontImage).length > 0) &&(Object.keys(backImage).length > 0) ?
              <CardItem style={[transparentBackground,{marginTop:50}]}>
                <Body style={centerStyle}>
                  <Button style={{backgroundColor:'#003580',width:335,justifyContent:'center',marginTop:10}} onPress={() =>this.gotToPayment(leftImage,rightImage,frontImage,backImage)}>
                  
                          {lang=='ar'?
                   <Icon name='md-arrow-back' style={{color:'#fff'}}/> 
                   :null}
                   <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
                   {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                  </Button>
                </Body>
            </CardItem>
            :null}
            </Content> */}
           </ImageBackground>
        )
    }
    _checkCameraPermissions = async () => {
      const { status } = await Permissions.getAsync(Permissions.CAMERA);
      //const { status } = await Permissions.getAsync(Permissions.CAMERA_ROLL);
      this.setState({ status });
  }
  _reqCameraPermissions = async () => {
      const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
      this.setState({ cameraPermission: status });
  };


  _checkCameraRollPermissions = async () => {
      const { status } = await Permissions.getAsync(Permissions.CAMERA);
      this.setState({ status });
  }
  _reqCameraRollPermissions = async () => {
      const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
      this.setState({ cameraRollPermission: status });
  };

  _pickImage = async () => {
      this._checkCameraRollPermissions();
      this._reqCameraRollPermissions();
      let result = await ImagePicker.launchImageLibraryAsync();

      console.log(result);
      if (!result.cancelled) {
          this.setState({ leftCarPic: result.uri });
          CameraRoll.saveToCameraRoll(result.uri)
      }
  };

  _takePicture = async () => {
      this._checkCameraPermissions();
      this._reqCameraPermissions();

      let result = await ImagePicker.launchCameraAsync();
      // let result = await ImagePicker.launchImageLibraryAsync();

      console.log(result);
      if (!result.cancelled) {
          this.setState({ leftCarPic: result.uri });
          CameraRoll.saveToCameraRoll(result.uri)
      }
  };



  _pickImageR = async () => {
    this._checkCameraRollPermissions();
    this._reqCameraRollPermissions();
    let result = await ImagePicker.launchImageLibraryAsync();

    console.log(result);
    if (!result.cancelled) {
        this.setState({ rightCarPic: result.uri });
        CameraRoll.saveToCameraRoll(result.uri)
    }
};

_takePictureR = async () => {
    this._checkCameraPermissions();
    this._reqCameraPermissions();

    let result = await ImagePicker.launchCameraAsync();
    // let result = await ImagePicker.launchImageLibraryAsync();

    console.log(result);
    if (!result.cancelled) {
        this.setState({ rightCarPic: result.uri });
        CameraRoll.saveToCameraRoll(result.uri)
    }
};




_pickImageF = async () => {
  this._checkCameraRollPermissions();
  this._reqCameraRollPermissions();
  let result = await ImagePicker.launchImageLibraryAsync();

  console.log(result);
  if (!result.cancelled) {
      this.setState({ frontCarPic: result.uri });
      CameraRoll.saveToCameraRoll(result.uri)
  }
};

_takePictureF = async () => {
  this._checkCameraPermissions();
  this._reqCameraPermissions();

  let result = await ImagePicker.launchCameraAsync();
  // let result = await ImagePicker.launchImageLibraryAsync();

  console.log(result);
  if (!result.cancelled) {
      this.setState({ frontCarPic: result.uri });
      CameraRoll.saveToCameraRoll(result.uri)
  }
};



_pickImageB= async () => {
  this._checkCameraRollPermissions();
  this._reqCameraRollPermissions();
  let result = await ImagePicker.launchImageLibraryAsync();

  console.log(result);
  if (!result.cancelled) {
      this.setState({ backCarPic: result.uri });
      CameraRoll.saveToCameraRoll(result.uri)
  }
};

_takePictureB = async () => {
  this._checkCameraPermissions();
  this._reqCameraPermissions();

  let result = await ImagePicker.launchCameraAsync();
  // let result = await ImagePicker.launchImageLibraryAsync();

  console.log(result);
  if (!result.cancelled) {
      this.setState({ backCarPic: result.uri });
      CameraRoll.saveToCameraRoll(result.uri)
  }
};
}
// export default DamageStep;
// export default CarInformation;
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;
  const { damage_step_msg} = state.damageStepReducer;
    return {damage_step_msg,lang};
}
// END MAP STATE TO PROPS


export default connect(mapStateToProps,damageStepAction)(DamageStep);