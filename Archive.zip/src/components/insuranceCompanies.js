import React,{Component} from 'react';
import {ImageBackground,Dimensions,Text,ScrollView,View,Image,TouchableWithoutFeedback,Modal} from 'react-native';
import {CardItem,Body,Right,Left,ListItem,CheckBox,Button, Content} from 'native-base';
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';

const dimensions=Dimensions.get('window');
const IMAGE_BASE_URL='https://bolisati1.qiotic.info/'

import * as insuranceCompaniesAction from '../actions/insuranceCompaniesAction';

import {centerStyle,servicesText,sevicesCardItemStyle,transparentBackground,buttonStyle,buttonText} from '../theme';
import { Actions } from 'react-native-router-flux';


class InsuranceCompanies extends Component{
  constructor(props){
    super(props);
    this.state ={
      isAddonChecked:false,insuranceCompanyId:null,totalAll:0
  }
  }
  countPrice=(value)=>{
    value.isChecked=!value.isChecked
    this.setState({isAddonChecked: value.isChecked});

  }
  goToAnotherPage=(addons,insuranceCompaanyId,total)=>{

    var companyAddons=[]
    for(var i=0;i<addons.length;i++)
    {
      if (addons[i].isChecked){
companyAddons.push(addons[i])
      }
    }
      const {show_insurance_modal,carInformation,user_id,lifeInsuranceInformation,travelInformation}=this.props;
      this.props.showInsuranceCompanyModal(!show_insurance_modal)
if(carInformation){
      Actions.damagestep({
        carInformation:carInformation,
        addons:companyAddons,
        insuranceCompaanyId:insuranceCompaanyId,
        total:total,
        user_id:user_id
      })
    }
    else if(lifeInsuranceInformation){
      this.props.lifeInsuranceOrder(insuranceCompaanyId,lifeInsuranceInformation)
    }
    else if (travelInformation){
      this.props.travelInsuranceOrder(insuranceCompaanyId,travelInformation)

    }
  }
    showModal=(id,company)=>{
console.log("company",company)
      const {addons,show_insurance_modal}=this.props;
      this.setState({insuranceCompanyId:id})
      // this.setState({totalAll:company.insurance_price})
      if(company.insurance_price)
     {
     this.setState({totalAll:company.insurance_price})
     }
      this.props.getAddons(id);
      this.props.getTerms(id);
      this.props.showInsuranceCompanyModal(!show_insurance_modal)

 console.log("addons",addons)
    }
    render(){
        const {show_insurance_modal,insuranceCompanies,terms,addons,carInformation,lang}=this.props
        console.log("this.props in insurance",this.props)
console.log("this.state.totalAll",this.state.totalAll)
     var total=this.state.totalAll
        for (var i=0;i<addons.length;i++){
          if(addons[i].isChecked){
            total=total+addons[i].price
          }
        }
   
        return(
            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
              {/* <TouchableWithoutFeedback onPress={() => this.props.showInsuranceCompanyModal(!show_insurance_modal)}>    */}
<Content style={{backgroundColor:"transparent"}}>
              <CardItem style={[sevicesCardItemStyle, {width: dimensions.width}]}>
 {lang=='ar'?
                <Right>
                  <Text style={servicesText}>{strings('insurancecompanies.insurance_companies',lang)}</Text>
                </Right>
                :
                <Left>
                <Text style={servicesText}>{strings('insurancecompanies.insurance_companies',lang)}</Text>
              </Left>
 }
              </CardItem>
   
          {insuranceCompanies?
          insuranceCompanies.map((company, index) => {
            return (
           <TouchableWithoutFeedback onPress={() => this.showModal(company.manufacturers_id,company)} key={company.manufacturers_id}>
           {lang=='ar'?
              <CardItem style={{backgroundColor:"#fff",height:129,marginTop:15,width:dimensions.width,direction:'rtl'}}>
               <Right>
                 <Body>
                 <Image source={{uri: `${IMAGE_BASE_URL}${company.manufacturers_image}`}} style={{width:100,height:80}}/>
                 </Body>
               </Right>
               <Body style={{justifyContent:"center",alignItems:"center"}}>
                 <Text style={{marginLeft:20}}>
                   {company.manufacturers_name}
                 </Text>
               </Body>
               {company.insurance_price?
               <Left>
                 <Body>
                 <Text>{company.insurance_price} JOD</Text>
                 </Body>
               </Left>
               :null}
              </CardItem>
              :
                          <CardItem style={{backgroundColor:"#fff",height:129,marginTop:15,width:dimensions.width,direction:'ltr'}}>
                          <Left>
                            <Body>
                            <Image source={{uri: `${IMAGE_BASE_URL}${company.manufacturers_image}`}} style={{width:100,height:80}}/>
                            </Body>
                          </Left>
                          <Body style={{justifyContent:"center",alignItems:"center"}}>
                            <Text style={{marginLeft:20}}>
                              {company.manufacturers_name}
                            </Text>
                          </Body>
                          {company.insurance_price?
                          <Right>
                            <Body style={{marginTop:50}}>
                            <Text>{company.insurance_price} JOD</Text>
                            </Body>
                          </Right>
                          :null}
                         </CardItem>
              
            }
              </TouchableWithoutFeedback>
          )})
:null}
              <Modal
            visible={show_insurance_modal}
            animationType={"slide"}
            onRequestClose={() =>
              this.props.showInsuranceCompanyModal(!show_insurance_modal)
            }
            supportedOrientations={[
              "portrait",
              "portrait-upside-down",
              "landscape",
              "landscape-left",
              "landscape-right"
            ]}
            transparent
          >
             <TouchableWithoutFeedback
              onPress={() => this.props.showInsuranceCompanyModal(!show_insurance_modal)}
            >
              <View style={{backgroundColor:'rgba(0,0,0,0.50)',position:'relative',flex:1,justifyContent:'center'}}>
                <View style={{  borderWidth:1,borderRadius:5,borderColor:'#e3e3e3',padding:0,backgroundColor:'#fff',marginLeft:15,marginRight:15}}>
                  <ListItem style={{marginTop:10,alignSelf:lang=='en'?"flex-start":"flex-end",borderBottomWidth: 0}}>
                    <Text style={{color:"#171717",fontSize:21,fontFamily:'TajawalRegular0'}}>
                    {strings('insurancecompanies.Terms_and_Conditions',lang)}
                    </Text>
                  </ListItem>
                  {terms.length>0?
                  // <ListItem style={{alignSelf:"flex-end",borderBottomWidth: 0}}>   
                  //     <Text style={{fontSize:12}}>
                  //         {terms[0].terms}
                  //     </Text>
                       
                  // </ListItem>
                  <CardItem style={transparentBackground}>
                  <View style={{marginLeft:50}}>
                  <Text style={{textAlign:lang=='ar'?"right":"left",fontSize:12,fontFamily:'TajawalRegular0'}}>{terms[0].terms}</Text>
                  </View>
                  </CardItem>
                    :null}

                  <ListItem style={{marginTop:10,borderBottomWidth: 0,direction:lang=='ar'?'rtl':'ltr'}}>
                    <Text style={{color:"#171717",fontSize:21,fontFamily:'TajawalRegular0'}}>
{strings('insurancecompanies.addons',lang)}
                    </Text>
                  </ListItem>
       
             {addons.length>0?
              addons.map((addon, index) => {
                addon.isChecked=Boolean(addon.isChecked)
                console.log("addon.isChecked",addon.isChecked)
                return(
            <CardItem style={{borderBottomWidth: 0,direction:lang=='ar'?'rtl':'ltr'}} key={index}>
            {/* <Right style={{marginRight:30}}>
              <Body> */}
              <CheckBox
              
                        style={{marginRight:15,borderRadius:50,justifyContent:'center',alignItems:'center',}}
                        checked={addon.isChecked}
                        color="#003580"
                        onPress={() =>this.countPrice(addon)
                      
                        }
                      />
                      
              {/* </Body>
              </Right>
              <Left>
                <Body> */}
                <Text style={{fontFamily:'TajawalRegular0'}}>
                {addon.addon_name}   {addon.price} 
                </Text>
                {/* </Body>
              </Left> */}
            </CardItem>
              )})
            :null}
            {/* <CardItem>
            <Right>
                    <Text>{total} JOD</Text>
                </Right>
                <Body>

                </Body>
                <Left>
                    <Text>المجموع</Text>
                    
                </Left>
            
            </CardItem> */}
            {total!=0?
                <CardItem style={[transparentBackground,{marginTop:40,direction:lang=='ar'?"rtl":'ltr'}]} bordered>
              <Left>
                 <Text style={{fontFamily:'TajawalRegular0', fontSize:16,textAlign:"right",color:"#171717"}}>{strings('insurancecompanies.total',lang)}</Text>
              </Left>
              <Right>
                 <Text style={{ fontFamily:'TajawalRegular0',fontSize:16,textAlign:"right",color:"#171717"}}>{total} JOD</Text>
              </Right>
            </CardItem>
            :null}
            <ListItem style={{borderBottomWidth: 0}}>
                    <Body>
                    <Button
            onPress={()=>this.goToAnotherPage(addons,this.state.insuranceCompanyId,total)}
            style={{backgroundColor:"#003580"}}
            block
          
          >
            <Text style={buttonText}>{strings('insurancecompanies.agree_the_termas',lang)}</Text>
          </Button>
                    </Body>
                  </ListItem>

                </View>
              </View>
              </TouchableWithoutFeedback>
          </Modal>
          </Content>
            </ImageBackground>

        )
    }

}
// START MAP STATE TO PROPS
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;
    const { show_insurance_modal,addons,terms} = state.insuranceCompaniesReducer;
    return { show_insurance_modal,addons,terms,lang};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,insuranceCompaniesAction)(InsuranceCompanies);