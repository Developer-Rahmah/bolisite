import React, { Component } from 'react';
import {ImageBackground,Dimensions,ScrollView,View,Image} from 'react-native';
import {CardItem,Body,Button,Text, Icon,Form,Item,Input,Picker,Right,Left,Card} from 'native-base';
import {transparentBackground,transparentBorder,inputStyle,centerStyle,buttonStyle,buttonText,pickerStyle,datePickerStyle} from '../theme';
import * as carInformationAction from '../actions/carInformationAction';
import DropdownAlert from 'react-native-dropdownalert';
import { connect } from 'react-redux';
import DatePicker from 'react-native-datepicker';
import {Actions} from "react-native-router-flux";
import moment, * as moments from 'moment';
import {strings} from '../../Locales/i18n';
const dimensions=Dimensions.get('window');
class CarInformation extends Component{
  constructor(props){
    super(props);
    this.state ={
      show_end_date:false 
    }
  }
  componentWillMount() {
    this.props.getCars();
  
    
  }

  componentDidUpdate (){
    const { car_information_msg,start_date} = this.props;
     if (car_information_msg != null) {
       setTimeout(()=> this.props.resetCarInformationMessage(),300);
     }
  }
  onValueChange(value) {
    this.props.getCarInformationTexts({prop: "car_type",value})
    this.props.getCarsModal(value)

  }
  changeShowDate(value) {
    console.log("value",value)
   this.props.getCarInformationTexts({prop: "insurance_type",value})
   if (value=="2"){
    this.setState({show_end_date: true});
  }
  else if(value=="1"){
    this.setState({show_end_date: false});

  }

  }
    //START DROPDOWN MESSAGES
  onError = (error) => {
    if (error) {
    console.log("error",error)
    this.dropdown.alertWithType('error', 'Error', error);
  }
}

  onSuccess = success => {
    if (success) {
    this.dropdown.alertWithType('success', 'Success', success);
  }
}
 
//END DROPDOWN MESSAGES
     //START SHOW ALERT FUNC
     showAlert = () => {
      const {car_information_msg} = this.props;
      if (car_information_msg != null) {
        if (car_information_msg.isError) {
          this.onError(car_information_msg.msg);
        } else if (car_information_msg.isSuccess) {
          this.onSuccess(car_information_msg.msg);
        } else {
          return;
        }
      }
    };
    //END SHOW ALERT FUNC
    goToInsuranceCompanies=()=>{
      const {full_name, id_number, insurance_type,car_type,vehicle_number,car_model,manufacturing_year,driver,fuel_type,car_salary,start_date,end_date,user_id} = this.props;
      let end_date1 = moment(start_date);
      end_date1 = moment(end_date1).add(365, 'day').format('YYYY-MM-DD');
            // this.props.goToInsuranceCompanies(full_name, id_number, insurance_type,car_type,vehicle_number,car_model,manufacturing_year,driver,fuel_type,car_salary,start_date,end_date1,user_id);

      if(insurance_type=="2"){
      this.props.goToInsuranceCompanies(full_name, id_number, insurance_type,car_type,vehicle_number,car_model,manufacturing_year,driver,fuel_type,car_salary,start_date,end_date,user_id);
    }
    else if( insurance_type=="1")
    {
      this.props.goToInsuranceCompanies(full_name, id_number, insurance_type,car_type,vehicle_number,car_model,manufacturing_year,driver,fuel_type,car_salary,start_date,end_date1,user_id);

    }
    }

    render(){
      console.log("this.props in car information",this.props)
      const {full_name,insurance_type,car_type,vehicle_number,car_model,manufacturing_year,driver,fuel_type,car_salary,start_date,end_date,id_number,cars,cars_model,lang}=this.props


        return(

            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width}}>
                      <ScrollView ref={(ref)=> {this._scrollView = ref}}>

              <Card style={{backgroundColor:'transparent',borderColor:'transparent'}}>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={full_name}
                     placeholder ={strings('carInformation.full_name',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getCarInformationTexts({prop:"full_name",value})}
                   />
                 </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={id_number}
                     placeholder ={strings('carInformation.id_number',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getCarInformationTexts({prop:"id_number",value})}
                   />
                 </Item>
               </CardItem>
     
                  <CardItem style={transparentBackground}>
                  <Item style={transparentBorder}>
             
                    <Picker
                      mode="dropdown"
                      iosHeader={strings('carInformation.insurance_type',lang)}
                      placeholder={strings('carInformation.insurance_type',lang)}
                      iosIcon={<Icon name="arrow-down" />}
                      placeholderStyle={{ color: "#9B9B9B" }}
                      style={[pickerStyle,{direction:lang=='ar'?'rtl':'ltr'}]}
                      selectedValue={insurance_type}
                      onValueChange={value =>
                        this.changeShowDate(value)
                        // this.props.getCarInformationTexts({
                        //   prop: "insurance_type",
                        //   value
                        // })
                      }
                     >
                     <Picker.Item label={strings('carInformation.supplementary',lang)}value="2" />
                     <Picker.Item label={strings('carInformation.comprehensive',lang)} value="1" />
                    </Picker>
                </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                  <Item style={transparentBorder}>
             
                    <Picker
                      mode="dropdown"
                      iosHeader={strings('carInformation.car_type',lang)}
                      placeholder={strings('carInformation.car_type',lang)}
                      iosIcon={<Icon name="arrow-down" />}
                      placeholderStyle={{ color: "#9B9B9B" }}
                      style={[pickerStyle,{direction:lang=='ar'?'rtl':'ltr'}]}
                      selectedValue={this.props.car_type}
                      onValueChange={value =>
                        // this.props.getCarInformationTexts({
                        //   prop: "car_type",
                        //   value
                        // })
                        this.onValueChange(value)
                      }
                     >
             
                        {cars.map((item, index) => {
                      return (
                        <Picker.Item
                          key={item.car_id}
                          label={item.car_model}
                          value={item.car_id}
                        />
                      );
                    })}
                    </Picker>
                </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                  <Item style={transparentBorder}>
             
                    <Picker
                      mode="dropdown"
                      iosHeader={strings('carInformation.car_model',lang)}
                      placeholder={strings('carInformation.car_model',lang)}
                      iosIcon={<Icon name="arrow-down" />}
                      placeholderStyle={{ color: "#9B9B9B" }}
                      style={[pickerStyle,{direction:lang=='ar'?'rtl':'ltr'}]}
                      selectedValue={car_model}
                      onValueChange={value =>
                        this.props.getCarInformationTexts({
                          prop: "car_model",
                          value
                        })
                      }
                     >
                          {cars_model.map((item, index) => {
                      return (
                        <Picker.Item
                          key={item.model_id}
                          label={item.model_name}
                          value={item.model_id}
                        />
                      );
                    })}
                    </Picker>
                </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={vehicle_number}
                     placeholder ={strings('carInformation.vehicle_number',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getCarInformationTexts({prop: "vehicle_number",value})}
                    />
                 </Item>
               </CardItem> 
   
               <CardItem style={transparentBackground}>
                  <Item style={transparentBorder}>
             
                    <Picker
                      mode="dropdown"
                      iosHeader={strings('carInformation.manufacturing_year',lang)}
                      placeholder={strings('carInformation.manufacturing_year',lang)}
                      iosIcon={<Icon name="arrow-down" />}
                      placeholderStyle={{ color: "#9B9B9B" }}
                      style={[pickerStyle,{direction:lang=='ar'?'rtl':'ltr'}]}
                      selectedValue={manufacturing_year}
                      onValueChange={value =>
                        this.props.getCarInformationTexts({
                          prop: "manufacturing_year",
                          value
                        })
                      }
                     >
                     <Picker.Item label="2009" value="2009" />
                     <Picker.Item label="2010" value="2010" />
                     <Picker.Item label="2011" value="2011" />
                     <Picker.Item label="2012" value="2012" />
                     <Picker.Item label="2013" value="2013" />
                    </Picker>
                </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                  <Item style={transparentBorder}>
             
                    <Picker
                      mode="dropdown"
                      iosHeader={strings('carInformation.driver',lang)}
                      placeholder={strings('carInformation.driver',lang)}
                      iosIcon={<Icon name="arrow-down" />}
                      placeholderStyle={{ color: "#9B9B9B" }}
                      style={[pickerStyle,{direction:lang=='ar'?'rtl':'ltr'}]}
                      selectedValue={driver}
                      onValueChange={value =>
                        this.props.getCarInformationTexts({
                          prop: "driver",
                          value
                        })
                      }
                     >
                     <Picker.Item label={strings('carInformation.automatic',lang)} value="اتوماتيك" />
                     <Picker.Item label={strings('carInformation.manually',lang)} value="عادي" />
                    </Picker>
                </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                  <Item style={transparentBorder}>
             
                    <Picker
                      mode="dropdown"
                      iosHeader={strings('carInformation.fuel_type',lang)}
                      placeholder={strings('carInformation.fuel_type',lang)}
                      iosIcon={<Icon name="arrow-down" />}
                      placeholderStyle={{ color: "#9B9B9B" }}
                      style={[pickerStyle,{direction:lang=='ar'?'rtl':'ltr'}]}
                      selectedValue={fuel_type}
                      onValueChange={value =>
                        this.props.getCarInformationTexts({
                          prop: "fuel_type",
                          value
                        })
                      }
                     >
                     <Picker.Item label={strings('carInformation.gasoline',lang)} value="بنزين" />
                    </Picker>
                </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                              <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={car_salary}
                     placeholder ={strings('carInformation.car_salary',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getCarInformationTexts({prop: "car_salary",value})}
                    />
                 </Item>
             
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}>
                 <DatePicker
                 style={datePickerStyle}
                 date={ start_date}
                 mode="date"
                 placeholder={strings('carInformation.start_date',lang)}
                 format="YYYY-MM-DD"
                 minDate={new Date()}
                 maxDate="2029-12-31"
                 confirmBtnText="Confirm"
                 cancelBtnText="Cancel"
                 customStyles={{
                 dateIcon: {
                 position: 'absolute',
                 left: 0,
                 top: 4,
                 marginLeft: 0
                 },
                 dateInput: {
                 marginLeft: 36
                 },
                 btnTextConfirm: {
                 height: 20
                 },
                 btnTextCancel: {
                 height: 20
                 }
     }}
     onDateChange={(value) => {this.props.getCarInformationTexts({prop:'start_date',value})}}
    />
                 </Item>
                 </CardItem>
{this.state.show_end_date?
           
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}>
                 <DatePicker
                 style={datePickerStyle}
                 date={end_date}
                 mode="date"
                 placeholder={strings('carInformation.end_date',lang)}
                 format="YYYY-MM-DD"
                 minDate={new Date()}
                 maxDate="2029-12-31"
                 confirmBtnText="Confirm"
                 cancelBtnText="Cancel"
                 customStyles={{
                 dateIcon: {
                 position: 'absolute',
                 left: 0,
                 top: 4,
                 marginLeft: 0
                 },
                 dateInput: {
                 marginLeft: 36
                 },
                 btnTextConfirm: {
                 height: 20
                 },
                 btnTextCancel: {
                 height: 20
                 }
     }}
     onDateChange={(value) => {this.props.getCarInformationTexts({prop:'end_date',value})}}
    />
                 </Item>

               </CardItem>
:null}
               <CardItem style={transparentBackground}>
               
                <Body style={centerStyle}>
                  {/* <Button style={buttonStyle} block onPress={() => Actions.insurancecompanies()}> */}
                  <Button style={buttonStyle}  block onPress={this.goToInsuranceCompanies}>
                  {lang=='ar'?
                    <Icon name='md-arrow-back' style={{color:'#fff'}}/>
                    :null}
                    <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
                    {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                  </Button>
                </Body>
            </CardItem>

            </Card>
           
            {/* <View style={{height:50,backgroundColor:"trasparent"}}></View> */}

            </ScrollView>
            <Text>{this.showAlert()}</Text>

<DropdownAlert ref={ref => (this.dropdown = ref)} style={{fontFamily:'TajawalRegular0',}} />
            </ImageBackground>

            

        )
    }
}
// export default CarInformation;
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;
  const { full_name,insurance_type,car_type,vehicle_number,car_model,manufacturing_year,driver,fuel_type,car_salary,start_date,end_date,information_loading,id_number,cars,cars_model,car_information_msg} = state.carInformarionReducer;
  return {full_name,insurance_type,car_type,vehicle_number,car_model,manufacturing_year,driver,fuel_type,car_salary,start_date,end_date,information_loading,id_number,cars,cars_model,car_information_msg,lang};
}
// END MAP STATE TO PROPS


export default connect(mapStateToProps,carInformationAction)(CarInformation);