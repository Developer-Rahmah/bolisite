// import React, { Component } from 'react';
// import {ImageBackground,Dimensions,ScrollView,View,Image} from 'react-native';
// import {CardItem,Body,Button,Text, Icon,Form,Item,Input,Picker,Right,Left,Card} from 'native-base';
// import {transparentBackground,transparentBorder,inputStyle,centerStyle,buttonStyle,buttonText,pickerStyle,datePickerStyle} from '../theme';
// import * as lifeInsuranceAction from '../actions/lifeInsuranceAction';
// import DropdownAlert from 'react-native-dropdownalert';
// import { connect } from 'react-redux';
// import {strings} from '../../Locales/i18n';
// const dimensions=Dimensions.get('window');
// class LifeInsurance extends Component{

//     componentDidUpdate (){
//         const { life_insurance_msg} = this.props;
//          if (life_insurance_msg != null) {
//            setTimeout(()=> this.props.resetLifeInsuranceMessage(),300);
//          }
//       }

//     //START DROPDOWN MESSAGES
//   onError = (error) => {
//     if (error) {
//     console.log("error",error)
//     this.dropdown.alertWithType('error', 'Error', error);
//   }
// }

//   onSuccess = success => {
//     if (success) {
//     this.dropdown.alertWithType('success', 'Success', success);
//   }
// }
 
// //END DROPDOWN MESSAGES
//      //START SHOW ALERT FUNC
//      showAlert = () => {
//       const {life_insurance_msg} = this.props;
//       if (life_insurance_msg != null) {
//         if (life_insurance_msg.isError) {
//           this.onError(life_insurance_msg.msg);
//         } else if (life_insurance_msg.isSuccess) {
//           this.onSuccess(life_insurance_msg.msg);
//         } else {
//           return;
//         }
//       }
//     };
//     goFromLifeInsurance=()=>{
//         const {full_name, id_number,age,user_id} = this.props;
//         this.props.goFromLifeInsurance(full_name, id_number,age,user_id);
    
 
//       }
//     render(){
//       const {full_name,id_number,age,lang}=this.props


//         return(

//             <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
//                       <ScrollView ref={(ref)=> {this._scrollView = ref}}>

//               <Card style={{backgroundColor:'transparent',borderColor:'transparent'}}>
//                <CardItem style={transparentBackground}>
//                  <Item style={transparentBorder}> 
//                    <Input
//                      color="#fff"
//                      value ={full_name}
//                      placeholder ={strings('carInformation.full_name',lang)}
//                      placeholderTextColor="#9B9B9B"
//                      style={[inputStyle,{textAlign:lang=='ar'?"right":"left"}]}
//                      onChangeText={value =>this.props.getLifeInsuranceTexts({prop:"full_name",value})}
//                    />
//                  </Item>
//                </CardItem>
//                <CardItem style={transparentBackground}>
//                  <Item style={transparentBorder}> 
//                    <Input
//                      color="#fff"
//                      value ={id_number}
//                      placeholder ={strings('carInformation.id_number',lang)}
//                      placeholderTextColor="#9B9B9B"
//                      style={[inputStyle,{textAlign:lang=='ar'?"right":"left"}]}
//                      onChangeText={value =>this.props.getLifeInsuranceTexts({prop:"id_number",value})}
//                    />
//                  </Item>
//                </CardItem>
     
//                   <CardItem style={transparentBackground}>
//                   <Item style={transparentBorder}>
             
//                     <Picker
//                       mode="dropdown"
//                       iosHeader={strings('lifeinsurance.age',lang)}
//                       placeholder={strings('lifeinsurance.age',lang)}
//                       iosIcon={<Icon name="arrow-down" />}
//                       placeholderStyle={{ color: "#9B9B9B" }}
//                       style={[pickerStyle,{direction:lang=='ar'?'rtl':'ltr'}]}
//                       selectedValue={age}
//                       onValueChange={value =>
//                         this.props.getLifeInsuranceTexts({
//                           prop: "age",
//                           value
//                         })
//                       }
//                      >
//                     <Picker.Item label="20-30" value="1" />
//                      <Picker.Item label="30-40" value="2" />
//                      <Picker.Item label="40-50" value="3" />
//                      <Picker.Item label="50-60" value="4" />
//                      <Picker.Item label="60-70" value="5" />
//                     </Picker>
//                 </Item>
//                </CardItem>
         
//                <CardItem style={transparentBackground}>
               
//                 <Body style={centerStyle}>
               
//                   <Button style={buttonStyle}  block onPress={this.goFromLifeInsurance}>
//                   {lang=='ar'?
//                     <Icon name='md-arrow-back' style={{color:'#fff'}}/>
//                     :null}
//                     <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
//                     {lang=='en'?
//                    <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
//                    :null}
//                   </Button>
//                 </Body>
//             </CardItem>

//             </Card>
           

//             </ScrollView>
//             <Text>{this.showAlert()}</Text>

// <DropdownAlert ref={ref => (this.dropdown = ref)} />
//             </ImageBackground>

            

//         )
//     }
// }
// // export default LifeInsurance;
// const mapStateToProps = state => {
//     const { lang } = state.sideBarReducer;
//     const { full_name,id_number,life_insurance_msg,age} = state.lifeInsuranceReducer;
//     return {full_name,id_number,life_insurance_msg,age,lang};
//   }
//   // END MAP STATE TO PROPS
  
  
//   export default connect(mapStateToProps,lifeInsuranceAction)(LifeInsurance);







import React, { Component } from 'react';
import {ImageBackground,Dimensions,ScrollView,View,Image} from 'react-native';
import {CardItem,Body,Button,Text, Icon,Form,Item,Input,Picker,Right,Left,Card} from 'native-base';
import {transparentBackground,transparentBorder,inputStyle,centerStyle,buttonStyle,buttonText,pickerStyle,datePickerStyle} from '../theme';
import * as lifeInsuranceAction from '../actions/lifeInsuranceAction';
import DropdownAlert from 'react-native-dropdownalert';
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';
const dimensions=Dimensions.get('window');
class LifeInsurance extends Component{

    componentDidUpdate (){
        const { life_insurance_msg} = this.props;
         if (life_insurance_msg != null) {
           setTimeout(()=> this.props.resetLifeInsuranceMessage(),300);
         }
      }

    //START DROPDOWN MESSAGES
  onError = (error) => {
    if (error) {
    console.log("error",error)
    this.dropdown.alertWithType('error', 'Error', error);
  }
}

  onSuccess = success => {
    if (success) {
    this.dropdown.alertWithType('success', 'Success', success);
  }
}
 
//END DROPDOWN MESSAGES
     //START SHOW ALERT FUNC
     showAlert = () => {
      const {life_insurance_msg} = this.props;
      if (life_insurance_msg != null) {
        if (life_insurance_msg.isError) {
          this.onError(life_insurance_msg.msg);
        } else if (life_insurance_msg.isSuccess) {
          this.onSuccess(life_insurance_msg.msg);
        } else {
          return;
        }
      }
    };
    goFromLifeInsurance=()=>{
        const {full_name, id_number,age,user_id} = this.props;
        this.props.goFromLifeInsurance(full_name, id_number,age,user_id);
    
 
      }
    render(){
      const {full_name,id_number,age,lang}=this.props


        return(

            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
                      <ScrollView ref={(ref)=> {this._scrollView = ref}}>

              <Card style={{backgroundColor:'transparent',borderColor:'transparent'}}>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={full_name}
                     placeholder ={strings('carInformation.full_name',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getLifeInsuranceTexts({prop:"full_name",value})}
                   />
                 </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={id_number}
                     placeholder ={strings('carInformation.id_number',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getLifeInsuranceTexts({prop:"id_number",value})}
                   />
                 </Item>
               </CardItem>
     
                  <CardItem style={transparentBackground}>
                  <Item style={transparentBorder}>
             
                    <Picker
                      mode="dropdown"
                      
                      iosHeader={strings('lifeinsurance.age',lang)}
                      placeholder={strings('lifeinsurance.age',lang)}
                      iosIcon={<Icon name="arrow-down" />}
                      placeholderStyle={{ color: "#9B9B9B" }}
                      style={[pickerStyle,{fontFamily:'TajawalRegular0',fontFamily:'TajawalRegular0',direction:lang=='ar'?'rtl':'ltr'}]}
                      selectedValue={age}
                      onValueChange={value =>
                        this.props.getLifeInsuranceTexts({
                          prop: "age",
                          value
                        })
                      }
                     >
                    <Picker.Item label="20-30" value="1" />
                     <Picker.Item label="30-40" value="2" />
                     <Picker.Item label="40-50" value="3" />
                     <Picker.Item label="50-60" value="4" />
                     <Picker.Item label="60-70" value="5" />
                    </Picker>
                </Item>
               </CardItem>
         
               <CardItem style={transparentBackground}>
               
                <Body style={centerStyle}>
               
                  <Button style={buttonStyle}  block onPress={this.goFromLifeInsurance}>
                  {lang=='ar'?
                    <Icon name='md-arrow-back' style={{color:'#fff'}}/>
                    :null}
                    <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
                    {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                  </Button>
                </Body>
            </CardItem>

            </Card>
           

            </ScrollView>
            <Text>{this.showAlert()}</Text>

<DropdownAlert ref={ref => (this.dropdown = ref)} style={{fontFamily:'TajawalRegular0'}}/>
            </ImageBackground>

            

        )
    }
}
// export default LifeInsurance;
const mapStateToProps = state => {
    const { lang } = state.sideBarReducer;
    const { full_name,id_number,life_insurance_msg,age} = state.lifeInsuranceReducer;
    return {full_name,id_number,life_insurance_msg,age,lang};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,lifeInsuranceAction)(LifeInsurance);