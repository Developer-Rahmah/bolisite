// import React, { Component } from 'react';
// import {ImageBackground,Dimensions,ScrollView,View,Image} from 'react-native';
// import {CardItem,Body,Button,Text, Icon,Form,Item,Input,Picker,Right,Left,Card} from 'native-base';
// import {transparentBackground,transparentBorder,inputStyle,centerStyle,buttonStyle,buttonText,pickerStyle,datePickerStyle} from '../theme';
// import * as travelInsuranceAction from '../actions/travelInsuranceAction';
// import DropdownAlert from 'react-native-dropdownalert';
// import { connect } from 'react-redux';
// import {strings} from '../../Locales/i18n';
// const dimensions=Dimensions.get('window');
// class TravelInsurance extends Component{

//     componentDidUpdate (){
//         const { travel_insurance_msg} = this.props;
//          if (travel_insurance_msg != null) {
//            setTimeout(()=> this.props.resetTravelInsuranceMessage(),300);
//          }
//       }

//     //START DROPDOWN MESSAGES
//   onError = (error) => {
//     if (error) {
//     console.log("error",error)
//     this.dropdown.alertWithType('error', 'Error', error);
//   }
// }

//   onSuccess = success => {
//     if (success) {
//     this.dropdown.alertWithType('success', 'Success', success);
//   }
// }
 
// //END DROPDOWN MESSAGES
//      //START SHOW ALERT FUNC
//      showAlert = () => {
//       const {travel_insurance_msg} = this.props;
//       if (travel_insurance_msg != null) {
//         if (travel_insurance_msg.isError) {
//           this.onError(travel_insurance_msg.msg);
//         } else if (travel_insurance_msg.isSuccess) {
//           this.onSuccess(travel_insurance_msg.msg);
//         } else {
//           return;
//         }
//       }
//     };
//     goFromTravelInsurance=()=>{
//         const {full_name, passport_number,destination,user_id} = this.props;
//         this.props.goFromTravelInsurance(full_name, passport_number,destination,user_id);
    
 
//       }
//     render(){
//       console.log("this.props in car information",this.props)
//       const {full_name,passport_number,destination,lang}=this.props


//         return(

//             <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
//                       <ScrollView ref={(ref)=> {this._scrollView = ref}}>

//               <Card style={{backgroundColor:'transparent',borderColor:'transparent'}}>
//                <CardItem style={transparentBackground}>
//                  <Item style={transparentBorder}> 
//                    <Input
//                      color="#fff"
//                      value ={full_name}
//                      placeholder ={strings('carInformation.full_name',lang)}
//                      placeholderTextColor="#9B9B9B"
//                      style={[inputStyle,{textAlign:lang=='ar'?"right":"left"}]}
//                      onChangeText={value =>this.props.getTravelInsuranceTexts({prop:"full_name",value})}
//                    />
//                  </Item>
//                </CardItem>
//                <CardItem style={transparentBackground}>
//                  <Item style={transparentBorder}> 
//                    <Input
//                      color="#fff"
//                      value ={passport_number}
//                      placeholder ={strings('travelinsurance.Passport_number',lang)}
//                      placeholderTextColor="#9B9B9B"
//                      style={[inputStyle,{textAlign:lang=='ar'?"right":"left"}]}
//                      onChangeText={value =>this.props.getTravelInsuranceTexts({prop:"passport_number",value})}
//                    />
//                  </Item>
//                </CardItem>
     
//                <CardItem style={transparentBackground}>
//                  <Item style={transparentBorder}> 
//                    <Input
//                      color="#fff"
//                      value ={destination}
//                      placeholder ={strings('travelinsurance.destination',lang)}
//                      placeholderTextColor="#9B9B9B"
//                      style={[inputStyle,{textAlign:lang=='ar'?"right":"left"}]}
//                      onChangeText={value =>this.props.getTravelInsuranceTexts({prop:"destination",value})}
//                    />
//                  </Item>
//                </CardItem>
         
//                <CardItem style={transparentBackground}>
               
//                 <Body style={centerStyle}>
               
//                   <Button style={buttonStyle}  block onPress={this.goFromTravelInsurance}>
//                   {lang=='ar'?
//                     <Icon name='md-arrow-back' style={{color:'#fff'}}/>
//                     :null}
//                     <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
//                     {lang=='en'?
//                    <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
//                    :null}
//                   </Button>
//                 </Body>
//             </CardItem>

//             </Card>
           

//             </ScrollView>
//             <Text>{this.showAlert()}</Text>

// <DropdownAlert ref={ref => (this.dropdown = ref)} />
//             </ImageBackground>

            

//         )
//     }
// }
// // export default LifeInsurance;
// const mapStateToProps = state => {
//     const { lang } = state.sideBarReducer;
//     const { full_name,passport_number,travel_insurance_msg,destination} = state.travelInsuranceReducer;
//     return {full_name,passport_number,travel_insurance_msg,destination,lang};
//   }
//   // END MAP STATE TO PROPS
  
  
//   export default connect(mapStateToProps,travelInsuranceAction)(TravelInsurance);







import React, { Component } from 'react';
import {ImageBackground,Dimensions,ScrollView,View,Image} from 'react-native';
import {CardItem,Body,Button,Text, Icon,Form,Item,Input,Picker,Right,Left,Card} from 'native-base';
import {transparentBackground,transparentBorder,inputStyle,centerStyle,buttonStyle,buttonText,pickerStyle,datePickerStyle} from '../theme';
import * as travelInsuranceAction from '../actions/travelInsuranceAction';
import DropdownAlert from 'react-native-dropdownalert';
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';
import DatePicker from 'react-native-datepicker';

const dimensions=Dimensions.get('window');
class TravelInsurance extends Component{

    componentDidUpdate (){
        const { travel_insurance_msg} = this.props;
         if (travel_insurance_msg != null) {
           setTimeout(()=> this.props.resetTravelInsuranceMessage(),300);
         }
      }

    //START DROPDOWN MESSAGES
  onError = (error) => {
    if (error) {
    console.log("error",error)
    this.dropdown.alertWithType('error', 'Error', error);
  }
}

  onSuccess = success => {
    if (success) {
    this.dropdown.alertWithType('success', 'Success', success);
  }
}
 
//END DROPDOWN MESSAGES
     //START SHOW ALERT FUNC
     showAlert = () => {
      const {travel_insurance_msg} = this.props;
      if (travel_insurance_msg != null) {
        if (travel_insurance_msg.isError) {
          this.onError(travel_insurance_msg.msg);
        } else if (travel_insurance_msg.isSuccess) {
          this.onSuccess(travel_insurance_msg.msg);
        } else {
          return;
        }
      }
    };
    goFromTravelInsurance=()=>{
        const {full_name, passport_number,from,to,travel_date,user_id} = this.props;
        this.props.goFromTravelInsurance(full_name, passport_number,from,to,travel_date,user_id);
    
 
      }
    render(){
      console.log("this.props in car information",this.props)
      const {full_name,passport_number,from,to,lang,travel_date}=this.props


        return(

            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
                      <ScrollView ref={(ref)=> {this._scrollView = ref}}>

              <Card style={{backgroundColor:'transparent',borderColor:'transparent'}}>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={full_name}
                     placeholder ={strings('carInformation.full_name',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getTravelInsuranceTexts({prop:"full_name",value})}
                   />
                 </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={passport_number}
                     placeholder ={strings('travelinsurance.Passport_number',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getTravelInsuranceTexts({prop:"passport_number",value})}
                   />
                 </Item>
               </CardItem>
     
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={from}
                     placeholder ={strings('travelinsurance.destination_from',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getTravelInsuranceTexts({prop:"from",value})}
                   />
                 </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={to}
                     placeholder ={strings('travelinsurance.destination_to',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getTravelInsuranceTexts({prop:"to",value})}
                   />
                 </Item>
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}>
                 <DatePicker
                 style={datePickerStyle}
                 date={ travel_date}
                 mode="date"
                 placeholder={strings('travelinsurance.travel_date',lang)}
                 format="YYYY-MM-DD"
                 minDate={new Date()}
                 maxDate="2029-12-31"
                 confirmBtnText="Confirm"
                 cancelBtnText="Cancel"
                 customStyles={{
                 dateIcon: {
                 position: 'absolute',
                 left: 0,
                 top: 4,
                 marginLeft: 0
                 },
                 dateInput: {
                 marginLeft: 36
                 },
                 btnTextConfirm: {
                 height: 20
                 },
                 btnTextCancel: {
                 height: 20
                 }
     }}
     onDateChange={(value) => this.props.getTravelInsuranceTexts({prop:"travel_date",value})}
    />
                 </Item>
                 </CardItem>
         
               <CardItem style={transparentBackground}>
               
                <Body style={centerStyle}>
               
                  <Button style={buttonStyle}  block onPress={this.goFromTravelInsurance}>
                  {lang=='ar'?
                    <Icon name='md-arrow-back' style={{color:'#fff'}}/>
                    :null}
                    <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
                    {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                  </Button>
                </Body>
            </CardItem>

            </Card>
           

            </ScrollView>
            <Text>{this.showAlert()}</Text>

<DropdownAlert ref={ref => (this.dropdown = ref)} style={{fontFamily:'TajawalRegular0',}} />
            </ImageBackground>

            

        )
    }
}
// export default LifeInsurance;
const mapStateToProps = state => {
    const { lang } = state.sideBarReducer;
    const { full_name,passport_number,travel_insurance_msg,from,travel_date,to} = state.travelInsuranceReducer;
    return {full_name,passport_number,travel_insurance_msg,from,lang,travel_date,to};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,travelInsuranceAction)(TravelInsurance);