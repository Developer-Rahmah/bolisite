import React, { Component } from 'react';
import {ImageBackground,Dimensions,ScrollView,View,Image} from 'react-native';
import {CardItem,Body,Button,Text, Icon,Form,Item,Input,Picker,Right,Left,Card} from 'native-base';
import {transparentBackground,transparentBorder,inputStyle,centerStyle,buttonStyle,buttonText,pickerStyle,datePickerStyle} from '../theme';
import * as shippingInsuranceAction from '../actions/shippingInsuranceAction';
import DropdownAlert from 'react-native-dropdownalert';
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';
const dimensions=Dimensions.get('window');
class ShippingInsurance extends Component{

    componentDidUpdate (){
        const { shipping_insurance_msg} = this.props;
         if (shipping_insurance_msg != null) {
           setTimeout(()=> this.props.resetShippingInsuranceMessage(),300);
         }
      }

    //START DROPDOWN MESSAGES
  onError = (error) => {
    if (error) {
    console.log("error",error)
    this.dropdown.alertWithType('error', 'Error', error);
  }
}

  onSuccess = success => {
    if (success) {
    this.dropdown.alertWithType('success', 'Success', success);
  }
}
 
//END DROPDOWN MESSAGES
     //START SHOW ALERT FUNC
     showAlert = () => {
      const {shipping_insurance_msg} = this.props;
      console.log("shipping_insurance_msg",shipping_insurance_msg)
      if (shipping_insurance_msg != null) {
        if (shipping_insurance_msg.isError) {
          this.onError(shipping_insurance_msg.msg);
        } else if (shipping_insurance_msg.isSuccess) {
          this.onSuccess(shipping_insurance_msg.msg);
        } else {
          return;
        }
      }
    };
    goFromShippingInsurance=()=>{
        const {bill_of_lading_number,user_id} = this.props;
        this.props.goFromShippingInsurance(bill_of_lading_number,user_id);
    
 
      }
    render(){
      console.log("this.props in car information",this.props)
      const {bill_of_lading_number,lang}=this.props


        return(

            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:'100%'}}>
                      <ScrollView ref={(ref)=> {this._scrollView = ref}}>

              <Card style={{backgroundColor:'transparent',borderColor:'transparent'}}>
               <CardItem style={transparentBackground}>
                 <Item style={transparentBorder}> 
                   <Input
                     color="#fff"
                     value ={bill_of_lading_number}
                     placeholder ={strings('shippinginsurance.bill_of_lading_number',lang)}
                     placeholderTextColor="#9B9B9B"
                     style={[inputStyle,{fontFamily:'TajawalRegular0',textAlign:lang=='ar'?"right":"left"}]}
                     onChangeText={value =>this.props.getShippingInsuranceTexts({prop:"bill_of_lading_number",value})}
                   />
                 </Item>
               </CardItem>
             
     
         
               <CardItem style={transparentBackground}>
               
                <Body style={centerStyle}>
               
                  <Button style={buttonStyle}  block onPress={this.goFromShippingInsurance}>
                  {lang=='ar'?
                    <Icon name='md-arrow-back' style={{color:'#fff'}}/>
                    :null}
                    <Text style={buttonText}>{strings('drivinglicense.continue',lang)}</Text>
                    {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                  </Button>
                </Body>
            </CardItem>

            </Card>
           

            </ScrollView>
            <Text>{this.showAlert()}</Text>

<DropdownAlert ref={ref => (this.dropdown = ref)} style={{fontFamily:'TajawalRegular0',}} />
            </ImageBackground>

            

        )
    }
}
// export default LifeInsurance;
const mapStateToProps = state => {
    const { lang } = state.sideBarReducer;
    const { bill_of_lading_number,shipping_insurance_msg} = state.shippingInsuranceReducer;
    return {bill_of_lading_number,shipping_insurance_msg,lang};
  }
  // END MAP STATE TO PROPS
  
  
  export default connect(mapStateToProps,shippingInsuranceAction)(ShippingInsurance);