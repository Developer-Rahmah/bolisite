import React, { Component } from 'react';
import {ImageBackground,Dimensions,Image,TouchableOpacity,Alert} from 'react-native';
import {CardItem,Body,Button,Text,Right,Left, Icon, Content,View} from 'native-base';
import {uploadButton,licenseImage,continueText,uploadLicenseText,skipButton,skipText,continueButton} from '../assests/styles/drivingLicenseStyles';
import {transparentBackground,centerStyle} from '../theme';
import {Actions} from "react-native-router-flux";
import {  ImagePicker, Camera, Permissions } from 'expo';

// import {RNCamera} from 'react-native-camera';
import * as drivingLicenseAction from '../actions/drivingLicenseAction';
import { connect } from 'react-redux';
import {strings} from '../../Locales/i18n';
const dimensions=Dimensions.get('window');
class DrivingLicense extends Component{
  constructor(props){
    super(props);
    this.state ={
      showCameraView:false ,
       type: Camera.Constants.Type.back,
            image: null,
            cameraPermission: null,
            cameraRollPermission: null,
    }
  }
  async componentWillMount() {
    
    this.setState({ loading: false });
    const { status } = await Permissions.askAsync(Permissions.CAMERA);
    this.setState({ hasCameraPermission: status === 'granted' });
}


  async componentDidMount() {
    const cameraPermission = await Permissions.getAsync(Permissions.CAMERA)
    const cameraRollPermission = await Permissions.getAsync(Permissions.CAMERA_ROLL);

    this.setState({
        cameraPermission: cameraPermission.status,
        cameraRollPermission: cameraRollPermission.status,
    })

}
  takePicture =  async function(a) {
    // debugger
    if (this.camera) {
      const options = { quality: 0.5, base64: true };
      const data23 =  await this.camera.takePictureAsync(options);
      const base64Str = 'data:image/jpg;base64,'+data23.base64;
       var data = new FormData();  
      data.append('apikey', '103f8deacb88957')
      data.append('base64Image', base64Str)
      data.append('language','ara')
      data.append('isOverlayRequired',true)
    
    const headers = { 
      'isOverlayRequired':true,
      'language':'ara',
      'apikey': '103f8deacb88957',
      'Accept': 'application/json',
      'Content-Type': 'multipart/form-data;',
     }
    const config = { 
      method: 'POST', 
      headers,
      body: data
     };
    const URL = 'https://api.ocr.space/parse/image';
    // debugger
    fetch(URL, config ).then(res=>{
      // debugger
      console.log('asda',res)
    })
    
    this.setState({showCameraView:false })
    
   // this.props.getImageInfo(data.uri)
    }
  };
    render(){
      let { image } = this.state;

      const {lang}=this.props;
  console.log("this.prop in driving",this.props)
        return(
            <ImageBackground source={require('../assests/images/splash–1.png')} style={{width:dimensions.width,height:dimensions.height}}>
            <Content style={transparentBackground}>
            {this.state.showCameraView?
            <View style={{flex: 1,flexDirection: 'column',backgroundColor: 'black',width:dimensions.width,height:dimensions.height/1.2}}>
  
        {/* <RNCamera
          ref={ref => {
            this.camera = ref;
          }}
          style={{flex: 1,justifyContent: 'flex-end',alignItems: 'center'}}
          type={RNCamera.Constants.Type.back}
          flashMode={RNCamera.Constants.FlashMode.on}
          permissionDialogTitle={'Permission to use camera'}
          permissionDialogMessage={'We need your permission to use your camera phone'}
          onGoogleVisionBarcodesDetected={({ barcodes }) => {
            console.log(barcodes);
          }}
        /> */}





<View style={{width:300,height:300}}>





<View style={{ flexDirection: 'column', width: Dimensions.get('window').width / 1.1, height: 160, justifyContent: 'center', paddingBottom: 5, marginRight: -30 }}>
    <View style={{ width: Dimensions.get('window').width / 1.33, height: 30, }}>
        <Text style={{
            width: 100
            , paddingTop: 0,
            color: 'rgba(189, 191, 191, 1)',
            fontSize: 13,
        }}> image</Text></View>

    

   

</View>

 
</View>





        <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center' }}>
          <TouchableOpacity 
          // onPress={this.takePicture.bind(this,"Left")} 
          onPress={()=>{ this._takePicture() } }

          style={{flex: 0,backgroundColor: '#fff',borderRadius: 5,padding: 15,paddingHorizontal: 20,alignSelf: 'center',margin: 20,}}>
          <Icon name='md-camera'/> 
          </TouchableOpacity>
        </View>
      </View>
      :null}
               <CardItem style={[transparentBackground,{marginTop:30}]}>
               <View style={{ width: '100%', height: 110, justifyContent: 'center', alignItems: 'center', borderRadius: 0,  borderWidth: 0, backgroundColor: 'transform' }}>
            <Image style={{
                resizeMode: 'contain',
                width: '50%',
                marginBottom: -3,
                // justifyContent: 'cener',
                height: '100%',
            }} source={require('../../assets/Driving-license.png')} />
            <View style={{ justifyContent: 'center', alignItems: 'center', }}>
    {image &&
        <Image source={{ uri: image }} style={{ width: 290, height: 120, marginTop: -130, }} />}
</View> 

        </View>
                 {/* <Body style={centerStyle}>
                 <Image
                   source={require('../../assets/Artboard.png')} style={licenseImage}
                 />
                 
                 </Body> */}
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Body style={centerStyle}>
                   <Button style={uploadButton} block 
                  //  onPress={()=>this.setState({showCameraView: true})}
                  onPress={()=>{ this._takePicture() } }
                   >
                     <Text style={uploadLicenseText}>{strings('drivinglicense.upload_car_license',lang)}</Text>
                   </Button>
                 </Body>
               </CardItem>
               <CardItem style={transparentBackground}>
                 <Button style={continueButton}
                 onPress={()=>{ this.uploadImageAsync(image) } }
                 >
                 {lang=='ar'?
                   <Icon name='md-arrow-back' style={{color:'#fff'}}/> 
                   :null}
                   <Text style={continueText}>{strings('drivinglicense.continue',lang)}</Text>
                   {lang=='en'?
                   <Icon name='md-arrow-round-forward'style={{color:'#fff'}}/> 
                   :null}
                   </Button>
                 <Button style={skipButton}onPress={() => Actions.carinformation({user_id:this.props.user_id})}>
                   <Text style={skipText}>{strings('drivinglicense.skip',lang)}</Text>
                 </Button>
               </CardItem>
               </Content>
           </ImageBackground>
        )
    }
    _pickImage = async () => {
      let result = await ImagePicker.launchImageLibraryAsync({
          allowsEditing: true,
          aspect: [4, 3],
      });

      console.log(result);

      if (!result.cancelled) {
          this.setState({ image: result.uri });
      }
  };
  _cam = async () => {
      let result = await ImagePicker.launchCameraAsync({
          allowsEditing: true,
          aspect: [4, 3],
      });

      console.log(result);

      if (!result.cancelled) {
          this.setState({ image: result.uri });
      }
  };

  async  uploadImageAsync(uri) {
    let apiUrl = 'https://bolisati1.qiotic.info/app/testimage';
  
    // Note:
    // Uncomment this if you want to experiment with local server
    //
    // if (Constants.isDevice) {
    //   apiUrl = `https://your-ngrok-subdomain.ngrok.io/upload`;
    // } else {
    //   apiUrl = `http://localhost:3000/upload`
    // }
  console.log('in upload fun',uri)
    let uriParts = uri.split('.');
    let fileType = uriParts[uriParts.length - 1];
  
    let formData = new FormData();
    formData.append('photo', {
      uri,
      name: `photo.${fileType}`,
      type: `image/${fileType}`,
    });
  
    let options = {
      method: 'POST',
      body: formData,
      
      headers: {
        Accept: 'application/json',
        'Content-Type': 'multipart/form-data',
      },
    };
  
     return fetch(apiUrl, options ).then(res=>{
      console.log('response',res)
    })

  }


  _checkCameraPermissions = async () => {
      const { status } = await Permissions.getAsync(Permissions.CAMERA);
      //const { status } = await Permissions.getAsync(Permissions.CAMERA_ROLL);
      this.setState({ status });
  }
  _reqCameraPermissions = async () => {
      const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
      this.setState({ cameraPermission: status });
  };


  _checkCameraRollPermissions = async () => {
      const { status } = await Permissions.getAsync(Permissions.CAMERA);
      this.setState({ status });
  }
  _reqCameraRollPermissions = async () => {
      const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
      this.setState({ cameraRollPermission: status });
  };

  _pickImage = async () => {
      this._checkCameraRollPermissions();
      this._reqCameraRollPermissions();
      let result = await ImagePicker.launchImageLibraryAsync();

      console.log(result);
      if (!result.cancelled) {
          this.setState({ image: result.uri });
          CameraRoll.saveToCameraRoll(result.uri)
      }
  };

  _takePicture = async () => {
      this._checkCameraPermissions();
      this._reqCameraPermissions();

      let result = await ImagePicker.launchCameraAsync();
      // let result = await ImagePicker.launchImageLibraryAsync();

      console.log(result);
      if (!result.cancelled) {
          this.setState({ image: result.uri });
          CameraRoll.saveToCameraRoll(result.uri)

        let apiUrl = 'https://bolisati1.qiotic.info/app/testimage';

let uri=result.uri
  let uriParts = result.uri.split('.');
  let fileType = uriParts[uriParts.length - 1];

  let formData = new FormData();
  formData.append('photo', {
    uri,
    name: `photo.${fileType}`,
    type: `image/${fileType}`,
  });

  let options = {
    method: 'POST',
    body: formData,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'multipart/form-data',
    },
  };
  fetch(apiUrl, options).then(res=>{
            console.log('response',res)
            let body = {
              "requests": [
                {
          
      "image":{
        "source":{
          "imageUri":res._bodyInit
        }
      },
                  "features": [
                    {
                      "type": "DOCUMENT_TEXT_DETECTION"              }
                  ]
                }
              ]
            }
          
        
          axios.post('https://vision.googleapis.com/v1/images:annotate?key=AIzaSyByOzFsQ-KQO27e_XVGtZrsxkbslGS56l4', body)
        .then((response) =>{
        console.log("response5555555",response)
        if(response.data.responses){
        var test=response.data.responses[0].textAnnotations[0].description
                // var test= '"description": "The Hashemite Kingdom of Jordan\nMinistry of Interior Licensing Department\nVehicle License\nالمملكة الأردنية الهاشمية\nوزارة الداخلية - إدارة الترخيص\nرخصة المركبة\nعادل عبدالرحيم عوده غنيم\nالعنوان: البلقاء السلط حي السلالم\nنوع المركبة فورد\nصنف المركبة اسكيب\nاللون ابيض\nاللون الفرعي\nفتة المركبة ركوب صغير\nصفة الاستعمال، ركوب\nسنة الصنع: ۲۰۰۸\nمرخصة لغاية. ۲۰۱۹\n/\n۱۲\n/\n۲۰\nصفة التسجيل\nرقم اللوحة\nخصوصي 5675-10\n"'

        console.log("test",test)
        var al = new Array();
        console.log("test2",test)
        al=test.split("\n");
        var name=al[6]
        var car_type=al[8]
        var car_model=al[9]
        var manufacturing_year=al[14]
        var end_date=al[19]+al[18]+al[17]+al[16]+al[15]
        // this.props.goToForm(name,car_type,car_model,manufacturing_year,end_date,al)
        Actions.carinformationshow({
          full_name2:name,
          car_type2:car_type,car_model2:car_model,manufacturing_year2:manufacturing_year,end_date2:end_date,al:al
        })
        console.log("al",al);
        // document.write(al.join(" <br> "));
        }
          });
  
        });
      }
  };

}
// export default DrivingLicense;
// START MAP STATE TO PROPS
const mapStateToProps = state => {
  const { lang } = state.sideBarReducer;
  const { information} = state.drivingLicenseReducer;
  return { information,lang};




  
}
// END MAP STATE TO PROPS
export default connect(mapStateToProps,drivingLicenseAction)(DrivingLicense);